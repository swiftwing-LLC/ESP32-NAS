#include <WiFi.h>
#include <WiFiUdp.h>

// =====================================================
// WiFi
// =====================================================

const char* ssid = "BaBaWu";
const char* password = "95042700Wu$";

// =====================================================
// Node Information
// =====================================================

const char* NODE_ID = "NODE2";
const char* NODE_NAME = "Storage Node 2";

// =====================================================
// UDP Discovery
// =====================================================

WiFiUDP udp;

const uint16_t DISCOVERY_PORT = 4210;

char packetBuffer[160];


// =====================================================
// Connect WiFi
// =====================================================

void connectWiFi() {

  WiFi.mode(WIFI_STA);

  WiFi.begin(
    ssid,
    password
  );


  Serial.print("Connecting to WiFi");


  while (
    WiFi.status() !=
    WL_CONNECTED
  ) {

    delay(500);
    Serial.print(".");
  }


  Serial.println();

  Serial.println("WiFi connected!");

  Serial.print("Node 2 IP: ");
  Serial.println(WiFi.localIP());

  Serial.print("Signal strength: ");
  Serial.print(WiFi.RSSI());
  Serial.println(" dBm");
}


// =====================================================
// Reply to Master
// =====================================================

void sendDiscoveryReply(
  IPAddress masterIP,
  uint16_t masterPort
) {

  String response =
    "Swiftwing_NODE|";

  response += NODE_ID;

  response += "|";

  response +=
    WiFi.localIP().toString();

  response += "|";

  response +=
    String(
      ESP.getFreeHeap()
    );

  response += "|";

  response +=
    String(
      millis() / 1000
    );


  udp.beginPacket(
    masterIP,
    masterPort
  );

  udp.print(response);

  udp.endPacket();


  Serial.print(
    "Discovery reply sent to "
  );

  Serial.println(masterIP);
}


// =====================================================
// Setup
// =====================================================

void setup() {

  Serial.begin(115200);

  delay(1000);


  Serial.println();
  Serial.println("============================");

  Serial.print("Starting ");
  Serial.println(NODE_NAME);

  Serial.println("============================");


  connectWiFi();


  udp.begin(
    DISCOVERY_PORT
  );


  Serial.print(
    "Listening on UDP port: "
  );

  Serial.println(
    DISCOVERY_PORT
  );


  Serial.println();

  Serial.println(
    "Node 2 is ONLINE"
  );

  Serial.println(
    "Waiting for Master..."
  );

  Serial.println(
    "============================"
  );
}


// =====================================================
// Loop
// =====================================================

void loop() {

  // Reconnect if WiFi drops

  if (
    WiFi.status() !=
    WL_CONNECTED
  ) {

    Serial.println(
      "WiFi disconnected."
    );

    connectWiFi();

    udp.stop();

    udp.begin(
      DISCOVERY_PORT
    );
  }


  int packetSize =
    udp.parsePacket();


  if (packetSize) {

    int len =
      udp.read(
        packetBuffer,
        sizeof(packetBuffer) - 1
      );


    if (len > 0) {
      packetBuffer[len] = '\0';
    }


    String message =
      String(packetBuffer);


    if (
      message ==
      "Swiftwing_NAS_DISCOVER"
    ) {

      Serial.println(
        "Master discovered Node 2"
      );


      sendDiscoveryReply(
        udp.remoteIP(),
        udp.remotePort()
      );
    }
  }


  delay(2);
}