/*
  Swiftwing NAS - ESP32-C3 DNS NODE
  Role:
    - local DNS override for swiftwingnas.tplinkdns.com
    - automatically learns the Master IP from UDP announcements
    - forwards all other DNS queries to Cloudflare 1.1.1.1
    - announces C3 health to the Master / Monitor

  Board: ESP32-C3
*/

#include <WiFi.h>
#include <WiFiUdp.h>

// =====================================================
// CONFIG
// =====================================================

const char* WIFI_SSID     = "BaBaWu";
const char* WIFI_PASSWORD = "95042700Wu$";

const char* NAS_DOMAIN    = "swiftwingnas.tplinkdns.com";

IPAddress UPSTREAM_DNS(1, 1, 1, 1);

// =====================================================
// Ports
// =====================================================

const uint16_t DNS_PORT              = 53;
const uint16_t UPSTREAM_LOCAL_PORT   = 53053;
const uint16_t MASTER_ANNOUNCE_PORT  = 4211;
const uint16_t DNS_STATUS_PORT       = 4213;

const unsigned long MASTER_TIMEOUT_MS = 15000;
const unsigned long STATUS_INTERVAL_MS = 5000;

WiFiUDP dnsUDP;
WiFiUDP upstreamUDP;
WiFiUDP masterUDP;
WiFiUDP statusUDP;

IPAddress masterIP(0, 0, 0, 0);
bool masterKnown = false;
unsigned long masterLastSeen = 0;
unsigned long lastStatus = 0;

static uint8_t dnsBuffer[512];
static uint8_t upstreamBuffer[512];

// =====================================================
// Helpers
// =====================================================

String fieldAt(const String &s, int index) {
  int start = 0;
  int current = 0;

  while (true) {
    int end = s.indexOf('|', start);

    if (current == index) {
      if (end < 0) return s.substring(start);
      return s.substring(start, end);
    }

    if (end < 0) return "";
    start = end + 1;
    current++;
  }
}

bool parseIPv4(const String &text, IPAddress &result) {
  int a, b, c, d;

  if (sscanf(text.c_str(), "%d.%d.%d.%d", &a, &b, &c, &d) != 4) return false;

  if (a < 0 || a > 255 || b < 0 || b > 255 ||
      c < 0 || c > 255 || d < 0 || d > 255) return false;

  result = IPAddress(a, b, c, d);
  return true;
}

bool parseQuestionName(
  const uint8_t *packet,
  int packetLen,
  int &offset,
  String &name
) {
  name = "";

  if (packetLen < 12) return false;

  offset = 12;

  while (offset < packetLen) {
    uint8_t labelLen = packet[offset++];

    if (labelLen == 0) break;
    if ((labelLen & 0xC0) != 0) return false;
    if (offset + labelLen > packetLen) return false;

    if (name.length()) name += ".";

    for (int i = 0; i < labelLen; i++) {
      name += (char)packet[offset++];
    }
  }

  return offset + 4 <= packetLen;
}

void sendEmptyReply(
  const uint8_t *query,
  int queryLen,
  IPAddress clientIP,
  uint16_t clientPort,
  int questionEnd
) {
  if (questionEnd > queryLen || questionEnd < 12) return;

  uint8_t reply[512];
  memcpy(reply, query, questionEnd);

  reply[2] = 0x81;
  reply[3] = 0x80;

  reply[6] = 0;
  reply[7] = 0;
  reply[8] = 0;
  reply[9] = 0;
  reply[10] = 0;
  reply[11] = 0;

  dnsUDP.beginPacket(clientIP, clientPort);
  dnsUDP.write(reply, questionEnd);
  dnsUDP.endPacket();
}

void sendLocalAReply(
  const uint8_t *query,
  int queryLen,
  IPAddress clientIP,
  uint16_t clientPort,
  int questionEnd
) {
  if (questionEnd > queryLen || questionEnd < 12) return;

  uint8_t reply[512];
  int p = 0;

  memcpy(reply, query, questionEnd);
  p = questionEnd;

  reply[2] = 0x81;
  reply[3] = 0x80;

  // ANCOUNT = 1
  reply[6] = 0;
  reply[7] = 1;

  // NSCOUNT = 0, ARCOUNT = 0
  reply[8] = 0;
  reply[9] = 0;
  reply[10] = 0;
  reply[11] = 0;

  // Answer name pointer to question name at offset 12
  reply[p++] = 0xC0;
  reply[p++] = 0x0C;

  // TYPE A
  reply[p++] = 0x00;
  reply[p++] = 0x01;

  // CLASS IN
  reply[p++] = 0x00;
  reply[p++] = 0x01;

  // TTL 5 seconds
  reply[p++] = 0x00;
  reply[p++] = 0x00;
  reply[p++] = 0x00;
  reply[p++] = 0x05;

  // RDLENGTH = 4
  reply[p++] = 0x00;
  reply[p++] = 0x04;

  reply[p++] = masterIP[0];
  reply[p++] = masterIP[1];
  reply[p++] = masterIP[2];
  reply[p++] = masterIP[3];

  dnsUDP.beginPacket(clientIP, clientPort);
  dnsUDP.write(reply, p);
  dnsUDP.endPacket();
}

// =====================================================
// Master IP learning
// =====================================================

void processMasterAnnouncements() {
  int packetSize = masterUDP.parsePacket();

  while (packetSize) {
    char buffer[160];

    int len = masterUDP.read(buffer, sizeof(buffer) - 1);
    if (len > 0) buffer[len] = '\0';

    String msg(buffer);

    // SWIFTWING_MASTER|ip|uptime
    if (msg.startsWith("SWIFTWING_MASTER|")) {
      IPAddress learned;

      if (parseIPv4(fieldAt(msg, 1), learned)) {
        bool changed = !masterKnown || learned != masterIP;

        masterIP = learned;
        masterKnown = true;
        masterLastSeen = millis();

        if (changed) {
          Serial.print("Master IP learned: ");
          Serial.println(masterIP);
        }
      }
    }

    packetSize = masterUDP.parsePacket();
  }

  if (masterKnown && millis() - masterLastSeen > MASTER_TIMEOUT_MS) {
    masterKnown = false;
    Serial.println("Master timeout");
  }
}

// =====================================================
// DNS proxy
// =====================================================

void forwardToUpstream(
  const uint8_t *query,
  int queryLen,
  IPAddress clientIP,
  uint16_t clientPort
) {
  upstreamUDP.beginPacket(UPSTREAM_DNS, 53);
  upstreamUDP.write(query, queryLen);
  upstreamUDP.endPacket();

  unsigned long start = millis();

  while (millis() - start < 900) {
    int n = upstreamUDP.parsePacket();

    if (n > 0) {
      int len = upstreamUDP.read(upstreamBuffer, sizeof(upstreamBuffer));

      dnsUDP.beginPacket(clientIP, clientPort);
      dnsUDP.write(upstreamBuffer, len);
      dnsUDP.endPacket();

      return;
    }

    delay(1);
    yield();
  }
}

void processDNS() {
  int packetSize = dnsUDP.parsePacket();
  if (packetSize <= 0) return;

  IPAddress clientIP = dnsUDP.remoteIP();
  uint16_t clientPort = dnsUDP.remotePort();

  int len = dnsUDP.read(dnsBuffer, sizeof(dnsBuffer));
  if (len < 12) return;

  int offset = 0;
  String qname;

  if (!parseQuestionName(dnsBuffer, len, offset, qname)) return;

  int questionEnd = offset + 4;

  uint16_t qType = ((uint16_t)dnsBuffer[offset] << 8) | dnsBuffer[offset + 1];

  String lowerName = qname;
  lowerName.toLowerCase();

  String localName = String(NAS_DOMAIN);
  localName.toLowerCase();

  if (lowerName == localName) {
    if (qType == 1 && masterKnown) {
      sendLocalAReply(
        dnsBuffer,
        len,
        clientIP,
        clientPort,
        questionEnd
      );
    } else {
      // No AAAA record, or Master IP not known yet.
      sendEmptyReply(
        dnsBuffer,
        len,
        clientIP,
        clientPort,
        questionEnd
      );
    }

    return;
  }

  forwardToUpstream(dnsBuffer, len, clientIP, clientPort);
}

// =====================================================
// C3 health announcement
// =====================================================

void sendStatus() {
  if (WiFi.status() != WL_CONNECTED) return;

  String msg =
    "SWIFTWING_DNS|C3|" +
    WiFi.localIP().toString() +
    "|" +
    String(millis() / 1000UL);

  statusUDP.beginPacket(
    IPAddress(255, 255, 255, 255),
    DNS_STATUS_PORT
  );

  statusUDP.print(msg);
  statusUDP.endPacket();
}

// =====================================================
// Setup / loop
// =====================================================

void connectWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  Serial.print("Connecting WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.print("C3 DNS IP: ");
  Serial.println(WiFi.localIP());
}

void startUDP() {
  dnsUDP.begin(DNS_PORT);
  upstreamUDP.begin(UPSTREAM_LOCAL_PORT);
  masterUDP.begin(MASTER_ANNOUNCE_PORT);
  statusUDP.begin(DNS_STATUS_PORT + 100);
}

void setup() {
  Serial.begin(115200);
  delay(500);

  connectWiFi();
  startUDP();

  Serial.println("Swiftwing C3 DNS ONLINE");
  Serial.print(NAS_DOMAIN);
  Serial.println(" -> waiting for Master announcement");

  sendStatus();
  lastStatus = millis();
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    dnsUDP.stop();
    upstreamUDP.stop();
    masterUDP.stop();
    statusUDP.stop();

    WiFi.disconnect();
    connectWiFi();
    startUDP();

    masterKnown = false;
  }

  processMasterAnnouncements();
  processDNS();

  if (millis() - lastStatus >= STATUS_INTERVAL_MS) {
    lastStatus = millis();
    sendStatus();
  }

  delay(1);
}
