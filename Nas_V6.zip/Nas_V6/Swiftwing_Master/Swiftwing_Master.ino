/*
  Swiftwing NAS

  Role:
    - Control / Login / NAS Web UI only
    - Discovers Storage Node 1 and Storage Node 2
    - Tracks ESP32-C3 DNS and ESP8266 Monitor
    - Announces current Master IP to C3 DNS
    - DOES NOT store user files locally

  UI:
    /        = NAS file manager
    /status  = system/node monitoring page

  Board: ESP32
*/

#include <WiFi.h>
#include <WebServer.h>
#include <WiFiUdp.h>

// =====================================================
// CONFIG
// =====================================================

const char* WIFI_SSID     = "BaBaWu";
const char* WIFI_PASSWORD = "95042700Wu$";

const char* UI_USERNAME   = "admin";
const char* UI_PASSWORD   = "88888888";

// Must be exactly the same in Master, Node 1 and Node 2.
const char* NODE_API_KEY  = "BaBaWu";

const char* NAS_DOMAIN    = "swiftwingnas.tplinkdns.com";

// =====================================================
// Network protocol
// =====================================================

const uint16_t HTTP_PORT              = 80;
const uint16_t STORAGE_DISCOVERY_PORT = 4210;
const uint16_t MASTER_ANNOUNCE_PORT   = 4211;
const uint16_t MASTER_LOCAL_PORT      = 4212;
const uint16_t DNS_STATUS_PORT        = 4213;
const uint16_t MONITOR_STATUS_PORT    = 4214;

const unsigned long DISCOVERY_INTERVAL_MS = 3000;
const unsigned long MASTER_ANNOUNCE_MS    = 3000;
const unsigned long NODE_TIMEOUT_MS       = 12000;
const unsigned long SERVICE_TIMEOUT_MS    = 15000;

WebServer server(HTTP_PORT);

WiFiUDP storageUDP;
WiFiUDP masterAnnounceUDP;
WiFiUDP dnsStatusUDP;
WiFiUDP monitorStatusUDP;

// =====================================================
// Session
// =====================================================

String sessionToken = "";

// =====================================================
// Device state
// =====================================================

struct StorageNode {
  String id;
  String label;
  IPAddress ip;
  uint16_t port;
  bool online;
  bool storageReady;
  uint64_t totalBytes;
  uint64_t usedBytes;
  uint64_t freeBytes;
  uint32_t uptimeSeconds;
  unsigned long lastSeen;
};

StorageNode node1;
StorageNode node2;

bool c3Online = false;
IPAddress c3IP(0, 0, 0, 0);
uint32_t c3Uptime = 0;
unsigned long c3LastSeen = 0;

bool monitorOnline = false;
IPAddress monitorIP(0, 0, 0, 0);
uint32_t monitorUptime = 0;
int monitorRSSI = 0;
unsigned long monitorLastSeen = 0;

unsigned long lastDiscovery = 0;
unsigned long lastMasterAnnouncement = 0;

// =====================================================
// NAS MAIN PAGE
// =====================================================

static const char MAIN_PAGE[] PROGMEM = R"SWIFTMAIN(
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Swiftwing NAS</title>
<style>
*{box-sizing:border-box}
:root{--blue:#2563eb;--bg:#f5f7fa;--text:#182235;--muted:#728096;--border:#e4e9f0;--red:#dc2626}
body{margin:0;background:var(--bg);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;color:var(--text)}
.top{height:64px;background:#fff;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;padding:0 26px}
.brand{font-size:21px;font-weight:800}
.nav{display:flex;align-items:center;gap:15px}.nav a{color:#4f5f75;text-decoration:none;font-size:14px}.nav .active{color:var(--blue);font-weight:700}
.page{max-width:1180px;margin:22px auto;padding:0 18px}
.card{background:#fff;border:1px solid var(--border);border-radius:16px;padding:18px;box-shadow:0 4px 16px rgba(20,32,55,.04)}
.headerRow{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:16px}
.title{font-size:20px;font-weight:800}.muted{font-size:13px;color:var(--muted)}
.storageTabs{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px}
.tab{background:#edf1f7;color:#34445a;border:0;border-radius:10px;padding:9px 13px;cursor:pointer;font-weight:600}
.tab.active{background:var(--blue);color:#fff}
.tab:disabled{opacity:.45;cursor:not-allowed}
.path{font-size:14px;margin-bottom:13px}.crumb{color:var(--blue);cursor:pointer}.sep{margin:0 6px;color:#9ca7b7}
.search{display:flex;gap:8px;margin-bottom:13px}.search input{flex:1}
input{padding:10px;border:1px solid #d7dee8;border-radius:9px;font-size:14px}
.toolbar{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px}
button,.btn{border:0;border-radius:9px;padding:9px 12px;background:var(--blue);color:white;cursor:pointer;font-size:13px;text-decoration:none}
.secondary{background:#e9eef6;color:#2f3d51}.danger{background:#ef4444}
.fileHead,.fileRow{display:grid;grid-template-columns:minmax(230px,3fr) 1fr 1fr 2.5fr;gap:10px;align-items:center;padding:11px 8px}
.fileHead{border-bottom:1px solid var(--border);font-size:12px;font-weight:700;color:#7d899a}
.fileRow{border-bottom:1px solid #f0f2f5}.fileRow:hover{background:#fafbfc}
.name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.folder{font-weight:700;color:#2458a6;cursor:pointer}
.actions{display:flex;gap:6px;flex-wrap:wrap}.small{padding:6px 8px;font-size:12px}
.empty{padding:35px;text-align:center;color:#8491a4}
.statusText{font-size:13px;color:#607087}
@media(max-width:800px){.fileHead{display:none}.fileRow{grid-template-columns:1fr}.fileRow>div:nth-child(2),.fileRow>div:nth-child(3){display:none}.headerRow{align-items:flex-start;flex-direction:column}}
</style>
</head>
<body>
<div class="top">
  <div class="brand">Swiftwing NAS</div>
  <div class="nav">
    <a class="active" href="/">Files</a>
    <a href="/status">System Status</a>
    <a href="/logout">Logout</a>
  </div>
</div>

<div class="page">
  <div class="card">
    <div class="headerRow">
      <div>
        <div class="title">Files</div>
        <div class="statusText" id="browserStatus">Loading storage...</div>
      </div>
      <button class="secondary" onclick="refreshFiles()">Refresh</button>
    </div>

    <div class="storageTabs">
      <button id="tab_NODE1" class="tab" onclick="selectNode('NODE1')">Node 1</button>
      <button id="tab_NODE2" class="tab" onclick="selectNode('NODE2')">Node 2</button>
    </div>

    <div class="path" id="breadcrumbs"></div>

    <div class="search">
      <input id="searchInput" placeholder="Search this storage node...">
      <button onclick="runSearch()">Search</button>
      <button class="secondary" onclick="clearSearch()">Clear</button>
    </div>

    <div class="toolbar">
      <button class="secondary" onclick="goBack()">Back</button>
      <button onclick="newFolder()">New Folder</button>
      <label class="btn">
        Upload
        <input id="uploadFile" type="file" style="display:none" onchange="uploadSelected()">
      </label>
    </div>

    <div class="fileHead">
      <div>Name</div><div>Type</div><div>Size</div><div>Actions</div>
    </div>

    <div id="files">
      <div class="empty">Loading...</div>
    </div>
  </div>
</div>

<script>
let STATE = null;
let NODES = {};
let API_KEY = "";
let selectedId = null;
let currentPath = "/";
let searchMode = false;

function fmtBytes(n){
  n = Number(n || 0);
  if(n < 1024) return n + " B";
  if(n < 1048576) return (n/1024).toFixed(1) + " KB";
  if(n < 1073741824) return (n/1048576).toFixed(1) + " MB";
  return (n/1073741824).toFixed(2) + " GB";
}

function escapeHtml(s){
  return String(s)
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;")
    .replaceAll('"',"&quot;")
    .replaceAll("'","&#39;");
}

function selectedNode(){
  return selectedId ? NODES[selectedId] : null;
}

function nodeBase(n){
  return "http://" + n.ip + ":" + n.port;
}

async function loadState(firstLoad){
  try{
    const r = await fetch("/api/state", {cache:"no-store"});
    if(r.status === 401){
      location.href = "/";
      return;
    }

    STATE = await r.json();
    API_KEY = STATE.apiKey;

    NODES = {
      NODE1: STATE.nodes.NODE1,
      NODE2: STATE.nodes.NODE2
    };

    updateTabs();

    if(firstLoad){
      if(NODES.NODE1.online) selectedId = "NODE1";
      else if(NODES.NODE2.online) selectedId = "NODE2";

      if(selectedId) refreshFiles();
      else showNoNode();
    }
  }catch(e){
    document.getElementById("browserStatus").textContent = "Master status error";
  }
}

function updateTabs(){
  ["NODE1","NODE2"].forEach(id => {
    const n = NODES[id];
    const b = document.getElementById("tab_" + id);

    b.disabled = !n || !n.online;
    b.className = "tab" + (selectedId === id ? " active" : "");
  });
}

function selectNode(id){
  if(!NODES[id] || !NODES[id].online) return;

  selectedId = id;
  currentPath = "/";
  searchMode = false;

  updateTabs();
  refreshFiles();
}

function showNoNode(){
  document.getElementById("browserStatus").textContent = "No storage node available";
  document.getElementById("breadcrumbs").innerHTML = "";
  document.getElementById("files").innerHTML =
    '<div class="empty">Storage nodes are unavailable. Open System Status for details.</div>';
}

function renderBreadcrumbs(){
  const box = document.getElementById("breadcrumbs");
  box.innerHTML = "";

  if(!selectedId) return;

  const home = document.createElement("span");
  home.className = "crumb";
  home.textContent = "Home";
  home.onclick = function(){
    currentPath = "/";
    searchMode = false;
    refreshFiles();
  };
  box.appendChild(home);

  if(currentPath === "/") return;

  let build = "";

  currentPath.split("/").filter(Boolean).forEach(part => {
    const sep = document.createElement("span");
    sep.className = "sep";
    sep.textContent = "/";
    box.appendChild(sep);

    build += "/" + part;
    const target = build;

    const c = document.createElement("span");
    c.className = "crumb";
    c.textContent = part;
    c.onclick = function(){
      currentPath = target;
      searchMode = false;
      refreshFiles();
    };
    box.appendChild(c);
  });
}

async function nodeFetch(path, options){
  const n = selectedNode();

  if(!n || !n.online) throw new Error("Storage node unavailable");

  if(!options) options = {};

  const glue = path.indexOf("?") >= 0 ? "&" : "?";
  const url = nodeBase(n) + path + glue + "key=" + encodeURIComponent(API_KEY);

  const r = await fetch(url, options);
  const text = await r.text();

  if(!r.ok) throw new Error(text || ("HTTP " + r.status));

  try{
    return JSON.parse(text);
  }catch(e){
    return text;
  }
}

async function refreshFiles(){
  await loadState(false);

  const n = selectedNode();
  updateTabs();
  renderBreadcrumbs();

  if(!n || !n.online){
    showNoNode();
    return;
  }

  if(!n.storageReady){
    document.getElementById("browserStatus").textContent = n.label + " storage not ready";
    document.getElementById("files").innerHTML =
      '<div class="empty">Storage is not ready. Open System Status for details.</div>';
    return;
  }

  document.getElementById("browserStatus").textContent =
    n.label + " · " + fmtBytes(n.free) + " free";

  try{
    const data = await nodeFetch("/api/list?path=" + encodeURIComponent(currentPath));

    searchMode = false;
    renderItems(data.items || []);
  }catch(e){
    document.getElementById("files").innerHTML =
      '<div class="empty">' + escapeHtml(e.message) + '</div>';
  }
}

function renderItems(items){
  const box = document.getElementById("files");
  box.innerHTML = "";

  if(!items.length){
    box.innerHTML = '<div class="empty">This folder is empty.</div>';
    return;
  }

  items.forEach(item => {
    const row = document.createElement("div");
    row.className = "fileRow";

    const type = item.directory ? "Folder" : (item.ext || "File");
    const size = item.directory ? "--" : fmtBytes(item.size);

    row.innerHTML =
      '<div class="name ' + (item.directory ? 'folder' : '') + '">' + escapeHtml(item.name) + '</div>' +
      '<div class="muted">' + escapeHtml(type) + '</div>' +
      '<div class="muted">' + size + '</div>' +
      '<div class="actions"></div>';

    const nameCell = row.children[0];

    if(item.directory){
      nameCell.onclick = function(){
        currentPath = item.path;
        searchMode = false;
        refreshFiles();
      };
    }

    const actions = row.children[3];

    if(item.directory){
      actions.appendChild(actionButton("Open", "", function(){
        currentPath = item.path;
        searchMode = false;
        refreshFiles();
      }));
    }else{
      actions.appendChild(actionButton("Download", "", function(){
        downloadItem(item);
      }));
    }

    actions.appendChild(actionButton("Rename", "secondary", function(){ renameItem(item); }));
    actions.appendChild(actionButton("Move", "secondary", function(){ moveItem(item); }));
    actions.appendChild(actionButton("Delete", "danger", function(){ deleteItem(item); }));

    box.appendChild(row);
  });
}

function actionButton(text, cls, fn){
  const b = document.createElement("button");
  b.className = "small " + cls;
  b.textContent = text;
  b.onclick = fn;
  return b;
}

function goBack(){
  if(searchMode){
    clearSearch();
    return;
  }

  if(currentPath === "/") return;

  const parts = currentPath.split("/").filter(Boolean);
  parts.pop();

  currentPath = "/" + parts.join("/");
  if(currentPath === "") currentPath = "/";

  refreshFiles();
}

async function newFolder(){
  if(!selectedId) return;

  const name = prompt("Folder name:");
  if(!name) return;

  try{
    await nodeFetch(
      "/api/mkdir?path=" + encodeURIComponent(currentPath) +
      "&name=" + encodeURIComponent(name),
      {method:"POST"}
    );

    refreshFiles();
  }catch(e){
    alert(e.message);
  }
}

async function deleteItem(item){
  if(!confirm("Delete " + item.name + "?")) return;

  try{
    await nodeFetch(
      "/api/delete?path=" + encodeURIComponent(item.path),
      {method:"POST"}
    );

    if(searchMode) runSearch();
    else refreshFiles();
  }catch(e){
    alert(e.message);
  }
}

async function renameItem(item){
  const name = prompt("New name:", item.name);

  if(!name || name === item.name) return;

  try{
    await nodeFetch(
      "/api/rename?path=" + encodeURIComponent(item.path) +
      "&name=" + encodeURIComponent(name),
      {method:"POST"}
    );

    if(searchMode) runSearch();
    else refreshFiles();
  }catch(e){
    alert(e.message);
  }
}

async function moveItem(item){
  const dest = prompt("Move to folder path:", currentPath);
  if(!dest) return;

  try{
    await nodeFetch(
      "/api/move?path=" + encodeURIComponent(item.path) +
      "&dest=" + encodeURIComponent(dest),
      {method:"POST"}
    );

    if(searchMode) runSearch();
    else refreshFiles();
  }catch(e){
    alert(e.message);
  }
}

function downloadItem(item){
  const n = selectedNode();

  const url =
    nodeBase(n) +
    "/download?key=" + encodeURIComponent(API_KEY) +
    "&path=" + encodeURIComponent(item.path);

  window.location.href = url;
}

async function uploadSelected(){
  const input = document.getElementById("uploadFile");
  const file = input.files[0];

  if(!file) return;

  const n = selectedNode();

  if(!n || !n.online || !n.storageReady){
    input.value = "";
    return;
  }

  const fd = new FormData();
  fd.append("file", file);

  const url =
    nodeBase(n) +
    "/upload?key=" + encodeURIComponent(API_KEY) +
    "&path=" + encodeURIComponent(currentPath);

  document.getElementById("browserStatus").textContent =
    "Uploading " + file.name + " directly to " + n.label + "...";

  try{
    const r = await fetch(url, {method:"POST", body:fd});
    const text = await r.text();

    if(!r.ok) throw new Error(text || "Upload failed");

    input.value = "";
    refreshFiles();
  }catch(e){
    input.value = "";
    alert(e.message);
  }
}

async function runSearch(){
  const q = document.getElementById("searchInput").value.trim();

  if(!q || !selectedId) return;

  try{
    const data = await nodeFetch(
      "/api/search?q=" + encodeURIComponent(q)
    );

    searchMode = true;

    document.getElementById("browserStatus").textContent =
      "Search · " + q + " · " + (data.items || []).length + " result(s)";

    renderItems(data.items || []);
  }catch(e){
    alert(e.message);
  }
}

function clearSearch(){
  document.getElementById("searchInput").value = "";
  searchMode = false;
  refreshFiles();
}

loadState(true);
setInterval(function(){
  loadState(false);
}, 5000);
</script>
</body>
</html>
)SWIFTMAIN";

// =====================================================
// SYSTEM STATUS PAGE
// =====================================================

static const char STATUS_PAGE[] PROGMEM = R"SWIFTSTATUS(
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Swiftwing NAS - System Status</title>
<style>
*{box-sizing:border-box}
:root{--blue:#2563eb;--bg:#f5f7fa;--text:#182235;--muted:#728096;--border:#e4e9f0;--green:#16a34a;--red:#dc2626}
body{margin:0;background:var(--bg);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;color:var(--text)}
.top{height:64px;background:#fff;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;padding:0 26px}
.brand{font-size:21px;font-weight:800}.nav{display:flex;gap:15px}.nav a{color:#4f5f75;text-decoration:none;font-size:14px}.nav .active{color:var(--blue);font-weight:700}
.page{max-width:1050px;margin:22px auto;padding:0 18px}
.heading{font-size:24px;font-weight:800;margin-bottom:5px}.sub{color:var(--muted);font-size:14px;margin-bottom:18px}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
.card{background:#fff;border:1px solid var(--border);border-radius:16px;padding:18px;box-shadow:0 4px 16px rgba(20,32,55,.04)}
.row{display:flex;justify-content:space-between;align-items:center;gap:12px}.name{font-size:17px;font-weight:800}
.dot{width:10px;height:10px;border-radius:50%;display:inline-block;margin-right:7px}.on{background:var(--green)}.off{background:var(--red)}
.muted{color:var(--muted);font-size:13px}.data{margin-top:12px;display:grid;grid-template-columns:110px 1fr;gap:7px;font-size:13px}
.bar{height:8px;background:#edf0f4;border-radius:8px;overflow:hidden;margin-top:12px}.fill{height:100%;background:var(--blue)}
@media(max-width:760px){.grid{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="top">
  <div class="brand">Swiftwing NAS</div>
  <div class="nav">
    <a href="/">Files</a>
    <a class="active" href="/status">System Status</a>
    <a href="/logout">Logout</a>
  </div>
</div>

<div class="page">
  <div class="heading">System Status</div>
  <div class="sub">Nodes, network services and storage health.</div>
  <div class="grid" id="cards"></div>
</div>

<script>
function fmtBytes(n){
  n = Number(n || 0);
  if(n < 1024) return n + " B";
  if(n < 1048576) return (n/1024).toFixed(1) + " KB";
  if(n < 1073741824) return (n/1048576).toFixed(1) + " MB";
  return (n/1073741824).toFixed(2) + " GB";
}

function fmtUptime(sec){
  sec = Number(sec || 0);

  const d = Math.floor(sec / 86400);
  sec %= 86400;

  const h = Math.floor(sec / 3600);
  sec %= 3600;

  const m = Math.floor(sec / 60);

  if(d > 0) return d + "d " + h + "h";
  if(h > 0) return h + "h " + m + "m";
  return m + "m";
}

function statusLabel(online){
  return '<span class="dot ' + (online ? 'on' : 'off') + '"></span>' +
    (online ? 'Online' : 'Offline');
}

function nodeCard(n){
  const total = Number(n.total || 0);
  const used = Number(n.used || 0);
  const percent = total > 0 ? Math.min(100, used / total * 100) : 0;

  return (
    '<div class="card">' +
      '<div class="row">' +
        '<div class="name">' + n.label + '</div>' +
        '<div>' + statusLabel(n.online) + '</div>' +
      '</div>' +
      '<div class="data">' +
        '<div class="muted">IP</div><div>' + (n.online ? n.ip : '--') + '</div>' +
        '<div class="muted">Storage</div><div>' + (n.storageReady ? 'Ready' : 'Not ready') + '</div>' +
        '<div class="muted">Used</div><div>' + fmtBytes(n.used) + '</div>' +
        '<div class="muted">Free</div><div>' + fmtBytes(n.free) + '</div>' +
        '<div class="muted">Total</div><div>' + fmtBytes(n.total) + '</div>' +
        '<div class="muted">Uptime</div><div>' + fmtUptime(n.uptime) + '</div>' +
      '</div>' +
      '<div class="bar"><div class="fill" style="width:' + percent + '%"></div></div>' +
    '</div>'
  );
}

function serviceCard(s, extra){
  return (
    '<div class="card">' +
      '<div class="row">' +
        '<div class="name">' + s.label + '</div>' +
        '<div>' + statusLabel(s.online) + '</div>' +
      '</div>' +
      '<div class="data">' +
        '<div class="muted">Role</div><div>' + s.detail + '</div>' +
        '<div class="muted">IP</div><div>' + (s.online ? s.ip : '--') + '</div>' +
        (s.uptime !== undefined ? '<div class="muted">Uptime</div><div>' + fmtUptime(s.uptime) + '</div>' : '') +
        (extra || '') +
      '</div>' +
    '</div>'
  );
}

async function refreshStatus(){
  try{
    const r = await fetch("/api/state", {cache:"no-store"});

    if(r.status === 401){
      location.href = "/";
      return;
    }

    const s = await r.json();

    let html = "";

    html += serviceCard(s.services.master, "");
    html += nodeCard(s.nodes.NODE1);
    html += nodeCard(s.nodes.NODE2);
    html += serviceCard(s.services.dns, "");
    html += serviceCard(
      s.services.monitor,
      '<div class="muted">WiFi RSSI</div><div>' + s.services.monitor.rssi + ' dBm</div>'
    );

    document.getElementById("cards").innerHTML = html;
  }catch(e){
    document.getElementById("cards").innerHTML =
      '<div class="card">Unable to load system status.</div>';
  }
}

refreshStatus();
setInterval(refreshStatus, 3000);
</script>
</body>
</html>
)SWIFTSTATUS";

// =====================================================
// Helpers
// =====================================================

String jsonEscape(String s) {
  s.replace("\\", "\\\\");
  s.replace("\"", "\\\"");
  s.replace("\r", "\\r");
  s.replace("\n", "\\n");
  return s;
}

String uint64ToString(uint64_t value) {
  char buf[32];

  snprintf(
    buf,
    sizeof(buf),
    "%llu",
    (unsigned long long)value
  );

  return String(buf);
}

String fieldAt(const String &s, int index) {
  int start = 0;
  int current = 0;

  while (true) {
    int end = s.indexOf('|', start);

    if (current == index) {
      if (end < 0) return s.substring(start);
      return s.substring(start, end);
    }

    if (end < 0) return "";

    start = end + 1;
    current++;
  }
}

bool parseIPv4(const String &text, IPAddress &result) {
  int a, b, c, d;

  if (
    sscanf(
      text.c_str(),
      "%d.%d.%d.%d",
      &a,
      &b,
      &c,
      &d
    ) != 4
  ) {
    return false;
  }

  if (
    a < 0 || a > 255 ||
    b < 0 || b > 255 ||
    c < 0 || c > 255 ||
    d < 0 || d > 255
  ) {
    return false;
  }

  result = IPAddress(a, b, c, d);
  return true;
}

void initNode(
  StorageNode &node,
  const String &id,
  const String &label
) {
  node.id = id;
  node.label = label;
  node.ip = IPAddress(0, 0, 0, 0);
  node.port = 80;
  node.online = false;
  node.storageReady = false;
  node.totalBytes = 0;
  node.usedBytes = 0;
  node.freeBytes = 0;
  node.uptimeSeconds = 0;
  node.lastSeen = 0;
}

StorageNode* findNodeById(const String &id) {
  if (id == "NODE1") return &node1;
  if (id == "NODE2") return &node2;

  return nullptr;
}

// =====================================================
// Authentication
// =====================================================

bool isAuthenticated() {
  if (sessionToken.length() == 0) return false;

  String cookie = server.header("Cookie");
  String expected = "SWIFTWING_SESSION=" + sessionToken;

  return cookie.indexOf(expected) >= 0;
}

String makeSessionToken() {
  char buf[33];

  snprintf(
    buf,
    sizeof(buf),
    "%08lx%08lx%08lx%08lx",
    (unsigned long)esp_random(),
    (unsigned long)esp_random(),
    (unsigned long)esp_random(),
    (unsigned long)esp_random()
  );

  return String(buf);
}

void redirectTo(const String &location) {
  server.sendHeader("Location", location);
  server.send(303, "text/plain", "");
}

void handleLoginPage() {
  static const char LOGIN_PAGE[] PROGMEM = R"LOGINPAGE(
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Swiftwing NAS Login</title>
<style>
*{box-sizing:border-box}
body{margin:0;background:#f5f7fa;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;color:#182235}
.wrap{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
.card{width:100%;max-width:390px;background:#fff;border-radius:20px;padding:30px;box-shadow:0 16px 45px rgba(20,32,55,.10)}
h1{margin:0 0 7px;font-size:27px}.sub{color:#728096;margin-bottom:24px}
input{width:100%;padding:13px 14px;margin:7px 0;border:1px solid #dce2ea;border-radius:11px;font-size:15px}
button{width:100%;padding:13px;margin-top:12px;border:0;border-radius:11px;background:#2563eb;color:white;font-size:15px;font-weight:700;cursor:pointer}
</style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <h1>Swiftwing NAS</h1>
    <div class="sub">Master Control Plane</div>
    <form method="POST" action="/login">
      <input name="username" placeholder="Username" autocomplete="username" required>
      <input name="password" type="password" placeholder="Password" autocomplete="current-password" required>
      <button type="submit">Sign in</button>
    </form>
  </div>
</div>
</body>
</html>
)LOGINPAGE";

  server.send_P(
    200,
    "text/html; charset=utf-8",
    LOGIN_PAGE
  );
}

void handleLogin() {
  if (
    !server.hasArg("username") ||
    !server.hasArg("password")
  ) {
    server.send(
      400,
      "text/plain",
      "Missing credentials"
    );

    return;
  }

  if (
    server.arg("username") != UI_USERNAME ||
    server.arg("password") != UI_PASSWORD
  ) {
    server.send(
      401,
      "text/plain",
      "Invalid username or password"
    );

    return;
  }

  sessionToken = makeSessionToken();

  server.sendHeader(
    "Set-Cookie",
    "SWIFTWING_SESSION=" +
    sessionToken +
    "; Path=/; HttpOnly; SameSite=Lax"
  );

  redirectTo("/");
}

void handleLogout() {
  sessionToken = "";

  server.sendHeader(
    "Set-Cookie",
    "SWIFTWING_SESSION=deleted; Path=/; Max-Age=0; HttpOnly; SameSite=Lax"
  );

  redirectTo("/");
}

// =====================================================
// Discovery
// =====================================================

void sendStorageDiscovery() {
  storageUDP.beginPacket(
    IPAddress(255, 255, 255, 255),
    STORAGE_DISCOVERY_PORT
  );

  storageUDP.print(
    "SWIFTWING_DISCOVER|MASTER"
  );

  storageUDP.endPacket();
}

void processStorageReplies() {
  int packetSize =
    storageUDP.parsePacket();

  while (packetSize) {
    char buffer[256];

    int len =
      storageUDP.read(
        buffer,
        sizeof(buffer) - 1
      );

    if (len > 0) {
      buffer[len] = '\0';
    }

    String msg(buffer);

    // SWIFTWING_STORAGE|NODE1|ip|port|ready|total|used|free|uptime
    if (
      msg.startsWith(
        "SWIFTWING_STORAGE|"
      )
    ) {
      String id =
        fieldAt(msg, 1);

      StorageNode *node =
        findNodeById(id);

      if (node != nullptr) {
        IPAddress reportedIP;

        if (
          !parseIPv4(
            fieldAt(msg, 2),
            reportedIP
          )
        ) {
          reportedIP =
            storageUDP.remoteIP();
        }

        node->ip =
          reportedIP;

        node->port =
          (uint16_t)
          fieldAt(msg, 3).toInt();

        if (node->port == 0) {
          node->port = 80;
        }

        node->storageReady =
          fieldAt(msg, 4).toInt() == 1;

        node->totalBytes =
          strtoull(
            fieldAt(msg, 5).c_str(),
            nullptr,
            10
          );

        node->usedBytes =
          strtoull(
            fieldAt(msg, 6).c_str(),
            nullptr,
            10
          );

        node->freeBytes =
          strtoull(
            fieldAt(msg, 7).c_str(),
            nullptr,
            10
          );

        node->uptimeSeconds =
          fieldAt(msg, 8).toInt();

        node->lastSeen =
          millis();

        node->online =
          true;
      }
    }

    packetSize =
      storageUDP.parsePacket();
  }

  unsigned long now =
    millis();

  if (
    node1.online &&
    now - node1.lastSeen >
    NODE_TIMEOUT_MS
  ) {
    node1.online = false;
  }

  if (
    node2.online &&
    now - node2.lastSeen >
    NODE_TIMEOUT_MS
  ) {
    node2.online = false;
  }
}

void sendMasterAnnouncement() {
  if (
    WiFi.status() !=
    WL_CONNECTED
  ) {
    return;
  }

  String msg =
    "SWIFTWING_MASTER|" +
    WiFi.localIP().toString() +
    "|" +
    String(millis() / 1000UL);

  masterAnnounceUDP.beginPacket(
    IPAddress(255, 255, 255, 255),
    MASTER_ANNOUNCE_PORT
  );

  masterAnnounceUDP.print(msg);

  masterAnnounceUDP.endPacket();
}

void processDNSStatus() {
  int packetSize =
    dnsStatusUDP.parsePacket();

  while (packetSize) {
    char buffer[160];

    int len =
      dnsStatusUDP.read(
        buffer,
        sizeof(buffer) - 1
      );

    if (len > 0) {
      buffer[len] = '\0';
    }

    String msg(buffer);

    if (
      msg.startsWith(
        "SWIFTWING_DNS|C3|"
      )
    ) {
      IPAddress ip;

      if (
        parseIPv4(
          fieldAt(msg, 2),
          ip
        )
      ) {
        c3IP = ip;
      } else {
        c3IP =
          dnsStatusUDP.remoteIP();
      }

      c3Uptime =
        fieldAt(msg, 3).toInt();

      c3LastSeen =
        millis();

      c3Online =
        true;
    }

    packetSize =
      dnsStatusUDP.parsePacket();
  }

  if (
    c3Online &&
    millis() - c3LastSeen >
    SERVICE_TIMEOUT_MS
  ) {
    c3Online = false;
  }
}

void processMonitorStatus() {
  int packetSize =
    monitorStatusUDP.parsePacket();

  while (packetSize) {
    char buffer[180];

    int len =
      monitorStatusUDP.read(
        buffer,
        sizeof(buffer) - 1
      );

    if (len > 0) {
      buffer[len] = '\0';
    }

    String msg(buffer);

    if (
      msg.startsWith(
        "SWIFTWING_MONITOR|ESP8266|"
      )
    ) {
      IPAddress ip;

      if (
        parseIPv4(
          fieldAt(msg, 2),
          ip
        )
      ) {
        monitorIP = ip;
      } else {
        monitorIP =
          monitorStatusUDP.remoteIP();
      }

      monitorUptime =
        fieldAt(msg, 3).toInt();

      monitorRSSI =
        fieldAt(msg, 4).toInt();

      monitorLastSeen =
        millis();

      monitorOnline =
        true;
    }

    packetSize =
      monitorStatusUDP.parsePacket();
  }

  if (
    monitorOnline &&
    millis() - monitorLastSeen >
    SERVICE_TIMEOUT_MS
  ) {
    monitorOnline = false;
  }
}

// =====================================================
// JSON State API
// =====================================================

String storageNodeJson(
  const StorageNode &n
) {
  String s = "{";

  s +=
    "\"id\":\"" +
    jsonEscape(n.id) +
    "\",";

  s +=
    "\"label\":\"" +
    jsonEscape(n.label) +
    "\",";

  s +=
    "\"online\":" +
    String(
      n.online ?
      "true" :
      "false"
    ) +
    ",";

  s +=
    "\"storageReady\":" +
    String(
      n.storageReady ?
      "true" :
      "false"
    ) +
    ",";

  s +=
    "\"ip\":\"" +
    n.ip.toString() +
    "\",";

  s +=
    "\"port\":" +
    String(n.port) +
    ",";

  s +=
    "\"total\":" +
    uint64ToString(
      n.totalBytes
    ) +
    ",";

  s +=
    "\"used\":" +
    uint64ToString(
      n.usedBytes
    ) +
    ",";

  s +=
    "\"free\":" +
    uint64ToString(
      n.freeBytes
    ) +
    ",";

  s +=
    "\"uptime\":" +
    String(
      n.uptimeSeconds
    );

  s += "}";

  return s;
}

void handleState() {
  if (!isAuthenticated()) {
    server.send(
      401,
      "application/json",
      "{\"error\":\"unauthorized\"}"
    );

    return;
  }

  String json;
  json.reserve(1600);

  json = "{";

  json +=
    "\"apiKey\":\"" +
    jsonEscape(
      String(NODE_API_KEY)
    ) +
    "\",";

  json +=
    "\"domain\":\"" +
    jsonEscape(
      String(NAS_DOMAIN)
    ) +
    "\",";

  json +=
    "\"nodes\":{";

  json +=
    "\"NODE1\":" +
    storageNodeJson(node1) +
    ",";

  json +=
    "\"NODE2\":" +
    storageNodeJson(node2);

  json += "},";

  json +=
    "\"services\":{";

  json +=
    "\"master\":{";

  json +=
    "\"label\":\"Master\",";

  json +=
    "\"detail\":\"Control / UI\",";

  json +=
    "\"online\":true,";

  json +=
    "\"ip\":\"" +
    WiFi.localIP().toString() +
    "\",";

  json +=
    "\"uptime\":" +
    String(
      millis() / 1000UL
    );

  json += "},";

  json +=
    "\"dns\":{";

  json +=
    "\"label\":\"C3 DNS\",";

  json +=
    "\"detail\":\"Local DNS\",";

  json +=
    "\"online\":" +
    String(
      c3Online ?
      "true" :
      "false"
    ) +
    ",";

  json +=
    "\"ip\":\"" +
    c3IP.toString() +
    "\",";

  json +=
    "\"uptime\":" +
    String(c3Uptime);

  json += "},";

  json +=
    "\"monitor\":{";

  json +=
    "\"label\":\"ESP8266 Monitor\",";

  json +=
    "\"detail\":\"Monitor / OLED\",";

  json +=
    "\"online\":" +
    String(
      monitorOnline ?
      "true" :
      "false"
    ) +
    ",";

  json +=
    "\"ip\":\"" +
    monitorIP.toString() +
    "\",";

  json +=
    "\"uptime\":" +
    String(
      monitorUptime
    ) +
    ",";

  json +=
    "\"rssi\":" +
    String(
      monitorRSSI
    );

  json += "}";

  json += "}";

  json += "}";

  server.sendHeader(
    "Cache-Control",
    "no-store"
  );

  server.send(
    200,
    "application/json; charset=utf-8",
    json
  );
}

// =====================================================
// Web Routes
// =====================================================

void handleRoot() {
  if (!isAuthenticated()) {
    handleLoginPage();
    return;
  }

  server.send_P(
    200,
    "text/html; charset=utf-8",
    MAIN_PAGE
  );
}

void handleStatusPage() {
  if (!isAuthenticated()) {
    redirectTo("/");
    return;
  }

  server.send_P(
    200,
    "text/html; charset=utf-8",
    STATUS_PAGE
  );
}

// =====================================================
// WiFi
// =====================================================

void connectWiFi() {
  WiFi.mode(WIFI_STA);

  WiFi.setSleep(false);

  WiFi.begin(
    WIFI_SSID,
    WIFI_PASSWORD
  );

  Serial.print(
    "Connecting WiFi"
  );

  while (
    WiFi.status() !=
    WL_CONNECTED
  ) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();

  Serial.print(
    "Master IP: "
  );

  Serial.println(
    WiFi.localIP()
  );
}

// =====================================================
// Setup / Loop
// =====================================================

void setup() {
  Serial.begin(115200);

  delay(500);

  initNode(
    node1,
    "NODE1",
    "Storage Node 1"
  );

  initNode(
    node2,
    "NODE2",
    "Storage Node 2"
  );

  connectWiFi();

  storageUDP.begin(
    STORAGE_DISCOVERY_PORT
  );

  masterAnnounceUDP.begin(
    MASTER_LOCAL_PORT
  );

  dnsStatusUDP.begin(
    DNS_STATUS_PORT
  );

  monitorStatusUDP.begin(
    MONITOR_STATUS_PORT
  );

  const char* headerKeys[] = {
    "Cookie"
  };

  server.collectHeaders(
    headerKeys,
    1
  );

  server.on(
    "/",
    HTTP_GET,
    handleRoot
  );

  server.on(
    "/status",
    HTTP_GET,
    handleStatusPage
  );

  server.on(
    "/api/state",
    HTTP_GET,
    handleState
  );

  server.on(
    "/login",
    HTTP_GET,
    handleLoginPage
  );

  server.on(
    "/login",
    HTTP_POST,
    handleLogin
  );

  server.on(
    "/logout",
    HTTP_GET,
    handleLogout
  );

  server.onNotFound(
    []() {
      if (!isAuthenticated()) {
        redirectTo("/");
        return;
      }

      server.send(
        404,
        "text/plain",
        "Not found"
      );
    }
  );

  server.begin();

  sendStorageDiscovery();

  sendMasterAnnouncement();

  lastDiscovery =
    millis();

  lastMasterAnnouncement =
    millis();

  Serial.println(
    "Swiftwing Master V1.3 ONLINE"
  );

  Serial.print(
    "Files: http://"
  );

  Serial.println(
    WiFi.localIP()
  );

  Serial.print(
    "Status: http://"
  );

  Serial.print(
    WiFi.localIP()
  );

  Serial.println(
    "/status"
  );
}

void loop() {
  server.handleClient();

  processStorageReplies();

  processDNSStatus();

  processMonitorStatus();

  if (
    WiFi.status() !=
    WL_CONNECTED
  ) {
    WiFi.disconnect();

    connectWiFi();
  }

  unsigned long now =
    millis();

  if (
    now - lastDiscovery >=
    DISCOVERY_INTERVAL_MS
  ) {
    lastDiscovery =
      now;

    sendStorageDiscovery();
  }

  if (
    now - lastMasterAnnouncement >=
    MASTER_ANNOUNCE_MS
  ) {
    lastMasterAnnouncement =
      now;

    sendMasterAnnouncement();
  }

  delay(1);
}
