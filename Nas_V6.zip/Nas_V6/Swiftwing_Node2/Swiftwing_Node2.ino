/*
  Swiftwing NAS - STORAGE NODE 2
  Board: ESP32
  Storage: standard SPI microSD module.

  Default wiring:
    microSD CS   -> GPIO 5
    microSD SCK  -> GPIO 18
    microSD MISO -> GPIO 19
    microSD MOSI -> GPIO 23
    VCC/GND as appropriate for your module.

  If Node 2 has no microSD connected yet, the node still boots and
  appears in Master as "Storage not ready".
*/

#include <SPI.h>
#include <SD.h>

const char* NODE_ID    = "NODE2";
const char* NODE_LABEL = "Storage Node 2";

// Defined in the shared node implementation below.
extern bool storageReady;

const int SD_CS   = 5;
const int SD_SCK  = 18;
const int SD_MISO = 19;
const int SD_MOSI = 23;

bool beginStorage() {
  SPI.begin(SD_SCK, SD_MISO, SD_MOSI, SD_CS);

  // 40 MHz first; fallback to 20 MHz for modules/cards that are less stable.
  if (SD.begin(SD_CS, SPI, 40000000)) {
    return true;
  }

  SD.end();
  delay(100);

  return SD.begin(SD_CS, SPI, 20000000);
}

fs::FS& store() {
  return SD;
}

uint64_t storageTotal() {
  return storageReady ? SD.totalBytes() : 0;
}

uint64_t storageUsed() {
  return storageReady ? SD.usedBytes() : 0;
}


#include <WiFi.h>
#include <WebServer.h>
#include <WiFiUdp.h>
#include "FS.h"

// =====================================================
// CONFIG
// =====================================================

const char* WIFI_SSID     = "BaBaWu";
const char* WIFI_PASSWORD = "95042700Wu$";

// Must match Master and the other storage node.
const char* NODE_API_KEY  = "BaBaWu";

const uint16_t HTTP_PORT              = 80;
const uint16_t STORAGE_DISCOVERY_PORT = 4210;

WebServer server(HTTP_PORT);
WiFiUDP discoveryUDP;

bool storageReady = false;

File uploadFile;
bool uploadAccepted = false;
int uploadFinalStatus = 200;
String uploadFinalMessage = "OK";

static uint8_t downloadBuffer[8192];

// =====================================================
// Utility
// =====================================================

String normalizePath(String path) {
  path.trim();

  if (path.length() == 0) path = "/";
  if (!path.startsWith("/")) path = "/" + path;

  while (path.indexOf("//") >= 0) path.replace("//", "/");

  if (path.length() > 1 && path.endsWith("/")) {
    path.remove(path.length() - 1);
  }

  if (path.indexOf("..") >= 0) return "/";

  return path;
}

String fileNameOnly(String path) {
  int i = path.lastIndexOf('/');
  if (i < 0) return path;
  return path.substring(i + 1);
}

String parentPath(String path) {
  path = normalizePath(path);
  if (path == "/") return "/";

  int i = path.lastIndexOf('/');
  if (i <= 0) return "/";

  return path.substring(0, i);
}

String joinPath(String folder, String name) {
  folder = normalizePath(folder);
  if (folder == "/") return "/" + name;
  return folder + "/" + name;
}

bool validSimpleName(String name) {
  name.trim();

  if (name.length() == 0) return false;
  if (name.indexOf("/") >= 0) return false;
  if (name.indexOf("\\") >= 0) return false;
  if (name.indexOf("..") >= 0) return false;

  return true;
}

bool hiddenName(const String &name) {
  return (
    name == "System Volume Information" ||
    name == "$RECYCLE.BIN" ||
    name == ".Trashes" ||
    name == ".Spotlight-V100" ||
    name == ".fseventsd"
  );
}

String jsonEscape(String s) {
  s.replace("\\", "\\\\");
  s.replace("\"", "\\\"");
  s.replace("\r", "\\r");
  s.replace("\n", "\\n");
  return s;
}

String extensionOf(String name) {
  int dot = name.lastIndexOf('.');
  if (dot < 0 || dot == name.length() - 1) return "";
  String ext = name.substring(dot + 1);
  ext.toUpperCase();
  return ext;
}

String contentType(String name) {
  String lower = name;
  lower.toLowerCase();

  if (lower.endsWith(".pdf")) return "application/pdf";
  if (lower.endsWith(".txt")) return "text/plain";
  if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
  if (lower.endsWith(".png")) return "image/png";
  if (lower.endsWith(".gif")) return "image/gif";
  if (lower.endsWith(".zip")) return "application/zip";
  if (lower.endsWith(".mp3")) return "audio/mpeg";
  if (lower.endsWith(".mp4")) return "video/mp4";
  if (lower.endsWith(".json")) return "application/json";
  if (lower.endsWith(".csv")) return "text/csv";

  return "application/octet-stream";
}

bool authorized() {
  return server.hasArg("key") && server.arg("key") == NODE_API_KEY;
}

void cors() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Content-Type");
  server.sendHeader("Cache-Control", "no-store");
}

void sendText(int code, const String &text) {
  cors();
  server.send(code, "text/plain; charset=utf-8", text);
}

void sendJson(int code, const String &json) {
  cors();
  server.send(code, "application/json; charset=utf-8", json);
}

bool requireAPI() {
  if (!authorized()) {
    sendText(401, "Unauthorized");
    return false;
  }

  if (!storageReady) {
    sendText(503, "Storage not ready");
    return false;
  }

  return true;
}

// =====================================================
// Storage-specific functions supplied per node
// =====================================================

// bool beginStorage()
// fs::FS& store()
// uint64_t storageTotal()
// uint64_t storageUsed()

uint64_t storageFree() {
  uint64_t total = storageTotal();
  uint64_t used = storageUsed();
  return total >= used ? total - used : 0;
}

// =====================================================
// Node discovery
// =====================================================

void sendDiscoveryReply(IPAddress remoteIP, uint16_t remotePort) {
  String response =
    String("SWIFTWING_STORAGE|") +
    NODE_ID +
    "|" +
    WiFi.localIP().toString() +
    "|" +
    String(HTTP_PORT) +
    "|" +
    String(storageReady ? 1 : 0) +
    "|" +
    String((unsigned long long)storageTotal()) +
    "|" +
    String((unsigned long long)storageUsed()) +
    "|" +
    String((unsigned long long)storageFree()) +
    "|" +
    String(millis() / 1000UL);

  discoveryUDP.beginPacket(remoteIP, remotePort);
  discoveryUDP.print(response);
  discoveryUDP.endPacket();
}

void processDiscovery() {
  int packetSize = discoveryUDP.parsePacket();

  while (packetSize) {
    char buffer[160];

    int len = discoveryUDP.read(buffer, sizeof(buffer) - 1);
    if (len > 0) buffer[len] = '\0';

    String msg(buffer);

    if (msg.startsWith("SWIFTWING_DISCOVER|")) {
      sendDiscoveryReply(discoveryUDP.remoteIP(), discoveryUDP.remotePort());
    }

    packetSize = discoveryUDP.parsePacket();
  }
}

// =====================================================
// File listing + search
// =====================================================

String itemJson(const String &path, const String &name, bool directory, uint64_t size) {
  String s = "{";
  s += "\"name\":\"" + jsonEscape(name) + "\",";
  s += "\"path\":\"" + jsonEscape(path) + "\",";
  s += "\"directory\":" + String(directory ? "true" : "false") + ",";
  s += "\"size\":" + String((unsigned long long)size) + ",";
  s += "\"ext\":\"" + jsonEscape(directory ? "" : extensionOf(name)) + "\"";
  s += "}";
  return s;
}

void handleList() {
  if (!requireAPI()) return;

  String path = server.hasArg("path") ? normalizePath(server.arg("path")) : "/";

  File dir = store().open(path);

  if (!dir || !dir.isDirectory()) {
    if (dir) dir.close();
    sendText(404, "Folder not found");
    return;
  }

  String folders = "";
  String files = "";
  int folderCount = 0;
  int fileCount = 0;
  int totalCount = 0;
  bool truncated = false;

  File item = dir.openNextFile();

  while (item) {
    if (totalCount >= 250) {
      truncated = true;
      item.close();
      break;
    }

    String fullPath = String(item.path());
    String name = fileNameOnly(fullPath);

    if (!hiddenName(name)) {
      bool isDir = item.isDirectory();
      uint64_t size = isDir ? 0 : item.size();

      String entry = itemJson(fullPath, name, isDir, size);

      if (isDir) {
        if (folderCount++) folders += ",";
        folders += entry;
      } else {
        if (fileCount++) files += ",";
        files += entry;
      }

      totalCount++;
    }

    item.close();
    item = dir.openNextFile();
  }

  dir.close();

  String json = "{";
  json += "\"node\":\"" + String(NODE_ID) + "\",";
  json += "\"path\":\"" + jsonEscape(path) + "\",";
  json += "\"truncated\":" + String(truncated ? "true" : "false") + ",";
  json += "\"items\":[" + folders;
  if (folderCount && fileCount) json += ",";
  json += files + "]}";

  sendJson(200, json);
}

void searchRecursive(
  const String &path,
  const String &queryLower,
  String &result,
  int &count,
  int depth
) {
  if (depth > 12 || count >= 100) return;

  File dir = store().open(path);
  if (!dir || !dir.isDirectory()) {
    if (dir) dir.close();
    return;
  }

  File item = dir.openNextFile();

  while (item && count < 100) {
    String fullPath = String(item.path());
    String name = fileNameOnly(fullPath);
    bool isDir = item.isDirectory();
    uint64_t size = isDir ? 0 : item.size();

    item.close();

    if (!hiddenName(name)) {
      String lower = name;
      lower.toLowerCase();

      if (lower.indexOf(queryLower) >= 0) {
        if (count++) result += ",";
        result += itemJson(fullPath, name, isDir, size);
      }

      if (isDir) {
        searchRecursive(fullPath, queryLower, result, count, depth + 1);
      }
    }

    item = dir.openNextFile();
  }

  dir.close();
}

void handleSearch() {
  if (!requireAPI()) return;
  if (!server.hasArg("q")) {
    sendText(400, "Missing q");
    return;
  }

  String q = server.arg("q");
  q.trim();
  q.toLowerCase();

  if (q.length() == 0) {
    sendText(400, "Empty search");
    return;
  }

  String items = "";
  int count = 0;

  searchRecursive("/", q, items, count, 0);

  String json = "{";
  json += "\"node\":\"" + String(NODE_ID) + "\",";
  json += "\"count\":" + String(count) + ",";
  json += "\"items\":[" + items + "]}";

  sendJson(200, json);
}

// =====================================================
// Mutating operations
// =====================================================

void handleMkdir() {
  if (!requireAPI()) return;
  if (!server.hasArg("name")) {
    sendText(400, "Missing name");
    return;
  }

  String parent = server.hasArg("path") ? normalizePath(server.arg("path")) : "/";
  String name = server.arg("name");
  name.trim();

  if (!validSimpleName(name)) {
    sendText(400, "Invalid folder name");
    return;
  }

  String target = joinPath(parent, name);

  if (store().exists(target)) {
    sendText(409, "Already exists");
    return;
  }

  if (!store().mkdir(target)) {
    sendText(500, "mkdir failed");
    return;
  }

  sendJson(200, "{\"ok\":true}");
}

void handleDelete() {
  if (!requireAPI()) return;
  if (!server.hasArg("path")) {
    sendText(400, "Missing path");
    return;
  }

  String path = normalizePath(server.arg("path"));

  if (path == "/") {
    sendText(403, "Cannot delete root");
    return;
  }

  File item = store().open(path);

  if (!item) {
    sendText(404, "Not found");
    return;
  }

  bool isDir = item.isDirectory();
  item.close();

  bool ok = isDir ? store().rmdir(path) : store().remove(path);

  if (!ok) {
    sendText(500, isDir ? "Delete failed. Folder may not be empty." : "Delete failed");
    return;
  }

  sendJson(200, "{\"ok\":true}");
}

void handleRename() {
  if (!requireAPI()) return;
  if (!server.hasArg("path") || !server.hasArg("name")) {
    sendText(400, "Missing parameter");
    return;
  }

  String oldPath = normalizePath(server.arg("path"));
  String newName = server.arg("name");
  newName.trim();

  if (oldPath == "/" || !validSimpleName(newName)) {
    sendText(400, "Invalid rename");
    return;
  }

  String newPath = joinPath(parentPath(oldPath), newName);

  if (store().exists(newPath)) {
    sendText(409, "Destination already exists");
    return;
  }

  if (!store().rename(oldPath, newPath)) {
    sendText(500, "Rename failed");
    return;
  }

  sendJson(200, "{\"ok\":true}");
}

void handleMove() {
  if (!requireAPI()) return;
  if (!server.hasArg("path") || !server.hasArg("dest")) {
    sendText(400, "Missing parameter");
    return;
  }

  String oldPath = normalizePath(server.arg("path"));
  String dest = normalizePath(server.arg("dest"));

  if (oldPath == "/") {
    sendText(403, "Cannot move root");
    return;
  }

  File destFolder = store().open(dest);
  if (!destFolder || !destFolder.isDirectory()) {
    if (destFolder) destFolder.close();
    sendText(400, "Destination folder does not exist");
    return;
  }
  destFolder.close();

  File source = store().open(oldPath);
  if (!source) {
    sendText(404, "Source not found");
    return;
  }

  bool sourceIsDir = source.isDirectory();
  source.close();

  if (sourceIsDir && (dest == oldPath || dest.startsWith(oldPath + "/"))) {
    sendText(400, "Cannot move a folder into itself");
    return;
  }

  String newPath = joinPath(dest, fileNameOnly(oldPath));

  if (newPath == oldPath) {
    sendJson(200, "{\"ok\":true}");
    return;
  }

  if (store().exists(newPath)) {
    sendText(409, "Destination already contains this name");
    return;
  }

  if (!store().rename(oldPath, newPath)) {
    sendText(500, "Move failed");
    return;
  }

  sendJson(200, "{\"ok\":true}");
}

// =====================================================
// Download
// =====================================================

void handleDownload() {
  if (!requireAPI()) return;
  if (!server.hasArg("path")) {
    sendText(400, "Missing path");
    return;
  }

  String path = normalizePath(server.arg("path"));

  File file = store().open(path, FILE_READ);

  if (!file || file.isDirectory()) {
    if (file) file.close();
    sendText(404, "File not found");
    return;
  }

  String name = fileNameOnly(path);
  size_t fileSize = file.size();

  cors();
  server.sendHeader(
    "Content-Disposition",
    "attachment; filename=\"" + name + "\""
  );
  server.setContentLength(fileSize);
  server.send(200, contentType(name), "");

  WiFiClient client = server.client();

  while (file.available() && client.connected()) {
    size_t n = file.read(downloadBuffer, sizeof(downloadBuffer));

    if (n == 0) break;

    size_t sent = 0;
    while (sent < n && client.connected()) {
      size_t written = client.write(downloadBuffer + sent, n - sent);
      if (written == 0) {
        delay(1);
        continue;
      }
      sent += written;
    }

    yield();
  }

  file.close();
}

// =====================================================
// Upload
// =====================================================

void uploadHandler() {
  HTTPUpload &upload = server.upload();

  if (upload.status == UPLOAD_FILE_START) {
    uploadAccepted = false;
    uploadFinalStatus = 200;
    uploadFinalMessage = "OK";

    if (!authorized()) {
      uploadFinalStatus = 401;
      uploadFinalMessage = "Unauthorized";
      return;
    }

    if (!storageReady) {
      uploadFinalStatus = 503;
      uploadFinalMessage = "Storage not ready";
      return;
    }

    String folder = server.hasArg("path") ? normalizePath(server.arg("path")) : "/";

    String filename = upload.filename;
    filename.replace("\\", "/");

    int slash = filename.lastIndexOf('/');
    if (slash >= 0) filename = filename.substring(slash + 1);

    if (!validSimpleName(filename)) {
      uploadFinalStatus = 400;
      uploadFinalMessage = "Invalid filename";
      return;
    }

    String target = joinPath(folder, filename);

    if (store().exists(target)) store().remove(target);

    uploadFile = store().open(target, FILE_WRITE);

    if (!uploadFile) {
      uploadFinalStatus = 500;
      uploadFinalMessage = "Cannot create destination file";
      return;
    }

    uploadAccepted = true;
  }

  else if (upload.status == UPLOAD_FILE_WRITE) {
    if (uploadAccepted && uploadFile) {
      size_t written = uploadFile.write(upload.buf, upload.currentSize);

      if (written != upload.currentSize) {
        uploadFinalStatus = 500;
        uploadFinalMessage = "Storage write failed";
        uploadAccepted = false;
      }
    }
  }

  else if (upload.status == UPLOAD_FILE_END) {
    if (uploadFile) uploadFile.close();
  }

  else if (upload.status == UPLOAD_FILE_ABORTED) {
    if (uploadFile) uploadFile.close();
    uploadFinalStatus = 499;
    uploadFinalMessage = "Upload aborted";
    uploadAccepted = false;
  }
}

void uploadFinished() {
  cors();

  if (uploadFinalStatus == 200 && uploadAccepted) {
    server.send(200, "application/json", "{\"ok\":true}");
  } else {
    server.send(uploadFinalStatus, "text/plain", uploadFinalMessage);
  }

  uploadAccepted = false;
}

// =====================================================
// Info + diagnostic page
// =====================================================

void handleInfo() {
  String json = "{";
  json += "\"id\":\"" + String(NODE_ID) + "\",";
  json += "\"label\":\"" + String(NODE_LABEL) + "\",";
  json += "\"ip\":\"" + WiFi.localIP().toString() + "\",";
  json += "\"ready\":" + String(storageReady ? "true" : "false") + ",";
  json += "\"total\":" + String((unsigned long long)storageTotal()) + ",";
  json += "\"used\":" + String((unsigned long long)storageUsed()) + ",";
  json += "\"free\":" + String((unsigned long long)storageFree()) + ",";
  json += "\"uptime\":" + String(millis() / 1000UL);
  json += "}";

  sendJson(200, json);
}

void handleRoot() {
  String text =
    String("Swiftwing ") + NODE_LABEL +
    "\nIP: " + WiFi.localIP().toString() +
    "\nStorage: " + (storageReady ? "READY" : "NOT READY") +
    "\nUse the Master UI for file management.\n";

  sendText(200, text);
}

void handleOptions() {
  cors();
  server.send(204, "text/plain", "");
}

// =====================================================
// Setup / loop
// =====================================================

void connectWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  Serial.print("Connecting WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.print(NODE_LABEL);
  Serial.print(" IP: ");
  Serial.println(WiFi.localIP());
}

void setupNode() {
  Serial.begin(115200);
  delay(500);

  connectWiFi();

  storageReady = beginStorage();

  Serial.print("Storage: ");
  Serial.println(storageReady ? "READY" : "NOT READY");

  discoveryUDP.begin(STORAGE_DISCOVERY_PORT);

  server.on("/", HTTP_GET, handleRoot);
  server.on("/api/info", HTTP_GET, handleInfo);
  server.on("/api/list", HTTP_GET, handleList);
  server.on("/api/search", HTTP_GET, handleSearch);

  server.on("/api/mkdir", HTTP_POST, handleMkdir);
  server.on("/api/delete", HTTP_POST, handleDelete);
  server.on("/api/rename", HTTP_POST, handleRename);
  server.on("/api/move", HTTP_POST, handleMove);

  server.on("/download", HTTP_GET, handleDownload);

  server.on(
    "/upload",
    HTTP_POST,
    uploadFinished,
    uploadHandler
  );

  server.onNotFound([]() {
    if (server.method() == HTTP_OPTIONS) {
      handleOptions();
      return;
    }
    sendText(404, "Not found");
  });

  server.begin();

  Serial.print(NODE_LABEL);
  Serial.println(" ONLINE");
}

void loopNode() {
  server.handleClient();
  processDiscovery();

  if (WiFi.status() != WL_CONNECTED) {
    WiFi.disconnect();
    connectWiFi();
  }

  delay(1);
}


void setup() {
  setupNode();
}

void loop() {
  loopNode();
}
