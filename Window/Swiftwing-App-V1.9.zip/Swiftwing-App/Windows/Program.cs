using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace SwiftwingNas
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }

    internal sealed class MainForm : Form
    {
        private const string DefaultBaseUrl = "http://swiftwingnas.tplinkdns.com/";
        private const string AccessPointUrl = "http://192.168.4.1/";

        private readonly Color _navy = Color.FromArgb(19, 32, 46);
        private readonly Color _panel = Color.FromArgb(29, 45, 61);
        private readonly Color _cyan = Color.FromArgb(46, 194, 215);
        private readonly WebView2 _webView;
        private readonly TextBox _address;
        private readonly Label _status;
        private readonly Panel _cover;
        private readonly Label _coverTitle;
        private readonly Label _coverText;
        private readonly Button _back;
        private readonly Button _forward;
        private readonly Button _refresh;

        private string _baseUrl;
        private string _lastAttemptedUrl;
        private bool _ready;
        private bool _hasSuccessfulPage;
        private bool _downloadStarted;

        private static string SettingsPath
        {
            get
            {
                return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    "Swiftwing NAS", "settings.txt");
            }
        }

        public MainForm()
        {
            _baseUrl = ReadBaseUrl();
            _lastAttemptedUrl = _baseUrl;

            Text = "Swiftwing NAS";
            Size = new Size(1160, 760);
            MinimumSize = new Size(820, 520);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = _navy;
            Font = new Font("Microsoft YaHei UI", 9F);
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); }
            catch { /* The embedded EXE icon is optional during source builds. */ }

            TableLayoutPanel shell = new TableLayoutPanel();
            shell.Dock = DockStyle.Fill;
            shell.BackColor = _navy;
            shell.Margin = Padding.Empty;
            shell.Padding = Padding.Empty;
            shell.RowCount = 3;
            shell.ColumnCount = 1;
            shell.RowStyles.Add(new RowStyle(SizeType.Absolute, 58));
            shell.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            shell.RowStyles.Add(new RowStyle(SizeType.Absolute, 28));
            shell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            Controls.Add(shell);

            TableLayoutPanel toolbar = new TableLayoutPanel();
            toolbar.Dock = DockStyle.Fill;
            toolbar.BackColor = _navy;
            toolbar.Padding = new Padding(12, 10, 12, 10);
            toolbar.Margin = Padding.Empty;
            toolbar.ColumnCount = 9;
            toolbar.RowCount = 1;
            toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 152));
            toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 40));
            toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 40));
            toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 40));
            toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 68));
            toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 54));
            toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 96));
            toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 92));
            shell.Controls.Add(toolbar, 0, 0);

            Label brand = new Label();
            brand.Text = "SWIFTWING  NAS";
            brand.ForeColor = _cyan;
            brand.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            brand.Dock = DockStyle.Fill;
            brand.TextAlign = ContentAlignment.MiddleLeft;
            brand.Margin = Padding.Empty;
            toolbar.Controls.Add(brand, 0, 0);

            _back = ToolbarButton("‹", "后退");
            _forward = ToolbarButton("›", "前进");
            _refresh = ToolbarButton("↻", "刷新");
            Button home = ToolbarButton("主页", "返回已保存的服务器地址");
            _back.Click += delegate { if (_ready && _webView.CanGoBack) _webView.GoBack(); };
            _forward.Click += delegate { if (_ready && _webView.CanGoForward) _webView.GoForward(); };
            _refresh.Click += delegate { Retry(); };
            home.Click += delegate { Navigate(_baseUrl); };
            toolbar.Controls.Add(_back, 1, 0);
            toolbar.Controls.Add(_forward, 2, 0);
            toolbar.Controls.Add(_refresh, 3, 0);
            toolbar.Controls.Add(home, 4, 0);

            _address = new TextBox();
            _address.Dock = DockStyle.Fill;
            _address.BorderStyle = BorderStyle.FixedSingle;
            _address.Font = new Font("Segoe UI", 10F);
            _address.BackColor = Color.FromArgb(238, 246, 248);
            _address.ForeColor = _navy;
            _address.Margin = new Padding(6, 6, 6, 5);
            _address.Text = _baseUrl;
            _address.KeyDown += delegate(object sender, KeyEventArgs e)
            {
                if (e.KeyCode == Keys.Enter)
                {
                    e.SuppressKeyPress = true;
                    OpenAddress();
                }
            };
            toolbar.Controls.Add(_address, 5, 0);

            Button go = ToolbarButton("打开", "打开地址栏中的地址");
            go.Click += delegate { OpenAddress(); };
            toolbar.Controls.Add(go, 6, 0);

            Button hotspot = ToolbarButton("设备热点", "打开 192.168.4.1");
            hotspot.Click += delegate { Navigate(AccessPointUrl); };
            toolbar.Controls.Add(hotspot, 7, 0);

            Button settings = ToolbarButton("服务器", "修改并保存主页地址");
            settings.Click += delegate { EditServer(); };
            toolbar.Controls.Add(settings, 8, 0);

            Panel content = new Panel();
            content.Dock = DockStyle.Fill;
            content.BackColor = Color.White;
            content.Margin = Padding.Empty;
            shell.Controls.Add(content, 0, 1);

            _webView = new WebView2();
            _webView.Dock = DockStyle.Fill;
            _webView.DefaultBackgroundColor = Color.White;
            content.Controls.Add(_webView);

            _cover = new Panel();
            _cover.Dock = DockStyle.Fill;
            _cover.BackColor = Color.FromArgb(238, 246, 248);
            content.Controls.Add(_cover);
            _cover.BringToFront();

            TableLayoutPanel coverLayout = new TableLayoutPanel();
            coverLayout.Dock = DockStyle.Fill;
            coverLayout.RowCount = 5;
            coverLayout.ColumnCount = 1;
            coverLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 36));
            coverLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 54));
            coverLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 84));
            coverLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 55));
            coverLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 64));
            coverLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            _cover.Controls.Add(coverLayout);

            _coverTitle = new Label();
            _coverTitle.Text = "正在连接 Swiftwing NAS";
            _coverTitle.Font = new Font("Microsoft YaHei UI", 19F, FontStyle.Bold);
            _coverTitle.ForeColor = _navy;
            _coverTitle.TextAlign = ContentAlignment.MiddleCenter;
            _coverTitle.Dock = DockStyle.Fill;
            coverLayout.Controls.Add(_coverTitle, 0, 1);

            _coverText = new Label();
            _coverText.Text = "请稍候…";
            _coverText.Font = new Font("Microsoft YaHei UI", 10F);
            _coverText.ForeColor = Color.FromArgb(75, 94, 108);
            _coverText.TextAlign = ContentAlignment.TopCenter;
            _coverText.Dock = DockStyle.Fill;
            _coverText.AutoEllipsis = true;
            coverLayout.Controls.Add(_coverText, 0, 2);

            FlowLayoutPanel recovery = new FlowLayoutPanel();
            recovery.Dock = DockStyle.Fill;
            recovery.FlowDirection = FlowDirection.LeftToRight;
            recovery.WrapContents = false;
            recovery.AutoSize = false;
            recovery.Anchor = AnchorStyles.None;
            recovery.Width = 310;
            recovery.Height = 45;
            Button retry = RecoveryButton("重试");
            retry.Click += delegate { Retry(); };
            Button ap = RecoveryButton("设备热点");
            ap.Click += delegate { Navigate(AccessPointUrl); };
            Button change = RecoveryButton("修改地址");
            change.Click += delegate { EditServer(); };
            recovery.Controls.Add(retry);
            recovery.Controls.Add(ap);
            recovery.Controls.Add(change);
            coverLayout.Controls.Add(recovery, 0, 3);

            _status = new Label();
            _status.Text = "准备连接";
            _status.ForeColor = Color.FromArgb(181, 201, 211);
            _status.BackColor = _panel;
            _status.Padding = new Padding(14, 0, 0, 0);
            _status.TextAlign = ContentAlignment.MiddleLeft;
            _status.Dock = DockStyle.Fill;
            _status.Margin = Padding.Empty;
            shell.Controls.Add(_status, 0, 2);

            UpdateButtons();
            Shown += async delegate { await InitializeWebViewAsync(); };
        }

        private Button ToolbarButton(string text, string tooltip)
        {
            Button b = new Button();
            b.Text = text;
            b.Dock = DockStyle.Fill;
            b.Margin = new Padding(2, 0, 2, 0);
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.BackColor = _panel;
            b.ForeColor = Color.White;
            b.Cursor = Cursors.Hand;
            new ToolTip().SetToolTip(b, tooltip);
            return b;
        }

        private Button RecoveryButton(string text)
        {
            Button b = new Button();
            b.Text = text;
            b.Size = new Size(96, 38);
            b.Margin = new Padding(3, 1, 3, 1);
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.BackColor = _navy;
            b.ForeColor = Color.White;
            b.Cursor = Cursors.Hand;
            return b;
        }

        private async Task InitializeWebViewAsync()
        {
            try
            {
                string dataFolder = Path.Combine(Environment.GetFolderPath(
                    Environment.SpecialFolder.LocalApplicationData), "Swiftwing NAS", "WebView2");
                Directory.CreateDirectory(dataFolder);
                CoreWebView2Environment environment = await CoreWebView2Environment.CreateAsync(null, dataFolder);
                await _webView.EnsureCoreWebView2Async(environment);

                CoreWebView2 core = _webView.CoreWebView2;
                core.Settings.AreDefaultScriptDialogsEnabled = true;
                core.Settings.AreDevToolsEnabled = false;
                core.Settings.IsPasswordAutosaveEnabled = false;
                core.Settings.IsGeneralAutofillEnabled = false;
                core.NavigationStarting += delegate(object sender, CoreWebView2NavigationStartingEventArgs e)
                {
                    _downloadStarted = false;
                    _lastAttemptedUrl = e.Uri;
                    _status.Text = "正在打开 " + e.Uri;
                    if (!_hasSuccessfulPage)
                    {
                        _coverTitle.Text = "正在连接 Swiftwing NAS";
                        _coverText.Text = e.Uri;
                        _cover.Visible = true;
                    }
                };
                core.NavigationCompleted += delegate(object sender, CoreWebView2NavigationCompletedEventArgs e)
                {
                    if (e.IsSuccess)
                    {
                        _hasSuccessfulPage = true;
                        _cover.Visible = false;
                        _status.Text = "已连接  ·  " + _webView.Source;
                    }
                    else if (_downloadStarted && e.WebErrorStatus == CoreWebView2WebErrorStatus.OperationCanceled)
                    {
                        // Attachment responses may cancel navigation after DownloadStarting.
                        _cover.Visible = false;
                    }
                    else
                    {
                        _coverTitle.Text = "无法打开页面";
                        _coverText.Text = "请检查网络和服务器地址，然后重试。\r\n" +
                            _lastAttemptedUrl + "\r\n" + e.WebErrorStatus;
                        _cover.Visible = true;
                        _cover.BringToFront();
                        _status.Text = "连接失败  ·  " + e.WebErrorStatus;
                    }
                    _downloadStarted = false;
                    UpdateButtons();
                };
                core.SourceChanged += delegate
                {
                    if (_webView.Source != null) _address.Text = _webView.Source.ToString();
                    UpdateButtons();
                };
                core.HistoryChanged += delegate { UpdateButtons(); };
                core.DownloadStarting += OnDownloadStarting;
                core.NewWindowRequested += delegate(object sender, CoreWebView2NewWindowRequestedEventArgs e)
                {
                    // Keep ordinary links and NAS node downloads inside this window.
                    e.Handled = true;
                    string target = e.Uri;
                    if (!string.IsNullOrWhiteSpace(target))
                    {
                        BeginInvoke(new Action(delegate { Navigate(target); }));
                    }
                };
                core.ProcessFailed += delegate(object sender, CoreWebView2ProcessFailedEventArgs e)
                {
                    if (e.ProcessFailedKind == CoreWebView2ProcessFailedKind.BrowserProcessExited ||
                        e.ProcessFailedKind == CoreWebView2ProcessFailedKind.RenderProcessExited)
                    {
                        _coverTitle.Text = "浏览器组件需要重新启动";
                        _coverText.Text = "WebView2 进程已停止。请关闭并重新打开 Swiftwing NAS。";
                        _cover.Visible = true;
                        _cover.BringToFront();
                    }
                    _status.Text = "WebView2 进程异常  ·  " + e.ProcessFailedKind;
                };

                _ready = true;
                UpdateButtons();
                string initial = _baseUrl;
                string[] args = Environment.GetCommandLineArgs();
                string overrideUrl;
                if (args.Length > 1 && TryNavigationUrl(args[1], out overrideUrl)) initial = overrideUrl;
                Navigate(initial);
            }
            catch (Exception ex)
            {
                _coverTitle.Text = "无法启动浏览器组件";
                _coverText.Text = "请安装或修复 Microsoft Edge WebView2 Runtime 后重新打开。\r\n" + ex.Message;
                _cover.Visible = true;
                _cover.BringToFront();
                _status.Text = "WebView2 初始化失败";
            }
        }

        private void OnDownloadStarting(object sender, CoreWebView2DownloadStartingEventArgs e)
        {
            _downloadStarted = true;
            // WebView2 requires a deferral when host UI is shown for this event.
            CoreWebView2Deferral deferral = e.GetDeferral();
            try
            {
                BeginInvoke(new Action(delegate
                {
                    try
                    {
                        using (SaveFileDialog save = new SaveFileDialog())
                        {
                            string proposed = Path.GetFileName(e.ResultFilePath);
                            save.FileName = string.IsNullOrWhiteSpace(proposed) ? "download" : proposed;
                            save.Filter = "所有文件 (*.*)|*.*";
                            save.OverwritePrompt = true;
                            string downloads = Path.Combine(Environment.GetFolderPath(
                                Environment.SpecialFolder.UserProfile), "Downloads");
                            if (Directory.Exists(downloads)) save.InitialDirectory = downloads;
                            if (save.ShowDialog(this) == DialogResult.OK)
                            {
                                e.ResultFilePath = Path.GetFullPath(save.FileName);
                                e.Handled = true;
                                _status.Text = "下载至  " + e.ResultFilePath;
                            }
                            else
                            {
                                e.Cancel = true;
                                e.Handled = true;
                                _status.Text = "已取消下载";
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        e.Cancel = true;
                        e.Handled = true;
                        _status.Text = "下载失败  ·  " + ex.Message;
                    }
                    finally { deferral.Complete(); }
                }));
            }
            catch
            {
                e.Cancel = true;
                deferral.Complete();
            }
        }

        private void OpenAddress()
        {
            string url;
            if (!TryNavigationUrl(_address.Text, out url))
            {
                MessageBox.Show(this, "请输入有效的 http:// 或 https:// 地址。", "地址无效",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            Navigate(url);
        }

        private void Navigate(string url)
        {
            string valid;
            if (!TryNavigationUrl(url, out valid)) return;
            _lastAttemptedUrl = valid;
            _address.Text = valid;
            _status.Text = "正在打开 " + valid;
            if (!_ready)
            {
                _coverTitle.Text = "正在准备浏览器组件";
                _coverText.Text = valid;
                _cover.Visible = true;
                return;
            }
            _cover.Visible = false;
            _webView.CoreWebView2.Navigate(valid);
        }

        private void Retry()
        {
            if (!_ready) return;
            string target = string.IsNullOrWhiteSpace(_lastAttemptedUrl) ? _baseUrl : _lastAttemptedUrl;
            Navigate(target);
        }

        private void EditServer()
        {
            using (ServerDialog dialog = new ServerDialog(_baseUrl))
            {
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                _baseUrl = dialog.BaseUrl;
                try
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(SettingsPath));
                    File.WriteAllText(SettingsPath, _baseUrl, new UTF8Encoding(false));
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "地址可以在本次使用，但保存失败：\r\n" + ex.Message,
                        "无法保存设置", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                Navigate(_baseUrl);
            }
        }

        private void UpdateButtons()
        {
            _back.Enabled = _ready && _webView.CanGoBack;
            _forward.Enabled = _ready && _webView.CanGoForward;
            _refresh.Enabled = _ready;
        }

        private static string ReadBaseUrl()
        {
            try
            {
                if (File.Exists(SettingsPath))
                {
                    string normalized;
                    if (TryBaseUrl(File.ReadAllText(SettingsPath).Trim(), out normalized))
                        return normalized;
                }
            }
            catch { /* A missing or unreadable setting falls back to the shipped URL. */ }
            return DefaultBaseUrl;
        }

        internal static bool TryNavigationUrl(string value, out string url)
        {
            url = null;
            if (string.IsNullOrWhiteSpace(value)) return false;
            value = value.Trim();
            if (value.IndexOf("://", StringComparison.Ordinal) < 0) value = "http://" + value;
            Uri uri;
            if (!Uri.TryCreate(value, UriKind.Absolute, out uri)) return false;
            if (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps) return false;
            if (string.IsNullOrEmpty(uri.Host) || !string.IsNullOrEmpty(uri.UserInfo)) return false;
            url = uri.AbsoluteUri;
            return true;
        }

        internal static bool TryBaseUrl(string value, out string url)
        {
            url = null;
            string navigation;
            if (!TryNavigationUrl(value, out navigation)) return false;
            Uri uri = new Uri(navigation);
            url = uri.GetLeftPart(UriPartial.Authority).TrimEnd('/') + "/";
            return true;
        }
    }

    internal sealed class ServerDialog : Form
    {
        private readonly TextBox _input;
        public string BaseUrl { get; private set; }

        public ServerDialog(string current)
        {
            Text = "服务器地址";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ClientSize = new Size(530, 190);
            Font = new Font("Microsoft YaHei UI", 9F);
            BackColor = Color.FromArgb(238, 246, 248);
            BaseUrl = current;

            Label heading = new Label();
            heading.Text = "Swiftwing NAS 主页地址";
            heading.Font = new Font("Microsoft YaHei UI", 11F, FontStyle.Bold);
            heading.SetBounds(22, 18, 460, 28);
            Controls.Add(heading);

            _input = new TextBox();
            _input.Text = current;
            _input.Font = new Font("Segoe UI", 11F);
            _input.SetBounds(22, 56, 484, 29);
            Controls.Add(_input);

            Label hint = new Label();
            hint.Text = "支持 http:// 或 https://。只保存协议、主机名和端口；路径不会保存。";
            hint.ForeColor = Color.FromArgb(74, 90, 102);
            hint.SetBounds(22, 94, 484, 30);
            Controls.Add(hint);

            Button cancel = new Button();
            cancel.Text = "取消";
            cancel.DialogResult = DialogResult.Cancel;
            cancel.SetBounds(320, 142, 88, 32);
            Controls.Add(cancel);

            Button save = new Button();
            save.Text = "保存并打开";
            save.SetBounds(413, 142, 93, 32);
            save.Click += delegate
            {
                string normalized;
                if (!MainForm.TryBaseUrl(_input.Text, out normalized))
                {
                    MessageBox.Show(this, "请输入有效的 http:// 或 https:// 服务器地址。",
                        "地址无效", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    _input.Focus();
                    return;
                }
                BaseUrl = normalized;
                DialogResult = DialogResult.OK;
                Close();
            };
            Controls.Add(save);
            AcceptButton = save;
            CancelButton = cancel;
        }
    }
}
