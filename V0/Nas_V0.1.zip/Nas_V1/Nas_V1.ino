#include <WiFi.h>
#include <WebServer.h>
#include "FS.h"
#include "SD_MMC.h"

const char* ssid = "BaBaWu";
const char* password = "95042700Wu$";

WebServer server(80);

File uploadFile;

void showFiles() {
  String html = R"rawliteral(
  <html>
  <body>
    <h1>Ricky ESP32 NAS</h1>
  )rawliteral";

  uint64_t totalBytes = SD_MMC.totalBytes();
  uint64_t usedBytes  = SD_MMC.usedBytes();
  uint64_t freeBytes  = totalBytes - usedBytes;

  html += "<p>Total: ";
  html += String(totalBytes / (1024.0 * 1024.0 * 1024.0), 2);
  html += " GB</p>";

  html += "<p>Used: ";
  html += String(usedBytes / (1024.0 * 1024.0 * 1024.0), 2);
  html += " GB</p>";

  html += "<p>Free: ";
  html += String(freeBytes / (1024.0 * 1024.0 * 1024.0), 2);
  html += " GB</p>";

  html += R"rawliteral(
    <hr>

    <h2>Upload File</h2>
    <form method="POST" action="/upload" enctype="multipart/form-data">
      <input type="file" name="file">
      <input type="submit" value="Upload">
    </form>

    <hr>
    <h2>Files</h2>
  )rawliteral";

  File root = SD_MMC.open("/");
  File file = root.openNextFile();

  while (file) {
    String fileName = String(file.name());

    html += "<p>";
    html += fileName;
    html += " - ";
    html += String(file.size());
    html += " bytes ";

    if (!file.isDirectory()) {
      html += "<a href='/download?file=";
      html += fileName;
      html += "'>Download</a>";

      html += " | ";

      html += "<a href='/delete?file=";
      html += fileName;
      html += "' onclick=\"return confirm('Delete this file?');\">Delete</a>";
    }

    html += "</p>";

    file = root.openNextFile();
  }

  html += "</body></html>";

  server.send(200, "text/html", html);
}

void downloadFile() {

  if (!server.hasArg("file")) {
    server.send(400, "text/plain", "File not specified");
    return;
  }

  String path = server.arg("file");

  if (!path.startsWith("/")) {
    path = "/" + path;
  }

  File file = SD_MMC.open(path, FILE_READ);

  if (!file || file.isDirectory()) {
    server.send(404, "text/plain", "File not found");
    return;
  }

  // 获取文件名
  String filename = path.substring(path.lastIndexOf('/') + 1);

  // 根据扩展名选择正确的文件类型
  String contentType = "application/octet-stream";

  if (filename.endsWith(".pdf")) {
    contentType = "application/pdf";
  }
  else if (filename.endsWith(".txt")) {
    contentType = "text/plain";
  }
  else if (filename.endsWith(".jpg") ||
           filename.endsWith(".jpeg")) {
    contentType = "image/jpeg";
  }
  else if (filename.endsWith(".png")) {
    contentType = "image/png";
  }
  else if (filename.endsWith(".zip")) {
    contentType = "application/zip";
  }

  // 告诉浏览器：这是一个要下载的文件
  server.sendHeader(
    "Content-Disposition",
    "attachment; filename=\"" + filename + "\""
  );

  server.sendHeader("Cache-Control", "no-cache");

  Serial.print("Downloading: ");
  Serial.println(filename);

  Serial.print("Size: ");
  Serial.println(file.size());

  size_t sent = server.streamFile(file, contentType);

  Serial.print("Bytes sent: ");
  Serial.println(sent);

  file.close();
}

void deleteFile() {

  if (!server.hasArg("file")) {
    server.send(400, "text/plain", "File not specified");
    return;
  }

  String path = server.arg("file");

  if (!path.startsWith("/")) {
    path = "/" + path;
  }

  Serial.print("Deleting: ");
  Serial.println(path);

  if (SD_MMC.remove(path)) {
    Serial.println("Delete successful");

    server.sendHeader("Location", "/");
    server.send(303);
  }
  else {
    Serial.println("Delete failed");

    server.send(
      500,
      "text/plain",
      "Failed to delete file"
    );
  }
}

void handleUpload() {
  HTTPUpload& upload = server.upload();

  if (upload.status == UPLOAD_FILE_START) {

    String filename = upload.filename;

    if (!filename.startsWith("/")) {
      filename = "/" + filename;
    }

    Serial.print("Uploading: ");
    Serial.println(filename);

    // 如果同名文件已经存在，先删除
    if (SD_MMC.exists(filename)) {
      SD_MMC.remove(filename);
    }

    if (SD_MMC.exists(filename)) {
      SD_MMC.remove(filename);
    }

    uploadFile = SD_MMC.open(filename, FILE_WRITE);

    if (!uploadFile) {
      Serial.println("Failed to open file for writing!");
    }

  } else if (upload.status == UPLOAD_FILE_WRITE) {

    if (uploadFile) {
      size_t written = uploadFile.write(
        upload.buf,
        upload.currentSize
      );

      if (written != upload.currentSize) {
        Serial.println("Write error!");
      }
    }

  } else if (upload.status == UPLOAD_FILE_END) {

    if (uploadFile) {
      uploadFile.close();
    }

    Serial.print("Upload complete: ");
    Serial.print(upload.totalSize);
    Serial.println(" bytes");
  }
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println("Starting SD card...");

  if (!SD_MMC.begin()) {
    Serial.println("SD card failed!");
    return;
  }

  Serial.println("SD card ready!");

  WiFi.begin(ssid, password);

  Serial.print("Connecting to WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi connected!");

  Serial.print("NAS IP Address: ");
  Serial.println(WiFi.localIP());

  server.on("/", HTTP_GET, showFiles);

  server.on("/download", HTTP_GET, downloadFile);

  server.on("/delete", HTTP_GET, deleteFile);

  server.on(
    "/upload",
    HTTP_POST,
    []() {
      server.sendHeader("Location", "/");
      server.send(303);
    },
    handleUpload
  );

  server.begin();

  Serial.println("NAS server started!");
}

void loop() {
  server.handleClient();
}