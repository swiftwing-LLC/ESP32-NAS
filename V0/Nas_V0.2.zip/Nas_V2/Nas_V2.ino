#include <WiFi.h>
#include <WebServer.h>
#include "FS.h"
#include "SD_MMC.h"

// =====================================================
// WiFi
// =====================================================

const char* ssid = "BaBaWu";
const char* password = "95042700Wu$";

WebServer server(80);

File uploadFile;


// =====================================================
// Basic Utilities
// =====================================================

String htmlEscape(String text) {
  text.replace("&", "&amp;");
  text.replace("<", "&lt;");
  text.replace(">", "&gt;");
  text.replace("\"", "&quot;");
  text.replace("'", "&#39;");
  return text;
}


String urlEncode(const String &str) {

  String encoded = "";

  char hex[] = "0123456789ABCDEF";

  for (unsigned int i = 0; i < str.length(); i++) {

    unsigned char c = str[i];

    if (
      (c >= 'a' && c <= 'z') ||
      (c >= 'A' && c <= 'Z') ||
      (c >= '0' && c <= '9') ||
      c == '-' ||
      c == '_' ||
      c == '.' ||
      c == '~'
    ) {

      encoded += (char)c;

    } else {

      encoded += '%';
      encoded += hex[c >> 4];
      encoded += hex[c & 15];
    }
  }

  return encoded;
}


String normalizePath(String path) {

  if (path.length() == 0) {
    return "/";
  }

  if (!path.startsWith("/")) {
    path = "/" + path;
  }

  while (path.indexOf("//") >= 0) {
    path.replace("//", "/");
  }

  if (
    path.length() > 1 &&
    path.endsWith("/")
  ) {
    path.remove(path.length() - 1);
  }

  // Basic path traversal protection
  if (path.indexOf("..") >= 0) {
    return "/";
  }

  return path;
}


String fileNameOnly(String path) {

  int index = path.lastIndexOf('/');

  if (index >= 0) {
    return path.substring(index + 1);
  }

  return path;
}


String parentPath(String path) {

  path = normalizePath(path);

  if (path == "/") {
    return "/";
  }

  int index = path.lastIndexOf('/');

  if (index <= 0) {
    return "/";
  }

  return path.substring(0, index);
}


String joinPath(
  String folder,
  String name
) {

  folder = normalizePath(folder);

  if (folder == "/") {
    return "/" + name;
  }

  return folder + "/" + name;
}


// =====================================================
// Hidden system folders
// =====================================================

bool shouldHide(String name) {

  return (
    name == "System Volume Information" ||
    name == "$RECYCLE.BIN" ||
    name == ".Trashes" ||
    name == ".Spotlight-V100" ||
    name == ".fseventsd"
  );
}


// =====================================================
// Human-readable size
// =====================================================

String humanSize(uint64_t bytes) {

  if (bytes < 1024) {
    return String(bytes) + " B";
  }

  if (
    bytes <
    1024ULL * 1024ULL
  ) {

    return String(
      bytes / 1024.0,
      1
    ) + " KB";
  }

  if (
    bytes <
    1024ULL *
    1024ULL *
    1024ULL
  ) {

    return String(
      bytes /
      (1024.0 * 1024.0),
      1
    ) + " MB";
  }

  return String(
    bytes /
    (1024.0 *
     1024.0 *
     1024.0),
    2
  ) + " GB";
}


// =====================================================
// MIME types
// =====================================================

String getContentType(
  String filename
) {

  filename.toLowerCase();

  if (
    filename.endsWith(".pdf")
  ) {
    return "application/pdf";
  }

  if (
    filename.endsWith(".txt")
  ) {
    return "text/plain";
  }

  if (
    filename.endsWith(".html")
  ) {
    return "text/html";
  }

  if (
    filename.endsWith(".htm")
  ) {
    return "text/html";
  }

  if (
    filename.endsWith(".jpg") ||
    filename.endsWith(".jpeg")
  ) {
    return "image/jpeg";
  }

  if (
    filename.endsWith(".png")
  ) {
    return "image/png";
  }

  if (
    filename.endsWith(".gif")
  ) {
    return "image/gif";
  }

  if (
    filename.endsWith(".zip")
  ) {
    return "application/zip";
  }

  if (
    filename.endsWith(".mp3")
  ) {
    return "audio/mpeg";
  }

  if (
    filename.endsWith(".mp4")
  ) {
    return "video/mp4";
  }

  if (
    filename.endsWith(".json")
  ) {
    return "application/json";
  }

  if (
    filename.endsWith(".csv")
  ) {
    return "text/csv";
  }

  return "application/octet-stream";
}


// =====================================================
// Breadcrumb
// =====================================================

String makeBreadcrumb(
  String path
) {

  String result =
    "<a class='crumb' "
    "href='/?path=%2F'>Home</a>";

  if (path == "/") {
    return result;
  }

  String current = "";

  int start = 1;

  while (
    start < path.length()
  ) {

    int slash =
      path.indexOf('/', start);

    String part;

    if (slash == -1) {

      part =
        path.substring(start);

      start =
        path.length();

    } else {

      part =
        path.substring(
          start,
          slash
        );

      start =
        slash + 1;
    }

    if (
      part.length() == 0
    ) {
      continue;
    }

    current += "/" + part;

    result +=
      "<span class='separator'>"
      " / "
      "</span>";

    result +=
      "<a class='crumb' href='/?path=" +
      urlEncode(current) +
      "'>" +
      htmlEscape(part) +
      "</a>";
  }

  return result;
}


// =====================================================
// File row
// =====================================================

String makeRow(
  String fullPath,
  String name,
  bool directory,
  uint64_t size,
  String currentPath
) {

  String html =
    "<div class='file-row'>";

  // ----------------------------------
  // Name
  // ----------------------------------

  html +=
    "<div class='file-name'>";

  if (directory) {

    html +=
      "<div class='icon folder-icon'>"
      "DIR"
      "</div>";

    html +=
      "<a class='filename' "
      "href='/?path=" +
      urlEncode(fullPath) +
      "'>" +
      htmlEscape(name) +
      "</a>";

  } else {

    html +=
      "<div class='icon file-icon'>"
      "FILE"
      "</div>";

    html +=
      "<span class='filename'>" +
      htmlEscape(name) +
      "</span>";
  }

  html += "</div>";


  // ----------------------------------
  // Type
  // ----------------------------------

  html +=
    "<div class='file-type'>";

  if (directory) {

    html += "Folder";

  } else {

    int dot =
      name.lastIndexOf('.');

    if (dot >= 0) {

      String extension =
        name.substring(dot + 1);

      extension.toUpperCase();

      html += extension;

    } else {

      html += "File";
    }
  }

  html += "</div>";


  // ----------------------------------
  // Size
  // ----------------------------------

  html +=
    "<div class='file-size'>";

  if (directory) {

    html += "--";

  } else {

    html += humanSize(size);
  }

  html += "</div>";


  // ----------------------------------
  // Actions
  // ----------------------------------

  html +=
    "<div class='actions'>";

  if (directory) {

    html +=
      "<a class='button small' "
      "href='/?path=" +
      urlEncode(fullPath) +
      "'>Open</a>";

  } else {

    html +=
      "<a class='button small' "
      "href='/download?file=" +
      urlEncode(fullPath) +
      "'>Download</a>";
  }


  // Rename

  html +=
    "<button "
    "class='button small secondary' "
    "onclick=\"renameItem('";

  html += urlEncode(fullPath);

  html += "','";

  html += urlEncode(name);

  html += "','";

  html += urlEncode(currentPath);

  html +=
    "')\">Rename</button>";


  // Move

  html +=
    "<button "
    "class='button small secondary' "
    "onclick=\"moveItem('";

  html += urlEncode(fullPath);

  html += "','";

  html += urlEncode(currentPath);

  html +=
    "')\">Move</button>";


  // Delete

  html +=
    "<a "
    "class='button small danger' "
    "onclick=\"return confirm("
    "'Delete this item?'"
    ")\" "
    "href='/delete?file=";

  html += urlEncode(fullPath);

  html += "&return=";

  html += urlEncode(currentPath);

  html += "'>Delete</a>";


  html += "</div>";
  html += "</div>";

  return html;
}


// =====================================================
// Search recursively
// =====================================================

void appendSearchResults(
  String path,
  String query,
  String &html,
  int &count,
  int depth
) {

  if (
    depth > 12 ||
    count >= 100
  ) {
    return;
  }

  File dir =
    SD_MMC.open(path);

  if (
    !dir ||
    !dir.isDirectory()
  ) {
    return;
  }

  File item =
    dir.openNextFile();

  while (
    item &&
    count < 100
  ) {

    String fullPath =
      String(item.path());

    String name =
      fileNameOnly(fullPath);

    bool directory =
      item.isDirectory();

    uint64_t size =
      item.size();

    item.close();


    if (!shouldHide(name)) {

      String lowerName =
        name;

      lowerName.toLowerCase();

      if (
        lowerName.indexOf(query)
        >= 0
      ) {

        html += makeRow(
          fullPath,
          name,
          directory,
          size,
          parentPath(fullPath)
        );

        count++;
      }


      if (directory) {

        appendSearchResults(
          fullPath,
          query,
          html,
          count,
          depth + 1
        );
      }
    }

    item =
      dir.openNextFile();
  }

  dir.close();
}


// =====================================================
// Main page
// =====================================================

void showFiles() {

  String currentPath = "/";

  if (
    server.hasArg("path")
  ) {

    currentPath =
      normalizePath(
        server.arg("path")
      );
  }


  File directory =
    SD_MMC.open(currentPath);


  if (
    !directory ||
    !directory.isDirectory()
  ) {

    server.send(
      404,
      "text/plain",
      "Folder not found"
    );

    return;
  }


  uint64_t totalBytes =
    SD_MMC.totalBytes();

  uint64_t usedBytes =
    SD_MMC.usedBytes();

  uint64_t freeBytes =
    totalBytes - usedBytes;


  float usedPercent = 0;

  if (totalBytes > 0) {

    usedPercent =
      (
        (float)usedBytes /
        (float)totalBytes
      ) * 100.0;
  }


  String searchQuery = "";

  if (
    server.hasArg("q")
  ) {

    searchQuery =
      server.arg("q");

    searchQuery.trim();
  }


  // ===================================================
  // HTML HEAD
  // ===================================================

  String html = R"rawliteral(

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<meta
  name="viewport"
  content="width=device-width, initial-scale=1.0"
>

<title>Ricky NAS</title>


<style>

* {
  box-sizing: border-box;
}

body {

  margin: 0;

  background: #f5f6f8;

  font-family:
    -apple-system,
    BlinkMacSystemFont,
    "Segoe UI",
    Arial,
    sans-serif;

  color: #202124;
}


.topbar {

  height: 64px;

  background: white;

  border-bottom:
    1px solid #e3e5e8;

  display: flex;

  align-items: center;

  justify-content:
    space-between;

  padding:
    0 30px;
}


.logo {

  font-size: 22px;

  font-weight: 700;
}


.status {

  font-size: 13px;

  color: #35a853;
}


.container {

  max-width: 1150px;

  margin:
    28px auto;

  padding:
    0 20px;
}


.card {

  background: white;

  border-radius: 14px;

  padding: 22px;

  margin-bottom: 18px;

  box-shadow:
    0 2px 8px
    rgba(0,0,0,0.05);
}


.breadcrumb {

  font-size: 15px;

  margin-bottom: 18px;
}


.crumb {

  color: #2774d9;

  text-decoration: none;
}


.crumb:hover {

  text-decoration:
    underline;
}


.separator {

  color: #888;
}


.search-box {

  display: flex;

  gap: 8px;

  margin-bottom: 20px;
}


.search-box input {

  flex: 1;

  padding:
    11px 14px;

  border:
    1px solid #d7dbe0;

  border-radius: 9px;

  font-size: 14px;
}


.toolbar {

  display: flex;

  gap: 10px;

  flex-wrap: wrap;

  margin-bottom: 18px;
}


.forms {

  display: flex;

  gap: 12px;

  flex-wrap: wrap;

  margin-bottom: 22px;
}


.form-box {

  background: #f8f9fb;

  padding: 14px;

  border-radius: 10px;
}


input[type="text"] {

  padding: 8px;

  border:
    1px solid #ccc;

  border-radius: 6px;
}


input[type="file"] {

  max-width: 280px;
}


.button {

  display: inline-block;

  padding:
    9px 14px;

  background: #2774d9;

  color: white;

  text-decoration: none;

  border: none;

  border-radius: 8px;

  cursor: pointer;

  font-size: 14px;
}


.button:hover {

  opacity: 0.88;
}


.secondary {

  background: #e8ebef;

  color: #333;
}


.danger {

  background: #ef5350;
}


.small {

  padding:
    6px 10px;

  font-size: 12px;
}


.file-header,
.file-row {

  display: grid;

  grid-template-columns:
    minmax(250px, 3fr)
    1fr
    1fr
    2.7fr;

  align-items: center;

  gap: 10px;

  padding:
    12px 10px;
}


.file-header {

  font-size: 12px;

  font-weight: 600;

  color: #777;

  border-bottom:
    1px solid #eee;
}


.file-row {

  border-bottom:
    1px solid #f0f0f0;

  min-height: 58px;
}


.file-row:hover {

  background: #f7f9fc;
}


.file-name {

  display: flex;

  align-items: center;

  gap: 10px;

  min-width: 0;
}


.filename {

  color: #202124;

  text-decoration: none;

  overflow: hidden;

  text-overflow: ellipsis;

  white-space: nowrap;
}


a.filename:hover {

  color: #2774d9;
}


.icon {

  width: 38px;

  height: 32px;

  border-radius: 7px;

  display: flex;

  justify-content: center;

  align-items: center;

  font-weight: 700;

  font-size: 9px;

  flex-shrink: 0;
}


.folder-icon {

  background: #dfeaff;

  color: #2774d9;
}


.file-icon {

  background: #e9ecef;

  color: #666;
}


.file-type,
.file-size {

  color: #666;

  font-size: 13px;
}


.actions {

  display: flex;

  gap: 6px;

  flex-wrap: wrap;
}


.storage-title {

  display: flex;

  justify-content:
    space-between;

  margin-bottom: 10px;

  font-size: 14px;
}


.storage-background {

  width: 100%;

  height: 10px;

  background: #e7e9ed;

  border-radius: 6px;

  overflow: hidden;
}


.storage-used {

  height: 100%;

  background: #2774d9;
}


.storage-details {

  color: #777;

  margin-top: 9px;

  font-size: 13px;
}


.empty {

  padding: 30px;

  text-align: center;

  color: #888;
}


@media(max-width: 760px) {

  .file-header {
    display: none;
  }

  .file-row {

    grid-template-columns:
      1fr;

    gap: 8px;
  }

  .file-type,
  .file-size {

    display: none;
  }

  .actions {

    padding-left: 48px;
  }

}

</style>


<script>

function renameItem(
  path,
  name,
  returnPath
) {

  const oldName =
    decodeURIComponent(name);

  const newName =
    prompt(
      "New name:",
      oldName
    );

  if (!newName) {
    return;
  }

  if (
    newName === oldName
  ) {
    return;
  }

  window.location.href =
    "/rename?file=" +
    path +
    "&name=" +
    encodeURIComponent(newName) +
    "&return=" +
    returnPath;
}


function moveItem(
  path,
  returnPath
) {

  const current =
    decodeURIComponent(
      returnPath
    );

  const destination =
    prompt(
      "Move to folder path:",
      current
    );

  if (!destination) {
    return;
  }

  window.location.href =
    "/move?file=" +
    path +
    "&dest=" +
    encodeURIComponent(destination) +
    "&return=" +
    returnPath;
}

</script>

</head>


<body>

<div class="topbar">

  <div class="logo">
    Ricky NAS
  </div>

  <div class="status">
    Master Node Online
  </div>

</div>


<div class="container">


<div class="card">


<div class="breadcrumb">

)rawliteral";


  // ===================================================
  // Breadcrumb
  // ===================================================

  html +=
    makeBreadcrumb(
      currentPath
    );

  html += "</div>";


  // ===================================================
  // Search
  // ===================================================

  html +=
    "<form "
    "class='search-box' "
    "method='GET' "
    "action='/'>";

  html +=
    "<input "
    "type='text' "
    "name='q' "
    "placeholder='Search entire NAS...' "
    "value='" +
    htmlEscape(searchQuery) +
    "'>";

  html +=
    "<button "
    "class='button' "
    "type='submit'>"
    "Search"
    "</button>";

  html += "</form>";


  // ===================================================
  // Back button
  // ===================================================

  if (
    currentPath != "/" &&
    searchQuery.length() == 0
  ) {

    html +=
      "<div class='toolbar'>";

    html +=
      "<a "
      "class='button secondary' "
      "href='/?path=" +
      urlEncode(
        parentPath(currentPath)
      ) +
      "'>Back</a>";

    html += "</div>";
  }


  // ===================================================
  // Upload + New Folder
  // ===================================================

  if (
    searchQuery.length() == 0
  ) {

    html +=
      "<div class='forms'>";


    // Upload

    html +=
      "<div class='form-box'>";

    html +=
      "<form "
      "method='POST' "
      "action='/upload?path=" +
      urlEncode(currentPath) +
      "' "
      "enctype='multipart/form-data'>";

    html +=
      "<input "
      "type='file' "
      "name='file' "
      "required> ";

    html +=
      "<input "
      "class='button' "
      "type='submit' "
      "value='Upload'>";

    html +=
      "</form>"
      "</div>";


    // New Folder

    html +=
      "<div class='form-box'>";

    html +=
      "<form "
      "method='POST' "
      "action='/mkdir?path=" +
      urlEncode(currentPath) +
      "'>";

    html +=
      "<input "
      "type='text' "
      "name='name' "
      "placeholder='Folder name' "
      "required> ";

    html +=
      "<input "
      "class='button' "
      "type='submit' "
      "value='New Folder'>";

    html +=
      "</form>"
      "</div>";


    html += "</div>";
  }


  // ===================================================
  // Table header
  // ===================================================

  html += R"rawliteral(

<div class="file-header">

  <div>Name</div>

  <div>Type</div>

  <div>Size</div>

  <div>Actions</div>

</div>

)rawliteral";


  // ===================================================
  // Search mode
  // ===================================================

  if (
    searchQuery.length() > 0
  ) {

    directory.close();

    String query =
      searchQuery;

    query.toLowerCase();

    html +=
      "<h3>Search results for: ";

    html +=
      htmlEscape(
        searchQuery
      );

    html += "</h3>";


    int resultCount = 0;


    appendSearchResults(
      "/",
      query,
      html,
      resultCount,
      0
    );


    if (
      resultCount == 0
    ) {

      html +=
        "<div class='empty'>"
        "No files found."
        "</div>";

    } else {

      html +=
        "<p style='color:#777;'>";

      html +=
        String(resultCount);

      html +=
        " result(s)"
        "</p>";
    }

  }


  // ===================================================
  // Normal browsing mode
  // ===================================================

  else {

    int itemCount = 0;


    // -------------------------------------------------
    // Folders first
    // -------------------------------------------------

    File item =
      directory.openNextFile();


    while (item) {

      if (
        item.isDirectory()
      ) {

        String fullPath =
          String(item.path());

        String name =
          fileNameOnly(
            fullPath
          );


        if (
          !shouldHide(name)
        ) {

          html +=
            makeRow(
              fullPath,
              name,
              true,
              0,
              currentPath
            );

          itemCount++;
        }
      }


      item.close();

      item =
        directory.openNextFile();
    }


    directory.close();


    // -------------------------------------------------
    // Files second
    // -------------------------------------------------

    directory =
      SD_MMC.open(
        currentPath
      );


    item =
      directory.openNextFile();


    while (item) {

      if (
        !item.isDirectory()
      ) {

        String fullPath =
          String(item.path());

        String name =
          fileNameOnly(
            fullPath
          );


        if (
          !shouldHide(name)
        ) {

          html +=
            makeRow(
              fullPath,
              name,
              false,
              item.size(),
              currentPath
            );

          itemCount++;
        }
      }


      item.close();

      item =
        directory.openNextFile();
    }


    directory.close();


    if (
      itemCount == 0
    ) {

      html +=
        "<div class='empty'>"
        "This folder is empty."
        "</div>";
    }
  }


  html += "</div>";


  // ===================================================
  // Storage card
  // ===================================================

  html +=
    "<div class='card'>";


  html +=
    "<div "
    "class='storage-title'>";


  html +=
    "<strong>"
    "Storage"
    "</strong>";


  html +=
    "<span>";

  html +=
    String(
      usedPercent,
      1
    );

  html +=
    "% used"
    "</span>"
    "</div>";


  html +=
    "<div "
    "class='storage-background'>";


  html +=
    "<div "
    "class='storage-used' "
    "style='width:";

  html +=
    String(
      usedPercent,
      1
    );

  html +=
    "%'></div>"
    "</div>";


  html +=
    "<div "
    "class='storage-details'>";

  html +=
    humanSize(
      usedBytes
    );

  html +=
    " used &nbsp; | &nbsp; ";

  html +=
    humanSize(
      freeBytes
    );

  html +=
    " free &nbsp; | &nbsp; ";

  html +=
    humanSize(
      totalBytes
    );

  html +=
    " total"
    "</div>";


  html += "</div>";


  html += R"rawliteral(

</div>

</body>

</html>

)rawliteral";


  server.send(
    200,
    "text/html; charset=utf-8",
    html
  );
}


// =====================================================
// Download
// =====================================================

void downloadFile() {

  if (
    !server.hasArg("file")
  ) {

    server.send(
      400,
      "text/plain",
      "Missing file"
    );

    return;
  }


  String path =
    normalizePath(
      server.arg("file")
    );


  File file =
    SD_MMC.open(
      path,
      FILE_READ
    );


  if (
    !file ||
    file.isDirectory()
  ) {

    server.send(
      404,
      "text/plain",
      "File not found"
    );

    return;
  }


  String name =
    fileNameOnly(path);


  Serial.print(
    "Downloading: "
  );

  Serial.println(name);


  Serial.print(
    "Size: "
  );

  Serial.println(
    file.size()
  );


  server.sendHeader(
    "Content-Disposition",
    "attachment; filename=\"" +
    name +
    "\""
  );


  server.sendHeader(
    "Cache-Control",
    "no-cache"
  );


  size_t sent =
    server.streamFile(
      file,
      getContentType(name)
    );


  Serial.print(
    "Bytes sent: "
  );

  Serial.println(sent);


  file.close();
}


// =====================================================
// Upload
// =====================================================

void handleUpload() {

  HTTPUpload& upload =
    server.upload();


  String folder = "/";


  if (
    server.hasArg("path")
  ) {

    folder =
      normalizePath(
        server.arg("path")
      );
  }


  if (
    upload.status ==
    UPLOAD_FILE_START
  ) {

    String filename =
      upload.filename;


    // Remove browser path information
    filename.replace(
      "\\",
      "/"
    );


    int slash =
      filename.lastIndexOf('/');


    if (
      slash >= 0
    ) {

      filename =
        filename.substring(
          slash + 1
        );
    }


    if (
      filename.indexOf("..") >= 0 ||
      filename.length() == 0
    ) {

      return;
    }


    String path =
      joinPath(
        folder,
        filename
      );


    Serial.print(
      "Uploading: "
    );

    Serial.println(path);


    // Replace existing file
    if (
      SD_MMC.exists(path)
    ) {

      SD_MMC.remove(path);
    }


    uploadFile =
      SD_MMC.open(
        path,
        FILE_WRITE
      );
  }


  else if (
    upload.status ==
    UPLOAD_FILE_WRITE
  ) {

    if (uploadFile) {

      uploadFile.write(
        upload.buf,
        upload.currentSize
      );
    }
  }


  else if (
    upload.status ==
    UPLOAD_FILE_END
  ) {

    if (uploadFile) {
      uploadFile.close();
    }


    Serial.print(
      "Upload complete: "
    );

    Serial.print(
      upload.totalSize
    );

    Serial.println(
      " bytes"
    );
  }
}


// =====================================================
// Create Folder
// =====================================================

void createFolder() {

  String folder = "/";


  if (
    server.hasArg("path")
  ) {

    folder =
      normalizePath(
        server.arg("path")
      );
  }


  if (
    !server.hasArg("name")
  ) {

    server.send(
      400,
      "text/plain",
      "Missing folder name"
    );

    return;
  }


  String name =
    server.arg("name");


  name.trim();


  if (
    name.length() == 0 ||
    name.indexOf("/") >= 0 ||
    name.indexOf("\\") >= 0 ||
    name.indexOf("..") >= 0
  ) {

    server.send(
      400,
      "text/plain",
      "Invalid folder name"
    );

    return;
  }


  String newFolder =
    joinPath(
      folder,
      name
    );


  if (
    SD_MMC.exists(
      newFolder
    )
  ) {

    server.send(
      409,
      "text/plain",
      "Folder already exists"
    );

    return;
  }


  Serial.print(
    "Creating folder: "
  );

  Serial.println(
    newFolder
  );


  if (
    !SD_MMC.mkdir(
      newFolder
    )
  ) {

    server.send(
      500,
      "text/plain",
      "Failed to create folder"
    );

    return;
  }


  server.sendHeader(
    "Location",
    "/?path=" +
    urlEncode(folder)
  );


  server.send(303);
}


// =====================================================
// Delete
// =====================================================

void deleteItem() {

  if (
    !server.hasArg("file")
  ) {

    server.send(
      400,
      "text/plain",
      "Missing file"
    );

    return;
  }


  String path =
    normalizePath(
      server.arg("file")
    );


  String returnPath = "/";


  if (
    server.hasArg("return")
  ) {

    returnPath =
      normalizePath(
        server.arg("return")
      );
  }


  // Protect root
  if (
    path == "/"
  ) {

    server.send(
      403,
      "text/plain",
      "Cannot delete root"
    );

    return;
  }


  File item =
    SD_MMC.open(path);


  if (!item) {

    server.send(
      404,
      "text/plain",
      "Item not found"
    );

    return;
  }


  bool directory =
    item.isDirectory();


  item.close();


  bool result = false;


  if (directory) {

    // Only empty folders can currently be deleted
    result =
      SD_MMC.rmdir(path);

  } else {

    result =
      SD_MMC.remove(path);
  }


  if (!result) {

    server.send(
      500,
      "text/plain",
      "Delete failed. Folder may not be empty."
    );

    return;
  }


  server.sendHeader(
    "Location",
    "/?path=" +
    urlEncode(
      returnPath
    )
  );


  server.send(303);
}


// =====================================================
// Rename
// =====================================================

void renameItem() {

  if (
    !server.hasArg("file") ||
    !server.hasArg("name")
  ) {

    server.send(
      400,
      "text/plain",
      "Missing parameter"
    );

    return;
  }


  String oldPath =
    normalizePath(
      server.arg("file")
    );


  String newName =
    server.arg("name");


  newName.trim();


  if (
    oldPath == "/"
  ) {

    server.send(
      403,
      "text/plain",
      "Cannot rename root"
    );

    return;
  }


  if (
    newName.length() == 0 ||
    newName.indexOf("/") >= 0 ||
    newName.indexOf("\\") >= 0 ||
    newName.indexOf("..") >= 0
  ) {

    server.send(
      400,
      "text/plain",
      "Invalid name"
    );

    return;
  }


  String newPath =
    joinPath(
      parentPath(oldPath),
      newName
    );


  if (
    SD_MMC.exists(newPath)
  ) {

    server.send(
      409,
      "text/plain",
      "Name already exists"
    );

    return;
  }


  Serial.print(
    "Rename: "
  );

  Serial.print(
    oldPath
  );

  Serial.print(
    " -> "
  );

  Serial.println(
    newPath
  );


  if (
    !SD_MMC.rename(
      oldPath,
      newPath
    )
  ) {

    server.send(
      500,
      "text/plain",
      "Rename failed"
    );

    return;
  }


  String returnPath =
    parentPath(newPath);


  if (
    server.hasArg("return")
  ) {

    returnPath =
      normalizePath(
        server.arg("return")
      );
  }


  server.sendHeader(
    "Location",
    "/?path=" +
    urlEncode(
      returnPath
    )
  );


  server.send(303);
}


// =====================================================
// Move
// =====================================================

void moveItem() {

  if (
    !server.hasArg("file") ||
    !server.hasArg("dest")
  ) {

    server.send(
      400,
      "text/plain",
      "Missing parameter"
    );

    return;
  }


  String oldPath =
    normalizePath(
      server.arg("file")
    );


  String destination =
    normalizePath(
      server.arg("dest")
    );


  if (
    oldPath == "/"
  ) {

    server.send(
      403,
      "text/plain",
      "Cannot move root"
    );

    return;
  }


  File destinationFolder =
    SD_MMC.open(
      destination
    );


  if (
    !destinationFolder ||
    !destinationFolder.isDirectory()
  ) {

    if (
      destinationFolder
    ) {
      destinationFolder.close();
    }

    server.send(
      400,
      "text/plain",
      "Destination folder does not exist"
    );

    return;
  }


  destinationFolder.close();


  File source =
    SD_MMC.open(
      oldPath
    );


  if (!source) {

    server.send(
      404,
      "text/plain",
      "Source not found"
    );

    return;
  }


  bool sourceIsDirectory =
    source.isDirectory();


  source.close();


  // Prevent moving folder into itself
  if (
    sourceIsDirectory &&
    (
      destination ==
      oldPath ||

      destination.startsWith(
        oldPath + "/"
      )
    )
  ) {

    server.send(
      400,
      "text/plain",
      "Cannot move folder into itself"
    );

    return;
  }


  String newPath =
    joinPath(
      destination,
      fileNameOnly(
        oldPath
      )
    );


  if (
    newPath ==
    oldPath
  ) {

    server.sendHeader(
      "Location",
      "/?path=" +
      urlEncode(
        destination
      )
    );

    server.send(303);

    return;
  }


  if (
    SD_MMC.exists(
      newPath
    )
  ) {

    server.send(
      409,
      "text/plain",
      "Destination already contains an item with this name"
    );

    return;
  }


  Serial.print(
    "Move: "
  );

  Serial.print(
    oldPath
  );

  Serial.print(
    " -> "
  );

  Serial.println(
    newPath
  );


  if (
    !SD_MMC.rename(
      oldPath,
      newPath
    )
  ) {

    server.send(
      500,
      "text/plain",
      "Move failed"
    );

    return;
  }


  String returnPath = "/";


  if (
    server.hasArg("return")
  ) {

    returnPath =
      normalizePath(
        server.arg("return")
      );
  }


  server.sendHeader(
    "Location",
    "/?path=" +
    urlEncode(
      returnPath
    )
  );


  server.send(303);
}


// =====================================================
// Setup
// =====================================================

void setup() {

  Serial.begin(115200);

  delay(1000);


  Serial.println();
  Serial.println(
    "============================"
  );

  Serial.println(
    "Starting Ricky NAS..."
  );

  Serial.println(
    "============================"
  );


  // ---------------------------------------------------
  // SD Card
  // ---------------------------------------------------

  Serial.println(
    "Starting SD card..."
  );


  if (
    !SD_MMC.begin()
  ) {

    Serial.println(
      "SD card failed!"
    );

    return;
  }


  Serial.println(
    "SD card ready!"
  );


  Serial.print(
    "SD size: "
  );

  Serial.println(
    humanSize(
      SD_MMC.totalBytes()
    )
  );


  // ---------------------------------------------------
  // WiFi
  // ---------------------------------------------------

  WiFi.mode(
    WIFI_STA
  );


  WiFi.begin(
    ssid,
    password
  );


  Serial.print(
    "Connecting to WiFi"
  );


  while (
    WiFi.status() !=
    WL_CONNECTED
  ) {

    delay(500);

    Serial.print(".");
  }


  Serial.println();


  Serial.println(
    "WiFi connected!"
  );


  Serial.print(
    "Ricky NAS IP: http://"
  );


  Serial.println(
    WiFi.localIP()
  );


  // ---------------------------------------------------
  // Routes
  // ---------------------------------------------------


  // Main browser

  server.on(
    "/",
    HTTP_GET,
    showFiles
  );


  // Download

  server.on(
    "/download",
    HTTP_GET,
    downloadFile
  );


  // Delete

  server.on(
    "/delete",
    HTTP_GET,
    deleteItem
  );


  // Rename

  server.on(
    "/rename",
    HTTP_GET,
    renameItem
  );


  // Move

  server.on(
    "/move",
    HTTP_GET,
    moveItem
  );


  // New Folder

  server.on(
    "/mkdir",
    HTTP_POST,
    createFolder
  );


  // Upload

  server.on(

    "/upload",

    HTTP_POST,


    []() {

      String folder = "/";


      if (
        server.hasArg("path")
      ) {

        folder =
          normalizePath(
            server.arg("path")
          );
      }


      server.sendHeader(
        "Location",
        "/?path=" +
        urlEncode(folder)
      );


      server.send(303);
    },


    handleUpload
  );


  // ---------------------------------------------------
  // Start Server
  // ---------------------------------------------------

  server.begin();


  Serial.println(
    "Web server started!"
  );


  Serial.println();
  Serial.println(
    "Ricky NAS is ONLINE"
  );

  Serial.println(
    "============================"
  );
}


// =====================================================
// Loop
// =====================================================

void loop() {

  server.handleClient();
}