#include <WiFi.h>
#include <WiFiUdp.h>

// =====================================================
// WiFi
// =====================================================

const char* ssid = "BaBaWu";
const char* password = "95042700Wu$";


// =====================================================
// SwiftWing NAS Local DNS
// =====================================================

const char* NAS_DOMAIN =
  "swiftwingnas.tplinkdns.com";

// Master ESP32 local IP
IPAddress NAS_IP(
  192,
  168,
  0,
  100
);


// =====================================================
// Upstream DNS
// =====================================================

// Cloudflare DNS
IPAddress UPSTREAM_DNS(
  1,
  1,
  1,
  1
);


// =====================================================
// UDP
// =====================================================

WiFiUDP dnsServer;
WiFiUDP upstreamUDP;

const uint16_t DNS_PORT = 53;
const uint16_t UPSTREAM_LOCAL_PORT = 53000;


// =====================================================
// Buffers
// =====================================================

uint8_t dnsBuffer[512];
uint8_t responseBuffer[512];


// =====================================================
// DNS name parser
// =====================================================

String readDNSName(
  uint8_t* buffer,
  int length,
  int start,
  int &endPosition
) {

  String domain = "";

  int pos = start;

  while (
    pos < length &&
    buffer[pos] != 0
  ) {

    int labelLength =
      buffer[pos];

    pos++;

    if (
      labelLength <= 0 ||
      pos + labelLength >
      length
    ) {
      break;
    }

    if (
      domain.length() > 0
    ) {
      domain += ".";
    }

    for (
      int i = 0;
      i < labelLength;
      i++
    ) {

      domain +=
        (char)buffer[
          pos + i
        ];
    }

    pos += labelLength;
  }

  endPosition = pos + 1;

  domain.toLowerCase();

  return domain;
}


// =====================================================
// Reply with local NAS IPv4
// =====================================================

void sendLocalNASReply(
  uint8_t* query,
  int queryLength,
  IPAddress clientIP,
  uint16_t clientPort,
  int questionEnd
) {

  uint8_t reply[512];

  int pos = 0;


  // ---------------------------------------------------
  // Transaction ID
  // ---------------------------------------------------

  reply[pos++] =
    query[0];

  reply[pos++] =
    query[1];


  // ---------------------------------------------------
  // Flags
  // 0x8180
  // Standard response
  // Recursion available
  // No error
  // ---------------------------------------------------

  reply[pos++] = 0x81;
  reply[pos++] = 0x80;


  // ---------------------------------------------------
  // Questions = 1
  // ---------------------------------------------------

  reply[pos++] = 0x00;
  reply[pos++] = 0x01;


  // ---------------------------------------------------
  // Answers = 1
  // ---------------------------------------------------

  reply[pos++] = 0x00;
  reply[pos++] = 0x01;


  // ---------------------------------------------------
  // Authority = 0
  // ---------------------------------------------------

  reply[pos++] = 0x00;
  reply[pos++] = 0x00;


  // ---------------------------------------------------
  // Additional = 0
  // ---------------------------------------------------

  reply[pos++] = 0x00;
  reply[pos++] = 0x00;


  // ---------------------------------------------------
  // Copy original question
  //
  // questionEnd points after QNAME.
  // Add 4 bytes:
  // QTYPE + QCLASS
  // ---------------------------------------------------

  int questionLength =
    questionEnd + 4 - 12;

  for (
    int i = 0;
    i < questionLength;
    i++
  ) {

    reply[pos++] =
      query[12 + i];
  }


  // ---------------------------------------------------
  // Answer NAME
  //
  // Pointer to original name at offset 12
  // ---------------------------------------------------

  reply[pos++] = 0xC0;
  reply[pos++] = 0x0C;


  // ---------------------------------------------------
  // TYPE A
  // ---------------------------------------------------

  reply[pos++] = 0x00;
  reply[pos++] = 0x01;


  // ---------------------------------------------------
  // CLASS IN
  // ---------------------------------------------------

  reply[pos++] = 0x00;
  reply[pos++] = 0x01;


  // ---------------------------------------------------
  // TTL = 60 seconds
  // ---------------------------------------------------

  reply[pos++] = 0x00;
  reply[pos++] = 0x00;
  reply[pos++] = 0x00;
  reply[pos++] = 0x3C;


  // ---------------------------------------------------
  // IPv4 length = 4
  // ---------------------------------------------------

  reply[pos++] = 0x00;
  reply[pos++] = 0x04;


  // ---------------------------------------------------
  // Master NAS local IP
  // ---------------------------------------------------

  reply[pos++] = NAS_IP[0];
  reply[pos++] = NAS_IP[1];
  reply[pos++] = NAS_IP[2];
  reply[pos++] = NAS_IP[3];


  // ---------------------------------------------------
  // Send reply
  // ---------------------------------------------------

  dnsServer.beginPacket(
    clientIP,
    clientPort
  );

  dnsServer.write(
    reply,
    pos
  );

  dnsServer.endPacket();


  Serial.print(
    "LOCAL DNS: "
  );

  Serial.print(
    NAS_DOMAIN
  );

  Serial.print(
    " -> "
  );

  Serial.println(
    NAS_IP
  );
}


// =====================================================
// Return empty successful response
// Used for AAAA request to NAS domain
// =====================================================

void sendEmptyReply(
  uint8_t* query,
  int queryLength,
  IPAddress clientIP,
  uint16_t clientPort,
  int questionEnd
) {

  uint8_t reply[512];

  int pos = 0;


  // ID
  reply[pos++] = query[0];
  reply[pos++] = query[1];


  // Flags
  reply[pos++] = 0x81;
  reply[pos++] = 0x80;


  // One question
  reply[pos++] = 0x00;
  reply[pos++] = 0x01;


  // Zero answers
  reply[pos++] = 0x00;
  reply[pos++] = 0x00;


  // Authority
  reply[pos++] = 0x00;
  reply[pos++] = 0x00;


  // Additional
  reply[pos++] = 0x00;
  reply[pos++] = 0x00;


  int questionLength =
    questionEnd + 4 - 12;


  for (
    int i = 0;
    i < questionLength;
    i++
  ) {

    reply[pos++] =
      query[12 + i];
  }


  dnsServer.beginPacket(
    clientIP,
    clientPort
  );

  dnsServer.write(
    reply,
    pos
  );

  dnsServer.endPacket();
}


// =====================================================
// Forward normal DNS query
// =====================================================

void forwardDNSQuery(
  uint8_t* query,
  int queryLength,
  IPAddress clientIP,
  uint16_t clientPort
) {

  while (
    upstreamUDP.parsePacket()
  ) {

    upstreamUDP.read(
      responseBuffer,
      sizeof(responseBuffer)
    );
  }


  upstreamUDP.beginPacket(
    UPSTREAM_DNS,
    53
  );

  upstreamUDP.write(
    query,
    queryLength
  );

  upstreamUDP.endPacket();


  unsigned long startTime =
    millis();


  while (
    millis() - startTime <
    1000
  ) {

    int packetSize =
      upstreamUDP.parsePacket();


    if (packetSize) {

      int len =
        upstreamUDP.read(
          responseBuffer,
          sizeof(responseBuffer)
        );


      if (len > 0) {

        dnsServer.beginPacket(
          clientIP,
          clientPort
        );

        dnsServer.write(
          responseBuffer,
          len
        );

        dnsServer.endPacket();
      }

      return;
    }


    delay(1);
  }


  Serial.println(
    "Upstream DNS timeout"
  );
}


// =====================================================
// Process DNS Request
// =====================================================

void processDNSRequest() {

  int packetSize =
    dnsServer.parsePacket();


  if (!packetSize) {
    return;
  }


  IPAddress clientIP =
    dnsServer.remoteIP();


  uint16_t clientPort =
    dnsServer.remotePort();


  int len =
    dnsServer.read(
      dnsBuffer,
      sizeof(dnsBuffer)
    );


  if (len < 16) {
    return;
  }


  int questionEnd;


  String requestedDomain =
    readDNSName(
      dnsBuffer,
      len,
      12,
      questionEnd
    );


  if (
    questionEnd + 3 >= len
  ) {
    return;
  }


  uint16_t qType =
    (
      dnsBuffer[
        questionEnd
      ] << 8
    ) |

    dnsBuffer[
      questionEnd + 1
    ];


  // ===================================================
  // Our NAS domain
  // ===================================================

  if (
    requestedDomain ==
    String(NAS_DOMAIN)
  ) {

    // IPv4 A request
    if (qType == 1) {

      sendLocalNASReply(
        dnsBuffer,
        len,
        clientIP,
        clientPort,
        questionEnd
      );

      return;
    }


    // IPv6 AAAA request
    if (qType == 28) {

      sendEmptyReply(
        dnsBuffer,
        len,
        clientIP,
        clientPort,
        questionEnd
      );

      return;
    }
  }


  // ===================================================
  // Normal Internet domain
  // ===================================================

  forwardDNSQuery(
    dnsBuffer,
    len,
    clientIP,
    clientPort
  );
}


// =====================================================
// Connect WiFi
// =====================================================

void connectWiFi() {

  WiFi.mode(
    WIFI_STA
  );


  WiFi.begin(
    ssid,
    password
  );


  Serial.print(
    "Connecting to WiFi"
  );


  while (
    WiFi.status() !=
    WL_CONNECTED
  ) {

    delay(500);

    Serial.print(".");
  }


  Serial.println();


  Serial.println(
    "WiFi connected"
  );


  Serial.print(
    "DNS Node IP: "
  );

  Serial.println(
    WiFi.localIP()
  );


  Serial.print(
    "Gateway: "
  );

  Serial.println(
    WiFi.gatewayIP()
  );


  Serial.print(
    "Subnet: "
  );

  Serial.println(
    WiFi.subnetMask()
  );
}


// =====================================================
// Setup
// =====================================================

void setup() {

  Serial.begin(
    115200
  );


  delay(1000);


  Serial.println();

  Serial.println(
    "============================"
  );

  Serial.println(
    "Swiftwing NAS DNS Node"
  );

  Serial.println(
    "ESP32-C3"
  );

  Serial.println(
    "============================"
  );


  connectWiFi();


  // Local DNS server

  if (
    dnsServer.begin(
      DNS_PORT
    )
  ) {

    Serial.println(
      "DNS Server started on UDP 53"
    );

  } else {

    Serial.println(
      "ERROR: Could not start DNS server"
    );
  }


  // Upstream query socket

  upstreamUDP.begin(
    UPSTREAM_LOCAL_PORT
  );


  Serial.println();
  Serial.println(
    "Local override:"
  );

  Serial.print(
    NAS_DOMAIN
  );

  Serial.print(
    " -> "
  );

  Serial.println(
    NAS_IP
  );


  Serial.println();

  Serial.println(
    "Upstream DNS:"
  );

  Serial.println(
    UPSTREAM_DNS
  );


  Serial.println();

  Serial.println(
    "DNS Node ONLINE"
  );

  Serial.println(
    "============================"
  );
}


// =====================================================
// Loop
// =====================================================

void loop() {

  if (
    WiFi.status() !=
    WL_CONNECTED
  ) {

    Serial.println(
      "WiFi disconnected"
    );


    dnsServer.stop();

    upstreamUDP.stop();


    connectWiFi();


    dnsServer.begin(
      DNS_PORT
    );


    upstreamUDP.begin(
      UPSTREAM_LOCAL_PORT
    );
  }


  processDNSRequest();


  delay(1);
}