#include <WiFi.h>
#include <WiFiUdp.h>
#include <WebServer.h>
#include "FS.h"
#include "SD_MMC.h"
#include "esp_system.h"

// =====================================================
// WiFi
// =====================================================

const char* ssid = "BaBaWu";
const char* password = "95042700Wu$";

// =====================================================
// NAS Login
// =====================================================

// 登录 NAS 时使用，不是 WiFi 密码
const char* NAS_USERNAME = "BaBaWu";

// 一定改成你自己的强密码
const char* NAS_PASSWORD = "95042700";

// 30 minutes
const unsigned long SESSION_TIMEOUT = 30UL * 60UL * 1000UL;

String activeSessionToken = "";
unsigned long sessionLastActivity = 0;

// =====================================================
// Web Server
// =====================================================

WebServer server(80);

File uploadFile;
bool uploadAuthorized = false;

// We need to read Cookie header
const char* headerKeys[] = {
  "Cookie"
};

// =====================================================
// Node Discovery
// =====================================================

WiFiUDP discoveryUDP;

const uint16_t DISCOVERY_PORT = 4210;

const unsigned long DISCOVERY_INTERVAL = 3000;
const unsigned long NODE_TIMEOUT = 10000;

unsigned long lastDiscovery = 0;
unsigned long lastNode2Seen = 0;

IPAddress node2IP;

bool node2Online = false;

uint32_t node2FreeHeap = 0;
uint32_t node2Uptime = 0;

// =====================================================
// Utility
// =====================================================

String htmlEscape(String text) {
  text.replace("&", "&amp;");
  text.replace("<", "&lt;");
  text.replace(">", "&gt;");
  text.replace("\"", "&quot;");
  text.replace("'", "&#39;");
  return text;
}

String urlEncode(const String &str) {
  String encoded = "";
  const char hex[] = "0123456789ABCDEF";

  for (unsigned int i = 0; i < str.length(); i++) {
    unsigned char c = str[i];

    if (
      (c >= 'a' && c <= 'z') ||
      (c >= 'A' && c <= 'Z') ||
      (c >= '0' && c <= '9') ||
      c == '-' ||
      c == '_' ||
      c == '.' ||
      c == '~'
    ) {
      encoded += (char)c;
    } else {
      encoded += '%';
      encoded += hex[c >> 4];
      encoded += hex[c & 15];
    }
  }

  return encoded;
}

String normalizePath(String path) {
  if (path.length() == 0) {
    return "/";
  }

  if (!path.startsWith("/")) {
    path = "/" + path;
  }

  while (path.indexOf("//") >= 0) {
    path.replace("//", "/");
  }

  if (
    path.length() > 1 &&
    path.endsWith("/")
  ) {
    path.remove(path.length() - 1);
  }

  // Prevent path traversal
  if (path.indexOf("..") >= 0) {
    return "/";
  }

  return path;
}

String fileNameOnly(String path) {
  int index = path.lastIndexOf('/');

  if (index >= 0) {
    return path.substring(index + 1);
  }

  return path;
}

String parentPath(String path) {
  path = normalizePath(path);

  if (path == "/") {
    return "/";
  }

  int index = path.lastIndexOf('/');

  if (index <= 0) {
    return "/";
  }

  return path.substring(0, index);
}

String joinPath(String folder, String name) {
  folder = normalizePath(folder);

  if (folder == "/") {
    return "/" + name;
  }

  return folder + "/" + name;
}

// =====================================================
// Hidden System Files
// =====================================================

bool shouldHide(String name) {
  return (
    name == "System Volume Information" ||
    name == "$RECYCLE.BIN" ||
    name == ".Trashes" ||
    name == ".Spotlight-V100" ||
    name == ".fseventsd"
  );
}

// =====================================================
// File Size
// =====================================================

String humanSize(uint64_t bytes) {
  if (bytes < 1024) {
    return String(bytes) + " B";
  }

  if (bytes < 1024ULL * 1024ULL) {
    return String(bytes / 1024.0, 1) + " KB";
  }

  if (bytes < 1024ULL * 1024ULL * 1024ULL) {
    return String(
      bytes / (1024.0 * 1024.0),
      1
    ) + " MB";
  }

  return String(
    bytes / (1024.0 * 1024.0 * 1024.0),
    2
  ) + " GB";
}

// =====================================================
// MIME Types
// =====================================================

String getContentType(String filename) {
  filename.toLowerCase();

  if (filename.endsWith(".pdf"))  return "application/pdf";
  if (filename.endsWith(".txt"))  return "text/plain";
  if (filename.endsWith(".html")) return "text/html";
  if (filename.endsWith(".htm"))  return "text/html";
  if (filename.endsWith(".jpg"))  return "image/jpeg";
  if (filename.endsWith(".jpeg")) return "image/jpeg";
  if (filename.endsWith(".png"))  return "image/png";
  if (filename.endsWith(".gif"))  return "image/gif";
  if (filename.endsWith(".zip"))  return "application/zip";
  if (filename.endsWith(".mp3"))  return "audio/mpeg";
  if (filename.endsWith(".mp4"))  return "video/mp4";
  if (filename.endsWith(".json")) return "application/json";
  if (filename.endsWith(".csv"))  return "text/csv";

  return "application/octet-stream";
}

// =====================================================
// Authentication
// =====================================================

String generateSessionToken() {
  char buffer[40];

  uint32_t a = esp_random();
  uint32_t b = esp_random();
  uint32_t c = esp_random();
  uint32_t d = esp_random();

  snprintf(
    buffer,
    sizeof(buffer),
    "%08lx%08lx%08lx%08lx",
    (unsigned long)a,
    (unsigned long)b,
    (unsigned long)c,
    (unsigned long)d
  );

  return String(buffer);
}

bool isAuthenticated() {
  if (activeSessionToken.length() == 0) {
    return false;
  }

  // Session timeout
  if (
    millis() - sessionLastActivity >
    SESSION_TIMEOUT
  ) {
    activeSessionToken = "";
    return false;
  }

  if (!server.hasHeader("Cookie")) {
    return false;
  }

  String cookie = server.header("Cookie");

  String target =
    "SWIFTWING_SESSION=" +
    activeSessionToken;

  if (cookie.indexOf(target) >= 0) {
    sessionLastActivity = millis();
    return true;
  }

  return false;
}

bool requireAuth() {
  if (isAuthenticated()) {
    return true;
  }

  server.sendHeader(
    "Location",
    "/login"
  );

  server.send(303);

  return false;
}

// =====================================================
// Login Page
// =====================================================

void showLoginPage(
  String errorMessage = ""
) {
  String html = R"rawliteral(
<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<meta
  name="viewport"
  content="width=device-width, initial-scale=1.0"
>

<title>Swiftwing NAS Login</title>

<style>

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  min-height: 100vh;

  display: flex;
  align-items: center;
  justify-content: center;

  background: #f4f6f8;

  font-family:
    -apple-system,
    BlinkMacSystemFont,
    "Segoe UI",
    Arial,
    sans-serif;

  color: #202124;
}

.login-card {
  width: 100%;
  max-width: 390px;

  background: white;

  padding: 34px;

  border-radius: 18px;

  box-shadow:
    0 8px 30px
    rgba(0,0,0,0.08);
}

.logo {
  font-size: 26px;
  font-weight: 750;

  margin-bottom: 5px;
}

.subtitle {
  color: #7a7f87;

  margin-bottom: 28px;

  font-size: 14px;
}

label {
  display: block;

  margin-bottom: 7px;

  font-size: 13px;

  font-weight: 600;
}

input {
  width: 100%;

  padding: 12px 13px;

  margin-bottom: 18px;

  border:
    1px solid #d9dde3;

  border-radius: 9px;

  font-size: 15px;

  outline: none;
}

input:focus {
  border-color: #2774d9;
}

button {
  width: 100%;

  padding: 12px;

  border: none;

  border-radius: 9px;

  background: #2774d9;

  color: white;

  font-size: 15px;

  font-weight: 600;

  cursor: pointer;
}

button:hover {
  opacity: 0.9;
}

.error {
  background: #fff1f1;
  color: #c62828;

  padding: 10px 12px;

  border-radius: 8px;

  margin-bottom: 18px;

  font-size: 13px;
}

.status {
  margin-top: 22px;

  font-size: 12px;

  color: #888;

  text-align: center;
}

</style>

</head>

<body>

<div class="login-card">

  <div class="logo">
    Swiftwing NAS
  </div>

  <div class="subtitle">
    Sign in to access your storage
  </div>

)rawliteral";

  if (errorMessage.length() > 0) {
    html +=
      "<div class='error'>" +
      htmlEscape(errorMessage) +
      "</div>";
  }

  html += R"rawliteral(

<form
  method="POST"
  action="/login"
>

<label>
  Username
</label>

<input
  type="text"
  name="username"
  autocomplete="username"
  required
>

<label>
  Password
</label>

<input
  type="password"
  name="password"
  autocomplete="current-password"
  required
>

<button type="submit">
  Sign In
</button>

</form>

<div class="status">
  Swiftwing NAS Master
</div>

</div>

</body>

</html>
)rawliteral";

  server.send(
    200,
    "text/html; charset=utf-8",
    html
  );
}

void handleLoginGET() {
  if (isAuthenticated()) {
    server.sendHeader(
      "Location",
      "/"
    );

    server.send(303);

    return;
  }

  showLoginPage();
}

void handleLoginPOST() {
  if (
    !server.hasArg("username") ||
    !server.hasArg("password")
  ) {
    showLoginPage(
      "Please enter username and password."
    );

    return;
  }

  String username =
    server.arg("username");

  String userPassword =
    server.arg("password");

  if (
    username == NAS_USERNAME &&
    userPassword == NAS_PASSWORD
  ) {
    activeSessionToken =
      generateSessionToken();

    sessionLastActivity =
      millis();

    String cookie =
      "SWIFTWING_SESSION=" +
      activeSessionToken +
      "; Path=/; HttpOnly; SameSite=Lax";

    server.sendHeader(
      "Set-Cookie",
      cookie
    );

    server.sendHeader(
      "Location",
      "/"
    );

    server.send(303);

    Serial.println(
      "NAS login successful"
    );

    return;
  }

  Serial.println(
    "Failed NAS login attempt"
  );

  showLoginPage(
    "Incorrect username or password."
  );
}

void handleLogout() {
  activeSessionToken = "";

  server.sendHeader(
    "Set-Cookie",
    "SWIFTWING_SESSION=deleted; "
    "Path=/; "
    "Max-Age=0; "
    "HttpOnly; "
    "SameSite=Lax"
  );

  server.sendHeader(
    "Location",
    "/login"
  );

  server.send(303);
}

// =====================================================
// Breadcrumb
// =====================================================

String makeBreadcrumb(String path) {
  String result =
    "<a class='crumb' href='/?path=%2F'>Home</a>";

  if (path == "/") {
    return result;
  }

  String current = "";
  int start = 1;

  while (start < path.length()) {
    int slash =
      path.indexOf('/', start);

    String part;

    if (slash == -1) {
      part =
        path.substring(start);

      start =
        path.length();
    } else {
      part =
        path.substring(
          start,
          slash
        );

      start =
        slash + 1;
    }

    if (part.length() == 0) {
      continue;
    }

    current += "/" + part;

    result +=
      "<span class='separator'>"
      " / "
      "</span>";

    result +=
      "<a class='crumb' href='/?path=" +
      urlEncode(current) +
      "'>" +
      htmlEscape(part) +
      "</a>";
  }

  return result;
}

// =====================================================
// File Row
// =====================================================

String makeRow(
  String fullPath,
  String name,
  bool directory,
  uint64_t size,
  String currentPath
) {
  String encodedPath =
    urlEncode(fullPath);

  String encodedName =
    urlEncode(name);

  String encodedReturn =
    urlEncode(currentPath);

  String html =
    "<div class='file-row'>";

  // Name

  html +=
    "<div class='file-name'>";

  if (directory) {
    html +=
      "<div class='icon folder-icon'>DIR</div>";

    html +=
      "<a class='filename' href='/?path=" +
      encodedPath +
      "'>" +
      htmlEscape(name) +
      "</a>";
  } else {
    html +=
      "<div class='icon file-icon'>FILE</div>";

    html +=
      "<span class='filename'>" +
      htmlEscape(name) +
      "</span>";
  }

  html += "</div>";

  // Type

  html +=
    "<div class='file-type'>";

  if (directory) {
    html += "Folder";
  } else {
    int dot =
      name.lastIndexOf('.');

    if (dot >= 0) {
      String extension =
        name.substring(dot + 1);

      extension.toUpperCase();

      html += extension;
    } else {
      html += "File";
    }
  }

  html += "</div>";

  // Size

  html +=
    "<div class='file-size'>";

  if (directory) {
    html += "--";
  } else {
    html += humanSize(size);
  }

  html += "</div>";

  // Actions

  html +=
    "<div class='actions'>";

  if (directory) {
    html +=
      "<a class='button small' "
      "href='/?path=" +
      encodedPath +
      "'>Open</a>";
  } else {
    html +=
      "<a class='button small' "
      "href='/download?file=" +
      encodedPath +
      "'>Download</a>";
  }

  // Rename

  html +=
    "<button "
    "class='button small secondary' "
    "onclick=\"renameItem('";

  html += encodedPath;
  html += "','";
  html += encodedName;
  html += "','";
  html += encodedReturn;

  html +=
    "')\">Rename</button>";

  // Move

  html +=
    "<button "
    "class='button small secondary' "
    "onclick=\"moveItem('";

  html += encodedPath;
  html += "','";
  html += encodedReturn;

  html +=
    "')\">Move</button>";

  // Delete

  html +=
    "<button "
    "class='button small danger' "
    "onclick=\"deleteItem('";

  html += encodedPath;
  html += "','";
  html += encodedReturn;

  html +=
    "')\">Delete</button>";

  html += "</div>";
  html += "</div>";

  return html;
}

// =====================================================
// Search
// =====================================================

void appendSearchResults(
  String path,
  String query,
  String &html,
  int &count,
  int depth
) {
  if (
    depth > 12 ||
    count >= 100
  ) {
    return;
  }

  File dir =
    SD_MMC.open(path);

  if (
    !dir ||
    !dir.isDirectory()
  ) {
    return;
  }

  File item =
    dir.openNextFile();

  while (
    item &&
    count < 100
  ) {
    String fullPath =
      String(item.path());

    String name =
      fileNameOnly(fullPath);

    bool directory =
      item.isDirectory();

    uint64_t size =
      item.size();

    item.close();

    if (!shouldHide(name)) {
      String lowerName =
        name;

      lowerName.toLowerCase();

      if (
        lowerName.indexOf(query) >= 0
      ) {
        html +=
          makeRow(
            fullPath,
            name,
            directory,
            size,
            parentPath(fullPath)
          );

        count++;
      }

      if (directory) {
        appendSearchResults(
          fullPath,
          query,
          html,
          count,
          depth + 1
        );
      }
    }

    item =
      dir.openNextFile();
  }

  dir.close();
}

// =====================================================
// Node Discovery
// =====================================================

void sendNodeDiscovery() {
  discoveryUDP.beginPacket(
    IPAddress(
      255,
      255,
      255,
      255
    ),
    DISCOVERY_PORT
  );

  discoveryUDP.print(
    "RICKY_NAS_DISCOVER"
  );

  discoveryUDP.endPacket();
}

void checkNodeDiscovery() {
  int packetSize =
    discoveryUDP.parsePacket();

  while (packetSize) {
    char buffer[160];

    int len =
      discoveryUDP.read(
        buffer,
        sizeof(buffer) - 1
      );

    if (len > 0) {
      buffer[len] = '\0';
    }

    String message =
      String(buffer);

    if (
      message.startsWith(
        "RICKY_NODE|NODE2|"
      )
    ) {
      node2IP =
        discoveryUDP.remoteIP();

      lastNode2Seen =
        millis();

      node2Online = true;

      int p1 =
        message.indexOf('|');

      int p2 =
        message.indexOf(
          '|',
          p1 + 1
        );

      int p3 =
        message.indexOf(
          '|',
          p2 + 1
        );

      int p4 =
        message.indexOf(
          '|',
          p3 + 1
        );

      if (
        p3 >= 0 &&
        p4 >= 0
      ) {
        node2FreeHeap =
          message.substring(
            p3 + 1,
            p4
          ).toInt();

        node2Uptime =
          message.substring(
            p4 + 1
          ).toInt();
      }
    }

    packetSize =
      discoveryUDP.parsePacket();
  }

  if (
    node2Online &&
    millis() - lastNode2Seen >
    NODE_TIMEOUT
  ) {
    node2Online = false;
  }
}

// =====================================================
// Main NAS Page
// =====================================================

void showFiles() {
  if (!requireAuth()) {
    return;
  }

  String currentPath = "/";

  if (server.hasArg("path")) {
    currentPath =
      normalizePath(
        server.arg("path")
      );
  }

  File directory =
    SD_MMC.open(currentPath);

  if (
    !directory ||
    !directory.isDirectory()
  ) {
    server.send(
      404,
      "text/plain",
      "Folder not found"
    );

    return;
  }

  uint64_t totalBytes =
    SD_MMC.totalBytes();

  uint64_t usedBytes =
    SD_MMC.usedBytes();

  uint64_t freeBytes =
    totalBytes - usedBytes;

  float usedPercent = 0;

  if (totalBytes > 0) {
    usedPercent =
      ((float)usedBytes /
       (float)totalBytes) *
      100.0;
  }

  String searchQuery = "";

  if (server.hasArg("q")) {
    searchQuery =
      server.arg("q");

    searchQuery.trim();
  }

  String html = R"rawliteral(
<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<meta
  name="viewport"
  content="width=device-width, initial-scale=1.0"
>

<title>Swiftwing NAS</title>

<style>

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  background: #f5f6f8;

  font-family:
    -apple-system,
    BlinkMacSystemFont,
    "Segoe UI",
    Arial,
    sans-serif;

  color: #202124;
}

.topbar {
  height: 64px;

  background: white;

  border-bottom:
    1px solid #e3e5e8;

  display: flex;

  align-items: center;

  justify-content:
    space-between;

  padding: 0 30px;
}

.logo {
  font-size: 22px;
  font-weight: 700;
}

.top-right {
  display: flex;

  align-items: center;

  gap: 16px;
}

.status {
  font-size: 13px;
  color: #35a853;
}

.logout-button {
  border: none;

  background: #eef0f3;

  padding: 8px 12px;

  border-radius: 7px;

  cursor: pointer;

  color: #333;
}

.container {
  max-width: 1150px;

  margin: 28px auto;

  padding: 0 20px;
}

.card {
  background: white;

  border-radius: 14px;

  padding: 22px;

  margin-bottom: 18px;

  box-shadow:
    0 2px 8px
    rgba(0,0,0,0.05);
}

.breadcrumb {
  font-size: 15px;

  margin-bottom: 18px;
}

.crumb {
  color: #2774d9;
  text-decoration: none;
}

.crumb:hover {
  text-decoration: underline;
}

.separator {
  color: #888;
}

.search-box {
  display: flex;

  gap: 8px;

  margin-bottom: 20px;
}

.search-box input {
  flex: 1;

  padding: 11px 14px;

  border:
    1px solid #d7dbe0;

  border-radius: 9px;

  font-size: 14px;
}

.toolbar {
  display: flex;

  gap: 10px;

  flex-wrap: wrap;

  margin-bottom: 18px;
}

.forms {
  display: flex;

  gap: 12px;

  flex-wrap: wrap;

  margin-bottom: 22px;
}

.form-box {
  background: #f8f9fb;

  padding: 14px;

  border-radius: 10px;
}

input[type="text"] {
  padding: 8px;

  border:
    1px solid #ccc;

  border-radius: 6px;
}

input[type="file"] {
  max-width: 280px;
}

.button {
  display: inline-block;

  padding: 9px 14px;

  background: #2774d9;

  color: white;

  text-decoration: none;

  border: none;

  border-radius: 8px;

  cursor: pointer;

  font-size: 14px;
}

.button:hover {
  opacity: 0.88;
}

.secondary {
  background: #e8ebef;
  color: #333;
}

.danger {
  background: #ef5350;
}

.small {
  padding: 6px 10px;
  font-size: 12px;
}

.file-header,
.file-row {
  display: grid;

  grid-template-columns:
    minmax(250px, 3fr)
    1fr
    1fr
    2.7fr;

  align-items: center;

  gap: 10px;

  padding: 12px 10px;
}

.file-header {
  font-size: 12px;

  font-weight: 600;

  color: #777;

  border-bottom:
    1px solid #eee;
}

.file-row {
  border-bottom:
    1px solid #f0f0f0;

  min-height: 58px;
}

.file-row:hover {
  background: #f7f9fc;
}

.file-name {
  display: flex;

  align-items: center;

  gap: 10px;

  min-width: 0;
}

.filename {
  color: #202124;

  text-decoration: none;

  overflow: hidden;

  text-overflow: ellipsis;

  white-space: nowrap;
}

a.filename:hover {
  color: #2774d9;
}

.icon {
  width: 38px;
  height: 32px;

  border-radius: 7px;

  display: flex;

  justify-content: center;
  align-items: center;

  font-weight: 700;

  font-size: 9px;

  flex-shrink: 0;
}

.folder-icon {
  background: #dfeaff;
  color: #2774d9;
}

.file-icon {
  background: #e9ecef;
  color: #666;
}

.file-type,
.file-size {
  color: #666;

  font-size: 13px;
}

.actions {
  display: flex;

  gap: 6px;

  flex-wrap: wrap;
}

.storage-title {
  display: flex;

  justify-content:
    space-between;

  margin-bottom: 10px;

  font-size: 14px;
}

.storage-background {
  width: 100%;
  height: 10px;

  background: #e7e9ed;

  border-radius: 6px;

  overflow: hidden;
}

.storage-used {
  height: 100%;
  background: #2774d9;
}

.storage-details {
  color: #777;

  margin-top: 9px;

  font-size: 13px;
}

.node-row {
  display: flex;

  justify-content:
    space-between;

  align-items: center;

  padding: 15px 0;

  border-bottom:
    1px solid #eee;
}

.node-row:last-child {
  border-bottom: none;
}

.node-info {
  display: flex;

  align-items: center;

  gap: 12px;
}

.node-dot {
  width: 11px;
  height: 11px;

  border-radius: 50%;

  flex-shrink: 0;
}

.node-online {
  background: #34a853;
}

.node-offline {
  background: #ea4335;
}

.node-name {
  font-weight: 600;
}

.node-details {
  color: #777;

  font-size: 12px;

  margin-top: 4px;
}

.online-text {
  color: #34a853;
}

.offline-text {
  color: #ea4335;
}

.empty {
  padding: 30px;

  text-align: center;

  color: #888;
}

@media(max-width: 760px) {
  .file-header {
    display: none;
  }

  .file-row {
    grid-template-columns: 1fr;

    gap: 8px;
  }

  .file-type,
  .file-size {
    display: none;
  }

  .actions {
    padding-left: 48px;
  }

  .topbar {
    padding: 0 16px;
  }

  .status {
    display: none;
  }
}

</style>

<script>

function postTo(url, data) {
  const form =
    document.createElement("form");

  form.method = "POST";
  form.action = url;

  for (const key in data) {
    const input =
      document.createElement("input");

    input.type = "hidden";
    input.name = key;
    input.value = data[key];

    form.appendChild(input);
  }

  document.body.appendChild(form);

  form.submit();
}

function renameItem(
  encodedPath,
  encodedName,
  encodedReturn
) {
  const path =
    decodeURIComponent(
      encodedPath
    );

  const oldName =
    decodeURIComponent(
      encodedName
    );

  const returnPath =
    decodeURIComponent(
      encodedReturn
    );

  const newName =
    prompt(
      "New name:",
      oldName
    );

  if (!newName) {
    return;
  }

  if (newName === oldName) {
    return;
  }

  postTo(
    "/rename",
    {
      file: path,
      name: newName,
      return: returnPath
    }
  );
}

function moveItem(
  encodedPath,
  encodedReturn
) {
  const path =
    decodeURIComponent(
      encodedPath
    );

  const returnPath =
    decodeURIComponent(
      encodedReturn
    );

  const destination =
    prompt(
      "Move to folder path:",
      returnPath
    );

  if (!destination) {
    return;
  }

  postTo(
    "/move",
    {
      file: path,
      dest: destination,
      return: returnPath
    }
  );
}

function deleteItem(
  encodedPath,
  encodedReturn
) {
  if (
    !confirm(
      "Delete this item?"
    )
  ) {
    return;
  }

  postTo(
    "/delete",
    {
      file:
        decodeURIComponent(
          encodedPath
        ),

      return:
        decodeURIComponent(
          encodedReturn
        )
    }
  );
}

</script>

</head>

<body>

<div class="topbar">

  <div class="logo">
    Swiftwing NAS
  </div>

  <div class="top-right">

    <div class="status">
      Master Node Online
    </div>

    <form
      method="POST"
      action="/logout"
      style="margin:0;"
    >

      <button
        class="logout-button"
        type="submit"
      >
        Logout
      </button>

    </form>

  </div>

</div>

<div class="container">

<div class="card">

<div class="breadcrumb">

)rawliteral";

  html +=
    makeBreadcrumb(
      currentPath
    );

  html += "</div>";

  // Search

  html +=
    "<form "
    "class='search-box' "
    "method='GET' "
    "action='/'>";

  html +=
    "<input "
    "type='text' "
    "name='q' "
    "placeholder='Search entire NAS...' "
    "value='" +
    htmlEscape(
      searchQuery
    ) +
    "'>";

  html +=
    "<button "
    "class='button' "
    "type='submit'>"
    "Search"
    "</button>";

  html += "</form>";

  // Back

  if (
    currentPath != "/" &&
    searchQuery.length() == 0
  ) {
    html +=
      "<div class='toolbar'>";

    html +=
      "<a "
      "class='button secondary' "
      "href='/?path=" +
      urlEncode(
        parentPath(
          currentPath
        )
      ) +
      "'>Back</a>";

    html += "</div>";
  }

  // Upload / New Folder

  if (
    searchQuery.length() == 0
  ) {
    html +=
      "<div class='forms'>";

    html +=
      "<div class='form-box'>";

    html +=
      "<form "
      "method='POST' "
      "action='/upload?path=" +
      urlEncode(currentPath) +
      "' "
      "enctype='multipart/form-data'>";

    html +=
      "<input "
      "type='file' "
      "name='file' "
      "required> ";

    html +=
      "<input "
      "class='button' "
      "type='submit' "
      "value='Upload'>";

    html +=
      "</form>"
      "</div>";

    html +=
      "<div class='form-box'>";

    html +=
      "<form "
      "method='POST' "
      "action='/mkdir?path=" +
      urlEncode(currentPath) +
      "'>";

    html +=
      "<input "
      "type='text' "
      "name='name' "
      "placeholder='Folder name' "
      "required> ";

    html +=
      "<input "
      "class='button' "
      "type='submit' "
      "value='New Folder'>";

    html +=
      "</form>"
      "</div>";

    html += "</div>";
  }

  html += R"rawliteral(

<div class="file-header">

  <div>Name</div>
  <div>Type</div>
  <div>Size</div>
  <div>Actions</div>

</div>

)rawliteral";

  // Search results

  if (
    searchQuery.length() > 0
  ) {
    directory.close();

    String query =
      searchQuery;

    query.toLowerCase();

    html +=
      "<h3>Search results for: " +
      htmlEscape(
        searchQuery
      ) +
      "</h3>";

    int resultCount = 0;

    appendSearchResults(
      "/",
      query,
      html,
      resultCount,
      0
    );

    if (
      resultCount == 0
    ) {
      html +=
        "<div class='empty'>"
        "No files found."
        "</div>";
    } else {
      html +=
        "<p style='color:#777;'>" +
        String(resultCount) +
        " result(s)"
        "</p>";
    }
  } else {
    int itemCount = 0;

    // Folders first

    File item =
      directory.openNextFile();

    while (item) {
      if (
        item.isDirectory()
      ) {
        String fullPath =
          String(item.path());

        String name =
          fileNameOnly(
            fullPath
          );

        if (
          !shouldHide(name)
        ) {
          html +=
            makeRow(
              fullPath,
              name,
              true,
              0,
              currentPath
            );

          itemCount++;
        }
      }

      item.close();

      item =
        directory.openNextFile();
    }

    directory.close();

    // Files

    directory =
      SD_MMC.open(
        currentPath
      );

    item =
      directory.openNextFile();

    while (item) {
      if (
        !item.isDirectory()
      ) {
        String fullPath =
          String(item.path());

        String name =
          fileNameOnly(
            fullPath
          );

        if (
          !shouldHide(name)
        ) {
          html +=
            makeRow(
              fullPath,
              name,
              false,
              item.size(),
              currentPath
            );

          itemCount++;
        }
      }

      item.close();

      item =
        directory.openNextFile();
    }

    directory.close();

    if (
      itemCount == 0
    ) {
      html +=
        "<div class='empty'>"
        "This folder is empty."
        "</div>";
    }
  }

  html += "</div>";

  // ===================================================
  // Nodes
  // ===================================================

  html +=
    "<div class='card'>";

  html +=
    "<h3>NAS Nodes</h3>";

  // Master

  html +=
    "<div class='node-row'>";

  html +=
    "<div class='node-info'>";

  html +=
    "<div "
    "class='node-dot "
    "node-online'>"
    "</div>";

  html += "<div>";

  html +=
    "<div class='node-name'>"
    "Master Node"
    "</div>";

  html +=
    "<div "
    "class='node-details'>";

  html +=
    WiFi.localIP().toString();

  html +=
    " &nbsp; | &nbsp; ";

  html +=
    humanSize(
      SD_MMC.totalBytes()
    );

  html += "</div>";
  html += "</div>";
  html += "</div>";

  html +=
    "<strong "
    "class='online-text'>"
    "Online"
    "</strong>";

  html += "</div>";

  // Node 2

  html +=
    "<div class='node-row'>";

  html +=
    "<div class='node-info'>";

  if (node2Online) {
    html +=
      "<div "
      "class='node-dot "
      "node-online'>"
      "</div>";
  } else {
    html +=
      "<div "
      "class='node-dot "
      "node-offline'>"
      "</div>";
  }

  html += "<div>";

  html +=
    "<div class='node-name'>"
    "Storage Node 2"
    "</div>";

  html +=
    "<div "
    "class='node-details'>";

  if (node2Online) {
    html +=
      node2IP.toString();

    html +=
      " &nbsp; | &nbsp; "
      "Free RAM: ";

    html +=
      humanSize(
        node2FreeHeap
      );

    html +=
      " &nbsp; | &nbsp; "
      "Uptime: ";

    html +=
      String(
        node2Uptime
      );

    html += " sec";
  } else {
    html +=
      "Waiting for Node 2...";
  }

  html += "</div>";
  html += "</div>";
  html += "</div>";

  if (node2Online) {
    html +=
      "<strong "
      "class='online-text'>"
      "Online"
      "</strong>";
  } else {
    html +=
      "<strong "
      "class='offline-text'>"
      "Offline"
      "</strong>";
  }

  html += "</div>";

  html += "</div>";

  // ===================================================
  // Storage
  // ===================================================

  html +=
    "<div class='card'>";

  html +=
    "<div "
    "class='storage-title'>";

  html +=
    "<strong>"
    "Master Storage"
    "</strong>";

  html +=
    "<span>" +
    String(
      usedPercent,
      1
    ) +
    "% used</span>";

  html += "</div>";

  html +=
    "<div "
    "class='storage-background'>";

  html +=
    "<div "
    "class='storage-used' "
    "style='width:" +
    String(
      usedPercent,
      1
    ) +
    "%'>"
    "</div>";

  html += "</div>";

  html +=
    "<div "
    "class='storage-details'>";

  html +=
    humanSize(
      usedBytes
    );

  html +=
    " used &nbsp; | &nbsp; ";

  html +=
    humanSize(
      freeBytes
    );

  html +=
    " free &nbsp; | &nbsp; ";

  html +=
    humanSize(
      totalBytes
    );

  html +=
    " total"
    "</div>";

  html += "</div>";

  html += R"rawliteral(

</div>

</body>

</html>
)rawliteral";

  server.send(
    200,
    "text/html; charset=utf-8",
    html
  );
}

// =====================================================
// Download
// =====================================================

void downloadFile() {
  if (!requireAuth()) {
    return;
  }

  if (
    !server.hasArg("file")
  ) {
    server.send(
      400,
      "text/plain",
      "Missing file"
    );

    return;
  }

  String path =
    normalizePath(
      server.arg("file")
    );

  File file =
    SD_MMC.open(
      path,
      FILE_READ
    );

  if (
    !file ||
    file.isDirectory()
  ) {
    server.send(
      404,
      "text/plain",
      "File not found"
    );

    return;
  }

  String name =
    fileNameOnly(path);

  server.sendHeader(
    "Content-Disposition",
    "attachment; filename=\"" +
    name +
    "\""
  );

  server.sendHeader(
    "Cache-Control",
    "no-cache"
  );

  Serial.print(
    "Downloading: "
  );

  Serial.println(name);

  Serial.print(
    "Size: "
  );

  Serial.println(
    file.size()
  );

  size_t sent =
    server.streamFile(
      file,
      getContentType(name)
    );

  Serial.print(
    "Bytes sent: "
  );

  Serial.println(sent);

  file.close();
}

// =====================================================
// Upload
// =====================================================

void handleUpload() {
  HTTPUpload& upload =
    server.upload();

  if (
    upload.status ==
    UPLOAD_FILE_START
  ) {
    uploadAuthorized =
      isAuthenticated();

    if (!uploadAuthorized) {
      Serial.println(
        "Blocked unauthorized upload"
      );

      return;
    }
  }

  if (!uploadAuthorized) {
    return;
  }

  String folder = "/";

  if (
    server.hasArg("path")
  ) {
    folder =
      normalizePath(
        server.arg("path")
      );
  }

  if (
    upload.status ==
    UPLOAD_FILE_START
  ) {
    String filename =
      upload.filename;

    filename.replace(
      "\\",
      "/"
    );

    int slash =
      filename.lastIndexOf('/');

    if (slash >= 0) {
      filename =
        filename.substring(
          slash + 1
        );
    }

    if (
      filename.indexOf("..") >= 0 ||
      filename.length() == 0
    ) {
      uploadAuthorized = false;
      return;
    }

    String path =
      joinPath(
        folder,
        filename
      );

    Serial.print(
      "Uploading: "
    );

    Serial.println(path);

    if (
      SD_MMC.exists(path)
    ) {
      SD_MMC.remove(path);
    }

    uploadFile =
      SD_MMC.open(
        path,
        FILE_WRITE
      );
  }

  else if (
    upload.status ==
    UPLOAD_FILE_WRITE
  ) {
    if (uploadFile) {
      uploadFile.write(
        upload.buf,
        upload.currentSize
      );
    }
  }

  else if (
    upload.status ==
    UPLOAD_FILE_END
  ) {
    if (uploadFile) {
      uploadFile.close();
    }

    Serial.print(
      "Upload complete: "
    );

    Serial.print(
      upload.totalSize
    );

    Serial.println(
      " bytes"
    );

    uploadAuthorized = false;
  }

  else if (
    upload.status ==
    UPLOAD_FILE_ABORTED
  ) {
    if (uploadFile) {
      uploadFile.close();
    }

    uploadAuthorized = false;

    Serial.println(
      "Upload aborted"
    );
  }
}

void finishUploadRequest() {
  if (!requireAuth()) {
    return;
  }

  String folder = "/";

  if (
    server.hasArg("path")
  ) {
    folder =
      normalizePath(
        server.arg("path")
      );
  }

  server.sendHeader(
    "Location",
    "/?path=" +
    urlEncode(folder)
  );

  server.send(303);
}

// =====================================================
// New Folder
// =====================================================

void createFolder() {
  if (!requireAuth()) {
    return;
  }

  String folder = "/";

  if (
    server.hasArg("path")
  ) {
    folder =
      normalizePath(
        server.arg("path")
      );
  }

  if (
    !server.hasArg("name")
  ) {
    server.send(
      400,
      "text/plain",
      "Missing folder name"
    );

    return;
  }

  String name =
    server.arg("name");

  name.trim();

  if (
    name.length() == 0 ||
    name.indexOf("/") >= 0 ||
    name.indexOf("\\") >= 0 ||
    name.indexOf("..") >= 0
  ) {
    server.send(
      400,
      "text/plain",
      "Invalid folder name"
    );

    return;
  }

  String newFolder =
    joinPath(
      folder,
      name
    );

  if (
    SD_MMC.exists(
      newFolder
    )
  ) {
    server.send(
      409,
      "text/plain",
      "Folder already exists"
    );

    return;
  }

  if (
    !SD_MMC.mkdir(
      newFolder
    )
  ) {
    server.send(
      500,
      "text/plain",
      "Failed to create folder"
    );

    return;
  }

  server.sendHeader(
    "Location",
    "/?path=" +
    urlEncode(folder)
  );

  server.send(303);
}

// =====================================================
// Delete
// =====================================================

void deleteItem() {
  if (!requireAuth()) {
    return;
  }

  if (
    !server.hasArg("file")
  ) {
    server.send(
      400,
      "text/plain",
      "Missing file"
    );

    return;
  }

  String path =
    normalizePath(
      server.arg("file")
    );

  String returnPath = "/";

  if (
    server.hasArg("return")
  ) {
    returnPath =
      normalizePath(
        server.arg("return")
      );
  }

  if (path == "/") {
    server.send(
      403,
      "text/plain",
      "Cannot delete root"
    );

    return;
  }

  File item =
    SD_MMC.open(path);

  if (!item) {
    server.send(
      404,
      "text/plain",
      "Item not found"
    );

    return;
  }

  bool directory =
    item.isDirectory();

  item.close();

  bool result = false;

  if (directory) {
    result =
      SD_MMC.rmdir(path);
  } else {
    result =
      SD_MMC.remove(path);
  }

  if (!result) {
    server.send(
      500,
      "text/plain",
      "Delete failed. Folder may not be empty."
    );

    return;
  }

  server.sendHeader(
    "Location",
    "/?path=" +
    urlEncode(
      returnPath
    )
  );

  server.send(303);
}

// =====================================================
// Rename
// =====================================================

void renameItem() {
  if (!requireAuth()) {
    return;
  }

  if (
    !server.hasArg("file") ||
    !server.hasArg("name")
  ) {
    server.send(
      400,
      "text/plain",
      "Missing parameter"
    );

    return;
  }

  String oldPath =
    normalizePath(
      server.arg("file")
    );

  String newName =
    server.arg("name");

  newName.trim();

  if (
    oldPath == "/" ||
    newName.length() == 0 ||
    newName.indexOf("/") >= 0 ||
    newName.indexOf("\\") >= 0 ||
    newName.indexOf("..") >= 0
  ) {
    server.send(
      400,
      "text/plain",
      "Invalid rename"
    );

    return;
  }

  String newPath =
    joinPath(
      parentPath(oldPath),
      newName
    );

  if (
    SD_MMC.exists(
      newPath
    )
  ) {
    server.send(
      409,
      "text/plain",
      "Name already exists"
    );

    return;
  }

  if (
    !SD_MMC.rename(
      oldPath,
      newPath
    )
  ) {
    server.send(
      500,
      "text/plain",
      "Rename failed"
    );

    return;
  }

  String returnPath =
    parentPath(
      newPath
    );

  if (
    server.hasArg("return")
  ) {
    returnPath =
      normalizePath(
        server.arg("return")
      );
  }

  server.sendHeader(
    "Location",
    "/?path=" +
    urlEncode(
      returnPath
    )
  );

  server.send(303);
}

// =====================================================
// Move
// =====================================================

void moveItem() {
  if (!requireAuth()) {
    return;
  }

  if (
    !server.hasArg("file") ||
    !server.hasArg("dest")
  ) {
    server.send(
      400,
      "text/plain",
      "Missing parameter"
    );

    return;
  }

  String oldPath =
    normalizePath(
      server.arg("file")
    );

  String destination =
    normalizePath(
      server.arg("dest")
    );

  if (oldPath == "/") {
    server.send(
      403,
      "text/plain",
      "Cannot move root"
    );

    return;
  }

  File destinationFolder =
    SD_MMC.open(
      destination
    );

  if (
    !destinationFolder ||
    !destinationFolder.isDirectory()
  ) {
    if (destinationFolder) {
      destinationFolder.close();
    }

    server.send(
      400,
      "text/plain",
      "Destination folder does not exist"
    );

    return;
  }

  destinationFolder.close();

  File source =
    SD_MMC.open(
      oldPath
    );

  if (!source) {
    server.send(
      404,
      "text/plain",
      "Source not found"
    );

    return;
  }

  bool sourceIsDirectory =
    source.isDirectory();

  source.close();

  if (
    sourceIsDirectory &&
    (
      destination == oldPath ||
      destination.startsWith(
        oldPath + "/"
      )
    )
  ) {
    server.send(
      400,
      "text/plain",
      "Cannot move folder into itself"
    );

    return;
  }

  String newPath =
    joinPath(
      destination,
      fileNameOnly(
        oldPath
      )
    );

  if (newPath == oldPath) {
    server.sendHeader(
      "Location",
      "/?path=" +
      urlEncode(
        destination
      )
    );

    server.send(303);

    return;
  }

  if (
    SD_MMC.exists(
      newPath
    )
  ) {
    server.send(
      409,
      "text/plain",
      "Destination already contains this name"
    );

    return;
  }

  if (
    !SD_MMC.rename(
      oldPath,
      newPath
    )
  ) {
    server.send(
      500,
      "text/plain",
      "Move failed"
    );

    return;
  }

  String returnPath = "/";

  if (
    server.hasArg("return")
  ) {
    returnPath =
      normalizePath(
        server.arg("return")
      );
  }

  server.sendHeader(
    "Location",
    "/?path=" +
    urlEncode(
      returnPath
    )
  );

  server.send(303);
}

// =====================================================
// Setup
// =====================================================

void setup() {
  Serial.begin(115200);

  delay(1000);

  Serial.println();

  Serial.println(
    "============================"
  );

  Serial.println(
    "Starting Swiftwing NAS"
  );

  Serial.println(
    "============================"
  );

  // SD

  Serial.println(
    "Starting SD card..."
  );

  if (!SD_MMC.begin()) {
    Serial.println(
      "SD card failed!"
    );

    return;
  }

  Serial.println(
    "SD card ready!"
  );

  Serial.print(
    "SD size: "
  );

  Serial.println(
    humanSize(
      SD_MMC.totalBytes()
    )
  );

  // WiFi

  WiFi.mode(
    WIFI_STA
  );

  WiFi.begin(
    ssid,
    password
  );

  Serial.print(
    "Connecting to WiFi"
  );

  while (
    WiFi.status() !=
    WL_CONNECTED
  ) {
    delay(500);

    Serial.print(".");
  }

  Serial.println();

  Serial.println(
    "WiFi connected!"
  );

  Serial.print(
    "Master IP: "
  );

  Serial.println(
    WiFi.localIP()
  );

  // UDP discovery

  discoveryUDP.begin(
    DISCOVERY_PORT
  );

  // Cookie header

  server.collectHeaders(
    headerKeys,
    1
  );

  // Login

  server.on(
    "/login",
    HTTP_GET,
    handleLoginGET
  );

  server.on(
    "/login",
    HTTP_POST,
    handleLoginPOST
  );

  server.on(
    "/logout",
    HTTP_POST,
    handleLogout
  );

  // NAS

  server.on(
    "/",
    HTTP_GET,
    showFiles
  );

  server.on(
    "/download",
    HTTP_GET,
    downloadFile
  );

  server.on(
    "/delete",
    HTTP_POST,
    deleteItem
  );

  server.on(
    "/rename",
    HTTP_POST,
    renameItem
  );

  server.on(
    "/move",
    HTTP_POST,
    moveItem
  );

  server.on(
    "/mkdir",
    HTTP_POST,
    createFolder
  );

  server.on(
    "/upload",
    HTTP_POST,
    finishUploadRequest,
    handleUpload
  );

  server.onNotFound(
    []() {
      if (!isAuthenticated()) {
        server.sendHeader(
          "Location",
          "/login"
        );

        server.send(303);

        return;
      }

      server.send(
        404,
        "text/plain",
        "Not found"
      );
    }
  );

  server.begin();

  Serial.println(
    "Web server started!"
  );

  Serial.println(
    "Login protection enabled!"
  );

  Serial.println();

  Serial.print(
    "Local: http://"
  );

  Serial.println(
    WiFi.localIP()
  );

  Serial.println(
    "Remote:"
  );

  Serial.println(
    "http://swiftwingnas.tplinkdns.com"
  );

  Serial.println(
    "============================"
  );
}

// =====================================================
// Loop
// =====================================================

void loop() {
  server.handleClient();

  checkNodeDiscovery();

  if (
    millis() - lastDiscovery >
    DISCOVERY_INTERVAL
  ) {
    lastDiscovery =
      millis();

    sendNodeDiscovery();
  }
}