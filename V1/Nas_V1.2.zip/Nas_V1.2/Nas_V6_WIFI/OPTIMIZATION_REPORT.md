# Swiftwing NAS 优化记录

基线：用户提供的 `D:\Esp32 Nas\Nas_V6_WIFI.zip`。Monitor 节点按用户要求由 ESP8266 替换为标准 ESP32 Dev Module / ESP32-WROOM-32；监控状态字段改为 `ESP32`，Master 仍兼容旧 `ESP8266` 状态字段。Wi-Fi 配网协议、通信端口、API 路由、域名及其他页面功能保留。

## 修改

- **Master：**三个 HTML 页面改为在固件中存储 gzip 数据，并为对应响应发送 `Content-Encoding: gzip`。页面解压后与基线逐字节相同。空闲主循环的等待从 1 ms 调为 5 ms；Master 仍持续提供恢复 AP。监控 UI 标签按经过白名单检查的 ESP32/ESP8266 状态字段显示。
- **Node1 / Node2：**上传先汇集到 8 KiB 缓冲区再写入 SD；上传和下载共用原有大小的传输缓冲区。处理短写入、结束时剩余数据、异常中断和未收到结束回调的请求。传输时关闭 Wi-Fi 省电以保持吞吐，结束 2 秒后恢复最低级别的 modem sleep。持续传输数据时每 500 ms 最多检查一次 UDP 节点发现，减少 Master 状态页把忙碌节点标为离线的情况。发现回复只读取一次总容量和已用容量。
- **C3 DNS：**启用 Wi-Fi modem sleep；本地域名 DNS 回复复用接收缓冲区，减少单次调用的栈占用，并为 A 记录增加长度边界检查。等待上游 DNS 时的轮询间隔从 1 ms 调为 5 ms，减少忙转；最坏增加约 4 ms 的响应检测延迟。
- **ESP32 Monitor：**监控程序迁移到标准 ESP32 Dev Module，使用 ESP32 Wi-Fi、HTTPClient 和 EEPROM 库；使用 `WiFi.persistent(false)` 保持显式 EEPROM 配网记录、不把连接配置写入 SDK 区。连接后启用 minimum modem sleep，将空闲循环等待从 1 ms 调为 10 ms。可选 SSD1306 OLED 默认关闭；启用时 SDA/SCL 使用 GPIO21/22。

## 已完成的检查

- Arduino CLI 1.5.1 编译通过：Master、Node1、Node2、ESP32 Monitor 使用 `esp32:esp32:esp32` 和 ESP32 core 3.3.11；C3 使用 `esp32:esp32:esp32c3` 和相同 core。OLED 默认关闭，未启用额外显示库。
- Master 三个 HTML 页面原始总计 50,278 B，gzip 后 15,862 B（减少 68.45%）。逐页解压内容的 SHA-256 与原附件一致。四个页面发送路径均带 gzip 响应头。
- 用本机浏览器通过 gzip 响应检查了文件页、系统状态页和 Wi-Fi 配网页。通过本地模拟 API，文件列表、五板状态、Wi-Fi 扫描列表和选中网络后的密码表单均正常显示；390 px 窄屏下控件可访问，浏览器没有脚本错误。此项验证使用模拟数据，不代表实机 API 已验证。
- Master 及两个存储节点的 `server.on` 路由列表与原附件相同；两个存储节点的共用实现保持一致。
- 用 Arduino CLI 1.5.1 和 ESP32 core 3.3.11 构建：Master 1,019,148 → 985,284 B（减少 33,864 B）；Node1 1,045,716 → 1,046,608 B（增加 892 B）；Node2 1,024,592 → 1,025,464 B（增加 872 B）；C3 1,018,981 → 1,018,967 B（减少 14 B）。这四个原有板型合计减少 32,114 B。新 ESP32 Monitor 构建为 953,760 B，编译期全局 RAM 为 49,088 B；它替换了原 ESP8266 板，因此两种芯片的固件尺寸不直接比较。Master 编译期全局 RAM 增加 16 B，Node1/Node2 各增加 16 B，C3 不变。

## UI 更新（V7.6.1）

- Master 的文件管理、登录、系统状态和 Wi-Fi 配网页统一为深钴蓝工业控制台样式。文件区增加边界留白，主存储离线时显示占位值；加入轻量指针光感、列表渐进入场、上传进度光带、按钮回弹和 Wi-Fi 面板流畅展开。支持系统减少动态效果设置，不加载外部动效库。
- 可编辑页面位于 Swiftwing_Master/ui。修改 HTML/CSS 后，在 Swiftwing_Master 目录运行 python .\build_webui.py，将四个页面重新内嵌到固件；三个系统页和登录页都从 flash 以 gzip 形式发送。
- 四页 HTML 合计 65,116 B，gzip 后 21,043 B。与 V7.5.6 的三个 gzip 页面加未压缩登录页相比，嵌入 UI 增加 2,971 B；上传及存储节点代码未改。
- 本轮静态验证确认 gzip 数组与可编辑页面一致、文件管理 DOM ID 与 API 路由保持完整、登录仍提交到 /login，并用 Node 检查页面脚本语法。此前浏览器安全策略明确拒绝打开本地 file:// 预览并禁止绕过，因此本轮没有截图视觉验证；这也不是实机验证。本轮固件未重新编译或刷写。

## UI 版本标签（V1.1.3）

- Master 的 `UI_BUILD` 是 `/ui-version` 的唯一版本来源；文件管理页和 Wi-Fi 设置页在载入时读取该接口，标签不再各自写死版本号。
- 修改 `UI_BUILD` 或页面后，在 `Swiftwing_Master` 目录运行 `python .\build_webui.py`，再只刷写 Master。其它板子的程序和 UI 路由不需要更新。
- 本轮已检查四个 gzip 页面与可编辑 HTML 一致，并确认旧的 V7.6.1 标签已移除。当前环境没有 Arduino CLI，因此没有重新编译固件或进行实机验证。

## 账号申请与审核（V1.2.0）

- 登录页增加“Request access”流程。申请人设置自己的用户名与密码；Master 将账号以待审核状态写入独立 Preferences NVS 命名空间，用户名最多 8 个。通过审批前不能登录。
- 密码使用每个账号独立随机盐和 PBKDF2-HMAC-SHA256 派生值保存；登录后使用独立会话名，管理员可批准、拒绝或撤销账号。撤销会清除该账号现有会话。
- 登录主账号可在文件控制台打开 Access requests 审核列表。Wi-Fi 配置和账号管理保留给主账号；普通获批账号使用现有共享卷与相同文件权限，没有用户私有目录。
- 已对页面脚本运行 Node 语法检查、验证嵌入 gzip 页面与 HTML 源一致，并检查权限限制与账号路由。Master 使用 Arduino CLI 1.5.1、ESP32 core 3.3.12 编译通过；未连接实机，因此设备端 NVS 持久化和登录流程仍需上板验证。

## 外观与文件浏览（V1.2.1）

- 在文件管理、系统状态、登录和 Wi-Fi 配网页加入 Light/Dark 切换，选择保存在当前浏览器；默认沿用深色外观。
- 文件页增加当前视图统计，并提供本地文件类型过滤和名称、大小、类型排序；这些操作使用已加载的列表，不额外请求 NAS。
- Light/Dark 共用样式位于 `Swiftwing_Master/ui/theme.css`，页面样式在各自的 CSS 文件中。修改后照常运行 `python .\build_webui.py`，只需刷写 Master。
- 四个嵌入页面的 gzip 总量从 V1.2.0 的 23,973 B 增加到 32,172 B（增加 8,199 B）。页面源码与固件数组逐页一致，页面脚本通过 Node 语法检查；Master 的 15 条 HTTP 路由不变，其他四块板的固件文件与 V1.2.0 相同。
- 本轮未使用浏览器做截图检查，也未编译或刷写实机；因此主题视觉细节和设备端完整回归仍待上板确认。

## Monitor 风扇控制（V1.2.2）

- System Status 的 ESP32 Monitor 状态区新增 0–100% PWM 滑杆、应用和关闭操作；只允许主账号控制。状态通过现有 `/api/state` 只读字段更新，控制走新增的登录保护 `/api/fan` 路由，再由 Master 单播 UDP 命令到 Monitor。旧版 Monitor 不带风扇能力标志时 UI 自动显示需升级 Monitor 固件。
- Monitor 使用 GPIO25、25 kHz、8 bit LEDC PWM；从关闭转为运行时先 100% 启动 300 ms，然后进入设定占空比。目标占空比保存在 Monitor 专用 NVS namespace，重复命令不会反复写入。断电首次启动默认关闭；没有转速传感器，因此反馈的是目标/输出 PWM，不是 RPM。
- GPIO25 与 OLED 的 GPIO21/22 I²C 不冲突。GPIO 仅用于 MOSFET 栅极驱动，风扇必须由额定电源供电；具体接线和 4 线 PWM 风扇限制见 `FAN_WIRING.txt`。
- 页面 gzip 已重新嵌入，四个源页面与固件中的 gzip 解压内容逐页一致；状态页 3 段脚本通过 Node.js 语法检查。页面压缩总量为 34,026 B（V1.2.1 为 32,172 B，增加 1,854 B）。Master 从 15 个 HTTP 路由增加到 16 个，只新增 `/api/fan`。
- Arduino CLI 1.5.1、ESP32 core 3.3.12，`esp32:esp32:esp32` 构建通过：Master 1,014,716 B（77% flash，48,872 B globals）；Monitor 默认配置 965,443 B（73% flash，49,692 B globals）。临时启用 OLED 的 Monitor 变体也通过构建，1,005,219 B（76% flash，51,252 B globals）。
- 与 V1.2.1 ZIP 逐文件比较，只有 Master 与 ESP32 Monitor 的 `.ino` 改动；Node1、Node2、C3 DNS 源码没有变化。实机不可用，本轮没有验证实际风扇、MOSFET 接线、最低可运行占空比或风扇噪声/温度；页面不显示实测 RPM。

## 用户账号与界面修正（V1.2.3）

- 登录页由“申请访问”改为“创建账号”：用户自选用户名和密码后立即登录；密码长度为 8–64 个字符。管理员仍使用独立 `admin` 登录。
- 用户密码用独立随机盐和 PBKDF2-HMAC-SHA256 派生值存储；管理员用户页仅返回用户名，可撤销账号并清除现有会话，不会返回密码或哈希。用户最多 16 个，旧版本中等待审批的账号升级后自动激活。
- 文件页上传进度栏移除负上边距，主存储栏允许内容完整显示；Workspace / Snapshot 统计条固定最小高度并增加垂直留白，窄屏仍使用较紧凑的内边距。
- UI 页面源仍只由 Master 固件提供；重新嵌入页面后只需刷写 Master，Monitor 和其它节点没有改动。
- Arduino CLI 1.5.1 / ESP32 core 3.3.12 编译通过：Master 1,014,208 B（77% Flash；48,872 B globals）。四个 gzip 页面逐页与源文件一致，11 段页面脚本通过 Node.js 语法检查。因无可接入的实机，本轮未刷写或验证设备端登录与 NVS 行为。

## Raspberry Pi 5 四针风扇（V1.2.4）

- Monitor 的 GPIO25 改为输出 25 kHz 四线风扇 PWM 控制信号，通过外部开集电极/开漏晶体管连接风扇 PWM 脚；占空比按晶体管反相映射，网页 100% 对应风扇最大转速。+5 V 电机供电保持常接，Tach 未接入、网页仍显示设定值而非实测 RPM。
- Master 原有 0–100% 网站滑杆和 UDP 命令格式不变。已装有带风扇滑杆的 Master（V1.2.2 或更新）只需更新 ESP32 Monitor；旧 2/3 针风扇仍可在 Monitor 源码中将 `FAN_OUTPUT_4WIRE_PWM` 设为 0，并使用旧低侧功率 MOSFET 接法。
- Raspberry Pi 5 适配线序为 1:+5 V、2:PWM、3:GND、4:Tach；一般 PC 4 针风扇的电压和线序可能不同，接线前应看标签和风扇资料。GPIO25 不能直接接 PWM 脚，ESP32 GPIO 也不能给风扇电机供电。
- Arduino CLI 1.5.1 / ESP32 core 3.3.12 编译通过：ESP32 Monitor 965,447 B（73% Flash；49,692 B globals）。无实机可接，未验证实际转速、0% 是否停转、线序、电流预算或温升；需要按随包 `FAN_WIRING.txt` 接好外部驱动后再测试。

## Monitor 风扇启动时序（V1.2.5）

- 检查发现 Monitor 的 `setup()` 先等待 Wi-Fi，连接函数在网络不可用时会持续重试；PWM 初始化被阻塞期间，开集电极驱动保持释放，风扇会处于硬件满速失效保护状态。
- 将 `setupFanControl()` 移到 `connectWiFi()` 之前，开机时先载入 NVS 设定并开始 PWM。路由器暂时离线时，风扇也会维持已保存的转速。
- Master、UI、UDP 命令及其他节点源码未更改；ESP32 Monitor 使用 Arduino CLI 1.5.1 / ESP32 core 3.3.12 重新编译通过。未接入实机，仍需验证具体风扇在 0% 和最低转速区间的行为。

## 设备验证

本次没有连接或刷写实物板，也没有可用 SD 卡，因此不能保证实际上传速度、温度、ESP32 Monitor OLED 接线或特定路由器下的广播可靠性。一次局域网只读首页请求返回了 Storage Node 2 状态页，显示 `Storage: NOT READY`；该页没有固件版本标识，无法确认运行的是本次优化版，也不能据此诊断 SD 未就绪的原因。管理 API 需要密钥，本次没有发送密钥或执行写操作。刷写后建议在同一 Wi-Fi/SD 卡条件下：检查登录与页面、恢复 AP 和五板配网、ESP32 Monitor 状态与 OLED、域名解析与节点状态；上传大文件后下载并比对哈希；记录上传 MB/s、空闲与传输时温度，并持续观察节点发现状态。若目标路由器的省电行为影响节点发现，应先对相应板子关闭 Wi-Fi 省电再复测。

原版覆盖同名文件时会先删除旧文件，再写新文件。本次沿用该行为；若覆盖上传时断电、断线或 SD 写入失败，旧文件不会自动恢复。重要文件宜先备份，再做覆盖上传。

若上传客户端暂停发送数据很久，同步 WebServer 可能一直等待下一块数据，期间无法处理节点发现；Master 可能暂时显示该节点离线。传输继续或结束后会恢复发现回复。
