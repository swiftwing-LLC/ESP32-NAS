Swiftwing NAS V1.2.5 - Fan Startup Fix / Master UI V1.2.3

Goal
- Keep the original V6 domain design unchanged.
- The normal NAS address remains: http://swiftwingnas.tplinkdns.com
- Keep C3 DNS behavior, external DDNS/port-forward behavior, storage nodes and monitor behavior.
- Use an ESP32 Dev Module / ESP32-WROOM-32 for the Monitor node.
- Optional SSD1306 OLED wiring on that board: SDA GPIO21, SCL GPIO22; OLED support is disabled by default.
- Add one Wi-Fi control in the Master UI.
- Refresh the existing file manager, login, status and Wi-Fi pages with a dark cobalt control-console theme.
- Keep the editable page sources under Swiftwing_Master\ui; run python .\build_webui.py from Swiftwing_Master to embed them in flash.
- The visible UI version comes from UI_BUILD in Swiftwing_Master. After changing it or the UI pages, run the build_webui.py command above and flash the Master board; the other boards do not need an upload for UI label changes.
- V1.2.3 account and UI changes are Master-only. Compile/upload Swiftwing_Master once; do not reflash the ESP32 Monitor, storage nodes or C3 DNS for this update.
- The theme control stores the selection in this browser and applies it to the file manager, system status, login and Wi-Fi setup pages. Shared theme rules live in Swiftwing_Master\ui\theme.css.
- The System Status page controls the ESP32 Monitor fan at 0–100% PWM in 5% steps. The selected speed is saved on that Monitor and restored after reboot; the fan starts OFF until a speed is chosen.
- Default fan mode supports the 4-wire PWM fan used by Raspberry Pi 5. Monitor GPIO25 drives a 25 kHz signal through an external open-collector transistor; the fan motor needs a suitable 5 V supply. Never connect the motor or PWM input directly to an ESP32 GPIO. See FAN_WIRING.txt for the Pi header pinout and safe wiring.
- The Monitor loads and applies the saved fan speed before it waits for Wi-Fi, so a router outage does not leave the fan at its power-on fail-safe speed while the board retries its connection.
- Legacy 2-wire/3-wire power-PWM fans remain selectable by setting FAN_OUTPUT_4WIRE_PWM to 0 in the Monitor sketch and using the documented low-side MOSFET circuit.
- Only the owner account can change fan speed. No tachometer input is connected, so the page reports the PWM setpoint/output rather than measured RPM.
- Anyone can create a user account on the login page and sign in immediately. Each user chooses their own username and password; the Master stores a per-user salted password hash, never the readable password. The Master stores up to 16 user accounts in NVS; passwords must be 8–64 characters.
- The admin account remains separate (`admin`) and only the owner account can open the Users panel, view usernames, revoke access or change Wi-Fi settings. The Users panel never returns password hashes or passwords.
- User accounts share the existing NAS volume and file permissions. The current system does not create private home folders per account. Older pending account requests are automatically enabled by this version.
- The Master serves the login page over HTTP on port 80. Use a trusted LAN or VPN for sign-in; the current firmware does not provide TLS encryption.

Normal use
1. Open http://swiftwingnas.tplinkdns.com
2. Login.
3. Tap/click the "📶 Wi-Fi" button.
4. Scan nearby Wi-Fi, choose one, enter the password, and press "Connect all 5 boards".
5. Master sends the new Wi-Fi to Node1, Node2, C3 DNS and ESP32 Monitor.
6. All five boards save it and restart.

Recovery / first setup
- Master always provides the password-protected recovery AP:
  SSID: Swiftwing-Bridge
  Password: swiftwing-setup
- If home Wi-Fi is unavailable, connect a phone to that AP and open:
  http://192.168.4.1
- The same Wi-Fi picker is shown.
- Other nodes automatically fall back to Swiftwing-Bridge when their saved home Wi-Fi is unavailable, so one configuration on Master can provision them.

Important
- This version intentionally does not redesign the original tplinkdns.com logic.
- Wi-Fi credentials selected in the UI are stored in flash and do not require Arduino IDE edits afterward.
- If the Master already has the fan slider (V1.2.2 or later), upload only the updated Swiftwing_ESP32_Monitor for 4-wire PWM support. For an older Master without the fan slider, also upload Swiftwing_Master. Node1, Node2 and C3 DNS do not need changes.
