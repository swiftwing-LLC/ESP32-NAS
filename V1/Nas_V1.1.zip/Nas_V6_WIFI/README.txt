Swiftwing NAS V1.2.1 - Cobalt Motion / ESP32 Monitor

Goal
- Keep the original V6 domain design unchanged.
- The normal NAS address remains: http://swiftwingnas.tplinkdns.com
- Keep C3 DNS behavior, external DDNS/port-forward behavior, storage nodes and monitor behavior.
- Use an ESP32 Dev Module / ESP32-WROOM-32 for the Monitor node.
- Optional SSD1306 OLED wiring on that board: SDA GPIO21, SCL GPIO22; OLED support is disabled by default.
- Add one Wi-Fi control in the Master UI.
- Refresh the existing file manager, login, status and Wi-Fi pages with a dark cobalt control-console theme.
- Keep the editable page sources under Swiftwing_Master\ui; run python .\build_webui.py from Swiftwing_Master to embed them in flash.
- The visible UI version comes from UI_BUILD in Swiftwing_Master. After changing it or the UI pages, run the build_webui.py command above and flash the Master board; the other boards do not need an upload for UI label changes.
- The theme control stores the selection in this browser and applies it to the file manager, system status, login and Wi-Fi setup pages. Shared theme rules live in Swiftwing_Master\ui\theme.css.
- The login page accepts account requests. New accounts stay pending until the NAS owner approves them from the Master file console's Access requests control. The Master stores up to 8 user accounts in NVS; new passwords must be at least 12 characters.
- Approved accounts have individual sign-in credentials and share the existing NAS volume and file permissions. The current system does not create private home folders per account.
- Only the owner account can review users or change Wi-Fi settings; approved users can use the shared file console.
- The Master serves the login page over HTTP on port 80. Use a trusted LAN or VPN for sign-in; the current firmware does not provide TLS encryption.

Normal use
1. Open http://swiftwingnas.tplinkdns.com
2. Login.
3. Tap/click the "📶 Wi-Fi" button.
4. Scan nearby Wi-Fi, choose one, enter the password, and press "Connect all 5 boards".
5. Master sends the new Wi-Fi to Node1, Node2, C3 DNS and ESP32 Monitor.
6. All five boards save it and restart.

Recovery / first setup
- Master always provides the password-protected recovery AP:
  SSID: Swiftwing-Bridge
  Password: swiftwing-setup
- If home Wi-Fi is unavailable, connect a phone to that AP and open:
  http://192.168.4.1
- The same Wi-Fi picker is shown.
- Other nodes automatically fall back to Swiftwing-Bridge when their saved home Wi-Fi is unavailable, so one configuration on Master can provision them.

Important
- This version intentionally does not redesign the original tplinkdns.com logic.
- Wi-Fi credentials selected in the UI are stored in flash and do not require Arduino IDE edits afterward.
